import os
import sys
import json

# Add project root to sys.path to allow importing from CaseMaster and other top-level packages
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from CaseMaster import CaseEnquiry
import Batch
import Report
import getTodayCode  # <--- 新增此行以導入模組
from PyQt6 import QtWidgets, QtGui, QtCore, QtPrintSupport  # PyQt6 import

class DashboardSystem(QtWidgets.QMainWindow):
    def __init__(self, username, system_type):
        print("--- DashboardSystem.__init__ START ---") # DEBUG
        super().__init__()
        self.username = username
        self.system_type = system_type
        self.setWindowTitle("ICS Dialing System (Administration)")

        # 取得屏幕大小，用於全屏顯示
        print("Getting screen geometry...") # DEBUG
        screen = QtGui.QGuiApplication.primaryScreen().geometry()  # PyQt6
        self.setGeometry(0, 0, screen.width(), screen.height())
        print("Set geometry.") # DEBUG

        self._block_signals = True
        self.active_submenu_windows = []
        self.last_menu_index = -1
        self.parent_menu = {}
        self._intended_return_target = None # Flag to track return target

        print("Initializing main_modules_data...") # DEBUG
        self.main_modules_data = [
            ("1. Case Master", ["1. Case Enquiry",
                                "2. Case Entry",
                                "3. Case Transfer",
                                "4. Case Return",
                                "5. Case Settle",
                                "6. Case Detail Code",
                                "7. Case Information Code",
                                "8. Hold Action",
                                "9. User Case Report",
                                "A. Case Allocation Detail",
                                "B. Payment Due Date Entry",
                                "C. Case Address Batch",
                                "D. Print Visit or Mail Letter",
                                "E. Retain Case",
                                "F. Action Code Details",
                                "G. Re-open case",
                                "H. Case Expiry Master",
                                "I. Non-FIRM List",
                                "J. Add Dunning",
                                "K. Adjust First Action/Visit Day",
                                "0. Return"]),            

            ("2. Payment Master", ["1. Sub 2.1", "2. Sub 2.2", "0. Return"]),
            ("3. Client Master", ["1. Sub 3.1", "0. Return"]),
            ("4. Collector Master", ["1. Sub 4.1", "0. Return"]),
            ("5. Report Master", ["1. Sub 5.1", "0. Return"]),
            ("6. System Master", ["1. Sub 6.1", "0. Return"]),
            ("7. Billing Master", ["1. Sub 7.1", "0. Return"]),
            ("8. Salary Master", ["1. Sub 8.1", "0. Return"]),
            ("9. Database Maintenance", ["1. Get Code",  # <--- 選項文字保持不變
                                         "0. Return"]),
            ("A. Popup Maintenance", ["1. Sub A.1", "0. Return"]),
            ("B. Data Matching", ["1. Sub B.1", "0. Return"]),
            ("C. Assignment Exception Report", ["1. Sub C.1", "0. Return"]),
            ("D. Misc", ["1. Sub D.1", "0. Return"]),
            ("P. Change Password", ["1. Enter Current Password:", "2. Enter New Password:", "3. Confirm New Password:", "4. Update", "0. Return"]),
            ("0. EXIT", [])
        ]
        print("Initializing main_module_names...") # DEBUG
        if self.main_modules_data is None:
             print("ERROR: self.main_modules_data is None before list comprehension!") # DEBUG
             raise ValueError("main_modules_data cannot be None")
        try:
            self.main_module_names = [item[0] for item in self.main_modules_data]
            print(f"main_module_names initialized: {self.main_module_names}") # DEBUG
        except Exception as e:
            print(f"ERROR during main_module_names initialization: {e}") # DEBUG
            raise

        self.current_sub_menu_items = []

        print("Initializing submenu_data...") # DEBUG
        self.submenu_data = {
            "Case Entry": ["1. Case Entry by Batch", "2. Case Entry Report", "0. Return"],
            "Hold Case": ["1. Case Hold Action", "2. Held case recall date report", "0. Return"],
            "Case Information Code": ["1. Case Information Code Database", "2. Case Information Code Entry", "0. Return"],
            "Case Detail Code": ["1. Case Detail Code Database", "2. Case Detail Code Entry", "3. Assign Detail Code By System", "0. Return"],
            "Case Settle": ["1. Print Settle Letter", "2. Print Processed Settle Letter", "3. Print Processed Settle List", "4. Settle Letter Batch", "0. Return"],
            "Case Return": ["1. Case Return", "2. Print Return Letter", "3. Print Processed Return Letter", "4. Print Processed Return List", "0. Return"],
            "Case Transfer": ["1. Case Transfer", "2. Transfer Report", "0. Return"]
        }
        print("submenu_data initialized.") # DEBUG

        print("Calling init_ui...") # DEBUG
        self.init_ui()
        print("--- DashboardSystem.__init__ END ---") # DEBUG

    def init_ui(self):
        print("--- init_ui START ---") # DEBUG
        self.setStyleSheet("background-color: #009090;")
        container_widget = QtWidgets.QWidget()
        self.setCentralWidget(container_widget)
        top_title_bar = QtWidgets.QWidget()
        top_title_bar.setFixedHeight(25)
        top_title_bar.setStyleSheet("background-color: blue; border: none;")
        top_title_layout = QtWidgets.QHBoxLayout(top_title_bar)
        top_title_layout.setContentsMargins(10, 0, 10, 0)
        title_label = QtWidgets.QLabel("Integrated Credit Services Administration")
        title_label.setFont(QtGui.QFont("Arial", 11, QtGui.QFont.Weight.Bold)) # PyQt6
        title_label.setStyleSheet("color: yellow;")
        top_title_layout.addWidget(title_label)
        top_title_layout.addStretch()
        main_layout = QtWidgets.QVBoxLayout()
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(0)
        sidebar_container = QtWidgets.QWidget()
        sidebar_container.setFixedWidth(250)
        sidebar_container.setStyleSheet("""        
            background-color: #d4d0c8;
            border: 2px solid black;
            border-radius: 1px;
        """)
        sidebar_layout = QtWidgets.QVBoxLayout(sidebar_container)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(0)
        sidebar_title_bar = QtWidgets.QWidget()
        sidebar_title_bar.setFixedHeight(20)
        sidebar_title_bar.setStyleSheet("background-color: black; border: none;")
        sidebar_title_layout = QtWidgets.QHBoxLayout(sidebar_title_bar)
        sidebar_title_layout.setContentsMargins(5, 0, 5, 0)
        sidebar_title_label = QtWidgets.QLabel("MAIN MENU")
        sidebar_title_label.setFont(QtGui.QFont("Arial", 9, QtGui.QFont.Weight.Bold)) # PyQt6
        sidebar_title_label.setStyleSheet("color: white; border: none;")
        sidebar_title_layout.addWidget(sidebar_title_label)
        sidebar_title_layout.addStretch()
        sidebar_layout.addWidget(sidebar_title_bar)
        self.module_list = QtWidgets.QListWidget()
        self.module_list.blockSignals(True)
        self.module_list.setFont(QtGui.QFont("Arial", 9))
        self.module_list.setStyleSheet("""
            QListWidget {
                border: none;
                background-color: #d4d0c8;
                outline: 0;
            }
            QListWidget::item {
                padding: 2px 5px;
                color: black;
                border: none;
            }
            QListWidget::item:selected {
                background-color: blue;
                color: white;
            }
        """)
        print("Adding items to module_list...") # DEBUG
        if self.main_module_names is None:
             print("ERROR: self.main_module_names is None before addItems!") # DEBUG
        else:
             try:
                 self.module_list.addItems(self.main_module_names)
                 print("Items added to module_list.") # DEBUG
             except Exception as e:
                 print(f"ERROR during module_list.addItems: {e}") # DEBUG
                 raise
        sidebar_layout.addWidget(self.module_list)
        main_layout.addWidget(sidebar_container)
        self.module_list.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # PyQt6
        self.module_list.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # PyQt6
        outer_layout = QtWidgets.QVBoxLayout(container_widget)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)
        outer_layout.addWidget(top_title_bar)
        outer_layout.addLayout(main_layout)
        status_bar = QtWidgets.QStatusBar()
        status_bar.setStyleSheet("color: black; background-color: #d4d0c8;")
        self.setStatusBar(status_bar)
        self.status_bar = status_bar
        self.status_bar.showMessage("Focus restored to main menu, ready for input")
        self.module_list.clearSelection()
        self.module_list.setCurrentRow(-1)
        self.module_list.currentRowChanged.connect(self.change_module_content)

    def _show_submenu_window(self, title, items, parent_title="MAIN MENU"):
        for window in self.active_submenu_windows:
            if window.windowTitle() == title:
                window.raise_()
                window.activateWindow()
                return
        sub_window = QtWidgets.QDialog(self)
        sub_window.setWindowTitle(title)
        sub_window.setStyleSheet("""
            background-color: #d4d0c8;
            border: 2px solid black;
            border-radius: 1px;
        """)
        self.parent_menu[title] = parent_title
        base_x = 25
        base_y = 80
        if parent_title == "MAIN MENU":
            sub_window.setFixedSize(350, 470) #470
            x_pos = base_x + 115
            y_pos = base_y + 35
        elif parent_title == "Case Master":
            sub_window.setFixedSize(350, 250)
            x_pos = base_x + 230
            y_pos = base_y + 75
        else:
            sub_window.setFixedSize(350, 230)
            x_pos = base_x + 345
            y_pos = base_y + 115
        sub_window.move(x_pos, y_pos)
        sub_window.setWindowFlags(QtCore.Qt.WindowType.Dialog | QtCore.Qt.WindowType.FramelessWindowHint)  # PyQt6
        layout = QtWidgets.QVBoxLayout(sub_window)
        layout.setContentsMargins(1, 1, 1, 1)
        layout.setSpacing(0)
        title_bar = QtWidgets.QWidget()
        title_bar.setFixedHeight(20)
        title_bar.setStyleSheet("background-color: black; border: none;")
        title_layout = QtWidgets.QHBoxLayout(title_bar)
        title_layout.setContentsMargins(5, 0, 5, 0)
        title_label = QtWidgets.QLabel(title.upper())
        title_label.setFont(QtGui.QFont("Arial", 9, QtGui.QFont.Weight.Bold)) # PyQt6
        title_label.setStyleSheet("color: white;")
        title_layout.addWidget(title_label)
        layout.addWidget(title_bar)
        sub_list = QtWidgets.QListWidget()
        sub_list.setFont(QtGui.QFont("Arial", 9))
        sub_list.setStyleSheet("""
            QListWidget {
                border: none;
                background-color: #d4d0c8;
                outline: 0;
            }
            QListWidget::item {
                padding: 2px 5px;
                color: black;
                border: none;
            }
            QListWidget::item:selected {
                background-color: blue;
                color: white;
            }
        """)
        if items:
             sub_list.addItems(items)
        else:
             print(f"Warning: No items provided for submenu '{title}'")
        sub_list.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # PyQt6
        sub_list.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # PyQt6
        layout.addWidget(sub_list)
        sub_list.keyPressEvent = lambda event: self._submenu_key_press(event, sub_list, sub_window, title)
        sub_window.finished.connect(lambda result_code, win=sub_window: self._remove_submenu_window(win)) # Pass window instance
        self.active_submenu_windows.append(sub_window)
        sub_window.show()
        sub_list.setFocus()

    def _remove_submenu_window(self, window):
        """從活動窗口列表中移除關閉的窗口，並根據情況恢復焦點"""
        window_title = window.windowTitle() # Get title before potential removal
        print(f"--- _remove_submenu_window START for '{window_title}' ---") # DEBUG

        # Check if we intended to return to a specific parent
        intended_target = getattr(self, '_intended_return_target', None)
        print(f"Intended return target: {intended_target}") # DEBUG

        parent_widget_to_focus = None
        if intended_target and intended_target != "MAIN MENU":
            # Try to find the parent window among active ones
            for parent_win in self.active_submenu_windows:
                if parent_win.windowTitle() == intended_target:
                    parent_widget_to_focus = parent_win
                    break
            print(f"Parent widget found for '{intended_target}': {parent_widget_to_focus is not None}") # DEBUG

        # --- Clean up the closed window ---
        if window in self.active_submenu_windows:
            self.active_submenu_windows.remove(window)
            print(f"Removed '{window_title}' from active_submenu_windows.") # DEBUG
        if window_title in self.parent_menu:
            del self.parent_menu[window_title]
            print(f"Removed '{window_title}' from parent_menu.") # DEBUG
        # --- End clean up ---

        # Reset the intention flag regardless of outcome
        self._intended_return_target = None

        if parent_widget_to_focus:
            print(f"Attempting to focus parent: '{parent_widget_to_focus.windowTitle()}'") # DEBUG
            # Focus the parent submenu's list
            parent_list = parent_widget_to_focus.findChild(QtWidgets.QListWidget)
            if parent_list:
                # Use a short timer to ensure focus is set after window context settles
                QtCore.QTimer.singleShot(0, parent_list.setFocus)
                QtCore.QTimer.singleShot(0, parent_widget_to_focus.raise_)
                QtCore.QTimer.singleShot(0, parent_widget_to_focus.activateWindow)
                print(f"Scheduled focus for parent list of '{parent_widget_to_focus.windowTitle()}'.") # DEBUG
            else:
                print(f"ERROR: Could not find QListWidget in parent '{parent_widget_to_focus.windowTitle()}'. Falling back to main menu.") # DEBUG
                # Fallback to main menu focus if list not found
                self._schedule_main_menu_focus_restore()
        else:
            # Default: return focus to the main menu
            print("No specific parent target or parent not found. Returning focus to MAIN MENU.") # DEBUG
            self._schedule_main_menu_focus_restore()

        print(f"--- _remove_submenu_window END for '{window_title}' ---") # DEBUG

    def _schedule_main_menu_focus_restore(self):
        """Schedules the delayed focus restoration to the main menu."""
        self._block_signals = True
        self.activateWindow()
        self.raise_()
        QtCore.QTimer.singleShot(100, self._delayed_focus_restore)
        print("Scheduled delayed focus restore to MAIN MENU.") # DEBUG

    def _delayed_focus_restore(self):
        """延遲恢復焦點和信號處理 (只用於返回主選單)"""
        print("--- _delayed_focus_restore executing ---") # DEBUG
        current_row = self.module_list.currentRow()
        if current_row >= 0:
            self.module_list.blockSignals(True)
            self.module_list.setCurrentRow(-1)
            self.module_list.blockSignals(False)
            print("Cleared main menu selection.") # DEBUG

        self._block_signals = False
        print("Re-enabled signals.") # DEBUG

        self.module_list.setFocus(QtCore.Qt.FocusReason.ActiveWindowFocusReason)  # PyQt6
        print("Set focus to main menu list.") # DEBUG

        self.repaint()
        QtWidgets.QApplication.processEvents()

        print("Focus restored to main menu, ready for input")
        self.status_bar.showMessage("Focus restored to main menu, ready for input") # Update status bar

    def _submenu_key_press(self, event, list_widget, dialog, title):
        """處理子選單窗口的按鍵事件"""
        key = event.key()
        text = event.text().upper()

        if key == QtCore.Qt.Key.Key_Escape or text == '0':  # PyQt6
            print(f"Return key pressed in submenu '{title}'")

            self._intended_return_target = self.parent_menu.get(title) # Store parent title or None
            print(f"Setting intended return target to: '{self._intended_return_target}'")

            dialog.accept() # Close the current dialog

            event.accept()
            return

        if text and text.isalnum():
            prefix = text + ". "
            found = False
            for i in range(list_widget.count()):
                item_text = list_widget.item(i).text()
                if item_text.upper().startswith(prefix):
                    list_widget.setCurrentRow(i)
                    self._handle_submenu_action(title, list_widget.item(i))
                    found = True
                    break

            if found:
                event.accept()
                return

        QtWidgets.QListWidget.keyPressEvent(list_widget, event)

    def _handle_submenu_action(self, title, item):
        if not item:
            return

        selected_text = item.text()
        print(f"Selected: {title} -> {selected_text}")
        dialog = item.listWidget().parent() # This is the QDialog of the current submenu
        action_name = selected_text.split(". ", 1)[-1]

        if selected_text == "0. Return":
            window_title = dialog.windowTitle()
            self._intended_return_target = self.parent_menu.get(window_title)
            print(f"Returning from '{window_title}'. Setting intended return target: '{self._intended_return_target}'")
            dialog.accept()
            return

        should_open_submenu = False
        submenu_items_to_open = None
        if title == "Case Master":
             submenu_key_map = {
                 "Case Entry": "Case Entry", "Case Transfer": "Case Transfer", "Case Return": "Case Return",
                 "Case Settle": "Case Settle", "Case Detail Code": "Case Detail Code",
                 "Case Information Code": "Case Information Code", "Hold Action": "Hold Case"
             }
             submenu_key = submenu_key_map.get(action_name)
             if submenu_key and submenu_key in self.submenu_data:
                  should_open_submenu = True
                  submenu_items_to_open = self.submenu_data[submenu_key]

        if should_open_submenu:
            if submenu_items_to_open is not None:
                print(f"Opening submenu: {action_name}")
                QtCore.QTimer.singleShot(0, lambda an=action_name, items=submenu_items_to_open, t=title: self._show_submenu_window(an, items, parent_title=t))
            else:
                 print(f"Warning: Submenu items for '{action_name}' not found in submenu_data.")
            return

        error_message = None
        dialog_launched = False

        if title == "Case Master":
            if selected_text == "1. Case Enquiry":
                print("Opening Case Enquiry...")
                dialog_launched = True
                try:
                    if hasattr(CaseEnquiry, 'CaseEnquiry') and isinstance(CaseEnquiry.CaseEnquiry, type):
                        enquiry_dialog = CaseEnquiry.CaseEnquiry(self)
                        parent_submenu_dialog = dialog
                        enquiry_dialog.exec()  # PyQt6 Blocks until Case Enquiry closes

                        if parent_submenu_dialog and parent_submenu_dialog.isVisible():
                             list_widget = parent_submenu_dialog.findChild(QtWidgets.QListWidget)
                             if list_widget:
                                 QtCore.QTimer.singleShot(0, parent_submenu_dialog.raise_)
                                 QtCore.QTimer.singleShot(0, parent_submenu_dialog.activateWindow)
                                 QtCore.QTimer.singleShot(0, list_widget.setFocus)
                                 print("Refocused Case Master list after Case Enquiry closed.") # DEBUG
                             else:
                                 print("ERROR: Could not find list widget in parent submenu after Case Enquiry closed.")
                                 self._schedule_main_menu_focus_restore()
                        else:
                             print("Parent submenu no longer visible after Case Enquiry closed. Returning to main menu.")
                             self._schedule_main_menu_focus_restore()

                    else:
                        error_message = "Could not load Case Enquiry module or class."
                except ImportError as e:
                    error_message = f"ImportError loading Case Enquiry: {e}"
                except AttributeError as e:
                     error_message = f"AttributeError loading Case Enquiry: {e}"
                except Exception as e:
                    error_message = f"Failed to open Case Enquiry: {e}"

                if error_message:
                    QtWidgets.QMessageBox.critical(self, "Error", error_message)
                    if dialog and dialog.isVisible():
                         list_widget = dialog.findChild(QtWidgets.QListWidget)
                         if list_widget:
                             QtCore.QTimer.singleShot(0, dialog.raise_)
                             QtCore.QTimer.singleShot(0, dialog.activateWindow)
                             QtCore.QTimer.singleShot(0, list_widget.setFocus)

        elif title == "Case Entry":
            if selected_text == "1. Case Entry by Batch":
                print("Opening Case Entry by Batch...")
                dialog_launched = True
                try:
                    if hasattr(Batch, 'CaseEntryBatch') and isinstance(Batch.CaseEntryBatch, type):
                        batch_dialog = Batch.CaseEntryBatch(self)
                        parent_submenu_dialog = dialog
                        batch_dialog.exec()  # PyQt6 Blocks

                        if parent_submenu_dialog and parent_submenu_dialog.isVisible():
                             list_widget = parent_submenu_dialog.findChild(QtWidgets.QListWidget)
                             if list_widget:
                                 QtCore.QTimer.singleShot(0, parent_submenu_dialog.raise_)
                                 QtCore.QTimer.singleShot(0, parent_submenu_dialog.activateWindow)
                                 QtCore.QTimer.singleShot(0, list_widget.setFocus)
                                 print("Refocused Case Entry list after Batch closed.") # DEBUG
                             else:
                                 print("ERROR: Could not find list widget in parent submenu after Batch closed.")
                                 self._schedule_main_menu_focus_restore()
                        else:
                             print("Parent submenu no longer visible after Batch closed. Returning to main menu.")
                             self._schedule_main_menu_focus_restore()
                    else:
                        error_message = "Could not load Case Entry Batch module or class."
                except ImportError as e:
                    error_message = f"ImportError loading Case Entry Batch: {e}"
                except AttributeError as e:
                     error_message = f"AttributeError loading Case Entry Batch: {e}"
                except Exception as e:
                    error_message = f"Failed to open Case Entry Batch: {e}"

                if error_message:
                    QtWidgets.QMessageBox.critical(self, "Error", error_message)
                    if dialog and dialog.isVisible():
                         list_widget = dialog.findChild(QtWidgets.QListWidget)
                         if list_widget:
                             QtCore.QTimer.singleShot(0, dialog.raise_)
                             QtCore.QTimer.singleShot(0, dialog.activateWindow)
                             QtCore.QTimer.singleShot(0, list_widget.setFocus)

            elif selected_text == "2. Case Entry Report":
                print("Opening Case Entry Report...")
                dialog_launched = True
                try:
                    if hasattr(Report, 'CaseEntryReportDialog') and isinstance(Report.CaseEntryReportDialog, type):
                        report_dialog = Report.CaseEntryReportDialog(self)
                        parent_submenu_dialog = dialog
                        report_dialog.exec()  # PyQt6 Blocks

                        if parent_submenu_dialog and parent_submenu_dialog.isVisible():
                             list_widget = parent_submenu_dialog.findChild(QtWidgets.QListWidget)
                             if list_widget:
                                 QtCore.QTimer.singleShot(0, parent_submenu_dialog.raise_)
                                 QtCore.QTimer.singleShot(0, parent_submenu_dialog.activateWindow)
                                 QtCore.QTimer.singleShot(0, list_widget.setFocus)
                                 print("Refocused Case Entry list after Report closed.") # DEBUG
                             else:
                                 print("ERROR: Could not find list widget in parent submenu after Report closed.")
                                 self._schedule_main_menu_focus_restore()
                        else:
                             print("Parent submenu no longer visible after Report closed. Returning to main menu.")
                             self._schedule_main_menu_focus_restore()
                    else:
                        error_message = "Could not load Case Entry Report module or class."
                except ImportError as e:
                    error_message = f"ImportError loading Case Entry Report: {e}"
                except AttributeError as e:
                     error_message = f"AttributeError loading Case Entry Report: {e}"
                except Exception as e:
                    error_message = f"Failed to open Case Entry Report: {e}"

                if error_message:
                    QtWidgets.QMessageBox.critical(self, "Error", error_message)
                    if dialog and dialog.isVisible():
                         list_widget = dialog.findChild(QtWidgets.QListWidget)
                         if list_widget:
                             QtCore.QTimer.singleShot(0, dialog.raise_)
                             QtCore.QTimer.singleShot(0, dialog.activateWindow)
                             QtCore.QTimer.singleShot(0, list_widget.setFocus)

        elif title == "Database Maintenance":
            if selected_text == "1. Get Code":
                dialog_launched = True
                try:
                    print("Launching Code Generator dialog...") # DEBUG
                    getTodayCode.generate_today_code_dialog(dialog) # Pass current submenu dialog as parent
                except ImportError as e:
                    error_message = f"ImportError loading getTodayCode module: {e}"
                except AttributeError as e:
                    error_message = f"AttributeError in getTodayCode module: {e}"
                except Exception as e:
                    error_message = f"Failed to execute Code Generator dialog: {e}"

                if error_message:
                    QtWidgets.QMessageBox.warning(dialog, "Error", error_message) # Show error with submenu as parent

                # Always attempt to refocus the submenu list after the action or error
                if dialog and dialog.isVisible():
                    list_widget = dialog.findChild(QtWidgets.QListWidget)
                    if list_widget:
                        QtCore.QTimer.singleShot(0, dialog.raise_)
                        QtCore.QTimer.singleShot(0, dialog.activateWindow)
                        QtCore.QTimer.singleShot(0, list_widget.setFocus)
                        print(f"Refocused '{dialog.windowTitle()}' list after 'Code Generator' action.") # DEBUG
                    else:
                        print(f"ERROR: Could not find list widget in '{dialog.windowTitle()}' after 'Code Generator'.") # DEBUG
                        self._schedule_main_menu_focus_restore()
                else:
                    print(f"'{dialog.windowTitle()}' submenu no longer visible. Returning to main menu.") # DEBUG
                    self._schedule_main_menu_focus_restore()
                return # Important to return after handling this specific action

        elif not dialog_launched:
            print(f"Default action (message box) for: {selected_text}")
            parent_submenu_dialog = dialog
            QtCore.QTimer.singleShot(50, lambda text=selected_text: self.show_action_message(text))
            def refocus_parent():
                if parent_submenu_dialog and parent_submenu_dialog.isVisible():
                     list_widget = parent_submenu_dialog.findChild(QtWidgets.QListWidget)
                     if list_widget:
                         parent_submenu_dialog.raise_()
                         parent_submenu_dialog.activateWindow()
                         list_widget.setFocus()
                         print(f"Refocused '{parent_submenu_dialog.windowTitle()}' list after message box.")
                     else:
                         print(f"ERROR: Could not find list widget in '{parent_submenu_dialog.windowTitle()}' after message box.")
                         self._schedule_main_menu_focus_restore()
                else:
                     print("Parent submenu no longer visible after message box. Returning to main menu.")
                     self._schedule_main_menu_focus_restore()
            QtCore.QTimer.singleShot(100, refocus_parent)

    def change_module_content(self, index):
        if self._block_signals or index < 0 or index >= len(self.main_modules_data):
            return
        selected_main_item_text, sub_menu_items = self.main_modules_data[index]
        title_text = selected_main_item_text.split(". ", 1)[-1]
        for window in self.active_submenu_windows:
            if window.windowTitle() == title_text:
                window.raise_()
                window.activateWindow()
                return
        if selected_main_item_text == "0. EXIT":
            QtCore.QTimer.singleShot(0, self.close)
            return
        if sub_menu_items:
            self._show_submenu_window(title_text, sub_menu_items, parent_title="MAIN MENU")
        else:
             print(f"Main menu item '{title_text}' selected, but has no defined sub-items.")
             self.module_list.setCurrentRow(-1)

    def show_action_message(self, text):
        msgBox = QtWidgets.QMessageBox(self)
        msgBox.setWindowTitle("Action")
        msgBox.setText(f"Executing: {text}")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok)
        msgBox.exec()

    def keyPressEvent(self, event):
        key = event.key()
        text = event.text().upper()
        focused_widget = self.focusWidget()
        print(f"Key press in main window: {text}, focused: {focused_widget}")
        if focused_widget == self.module_list:
            if text and text.isalnum():
                target_row = -1
                prefix_to_find = text + ". "
                for i, (item_text, _) in enumerate(self.main_modules_data):
                    if item_text.upper().startswith(prefix_to_find):
                        target_row = i
                        break
                if target_row != -1:
                    curr_row = self.module_list.currentRow()
                    print(f"Target row: {target_row}, Current row: {curr_row}")
                    self.module_list.setCurrentRow(target_row)
                    if curr_row == target_row:
                        print("Same row, forcing content update")
                        if not self._block_signals:
                             self.change_module_content(target_row)
                        else:
                             print("Signals blocked, cannot force content update.")
                    event.accept()
                    return
        super().keyPressEvent(event)

    def showEvent(self, event):
        super().showEvent(event)
        QtCore.QTimer.singleShot(0, self._enable_signals)

    def _enable_signals(self):
        self._block_signals = False
        self.module_list.setFocus()
        self.module_list.setCurrentRow(-1)
        self.module_list.blockSignals(False)
        print("Signals enabled and focus set to main menu.") # DEBUG message

    def closeEvent(self, event):
        super().closeEvent(event)

# Example usage
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    dashboard = DashboardSystem(username="Admin", system_type="Administration System")
    dashboard.show()
    sys.exit(app.exec())