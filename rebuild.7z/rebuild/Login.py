import sys
from PyQt5 import QtWidgets, QtGui, QtCore
# Attempt to import the PyQt5 DashboardSystem using relative import
try:
    # Use relative import because Login.py and MainMenu.py are in the same package 'rebuild'
    from .MainMenu import DashboardSystem # <-- MODIFIED: Use relative import
    print("Successfully imported DashboardSystem using relative import.") # Add confirmation
except ImportError as e:
    # This except block should ideally NOT be hit when running with 'python -m rebuild.Login'
    print(f"Warning: Could not import DashboardSystem using relative import '.MainMenu'. Error: {e}")
    print("Falling back to placeholder DashboardSystem.")
    # Define a placeholder if import fails
    class DashboardSystem:
        """Placeholder Dashboard - Used if real import fails.""" # Add docstring for check
        def __init__(self, username, system_type):
            print(f"Placeholder Dashboard: User={username}, System={system_type}")
        def show(self):
            print("Showing placeholder dashboard.")

# --- Define a modern color palette ---
COLOR_PRIMARY_BG = "#F0F4F8"       # Light grayish-blue background
COLOR_SECONDARY_BG = "#FFFFFF"    # White background for form
COLOR_TITLE_BG = "#2C3E50"        # Dark blue for title bar
COLOR_TITLE_TEXT = "#ECF0F1"      # Light text for title bar
COLOR_TEXT_PRIMARY = "#34495E"    # Dark text
COLOR_TEXT_SECONDARY = "#7F8C8D"  # Gray text for labels
COLOR_BORDER = "#BDC3C7"          # Light gray border
COLOR_ACCENT = "#3498DB"          # Blue accent for buttons/focus
COLOR_ACCENT_HOVER = "#2980B9"    # Darker blue for button hover

class LoginSystem(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ICS Dialing System (Administration)")
        self.setFixedSize(400, 280) # Slightly adjusted size
        self.username = ""
        self.password = ""
        self.product_name = "Administration System"
        self.version = "2.5.0"
        self.init_ui()

    def init_ui(self):
        # Set the main window background color
        self.setStyleSheet(f"background-color: {COLOR_PRIMARY_BG};")

        # Main vertical layout
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0) # No margins
        main_layout.setSpacing(0)

        # --- Top Title Bar ---
        title_container = QtWidgets.QWidget()
        title_container.setFixedHeight(35)
        title_container.setStyleSheet(f"background-color: {COLOR_TITLE_BG};")
        title_layout = QtWidgets.QHBoxLayout(title_container)
        title_layout.setContentsMargins(15, 0, 15, 0)
        title = QtWidgets.QLabel("Integrated Credit Services Administration")
        title.setFont(QtGui.QFont("Segoe UI", 10, QtGui.QFont.Bold)) # Modern font
        title.setStyleSheet(f"color: {COLOR_TITLE_TEXT}; background-color: transparent;")
        title_layout.addWidget(title)
        main_layout.addWidget(title_container)

        # --- Central Form Area (using a QWidget with background) ---
        form_area = QtWidgets.QWidget()
        form_area.setStyleSheet(f"background-color: {COLOR_PRIMARY_BG};") # Match main background
        form_layout_container = QtWidgets.QVBoxLayout(form_area)
        # Add padding around the form elements
        form_layout_container.setContentsMargins(30, 25, 30, 25)
        form_layout_container.setSpacing(20) # Increase spacing

        # Form Title (LOGIN)
        login_title = QtWidgets.QLabel("LOGIN")
        login_title.setFont(QtGui.QFont("Segoe UI", 14, QtGui.QFont.Bold))
        login_title.setStyleSheet(f"color: {COLOR_TEXT_PRIMARY}; background-color: transparent;")
        login_title.setAlignment(QtCore.Qt.AlignCenter)
        form_layout_container.addWidget(login_title)

        # Input Fields (using QVBoxLayout for more control)
        input_fields_widget = QtWidgets.QWidget()
        input_layout = QtWidgets.QFormLayout(input_fields_widget)
        input_layout.setContentsMargins(0, 0, 0, 0)
        input_layout.setVerticalSpacing(10) # Spacing between label and input
        input_layout.setLabelAlignment(QtCore.Qt.AlignRight)

        self.username_edit = QtWidgets.QLineEdit()
        self.password_edit = QtWidgets.QLineEdit()
        self.password_edit.setEchoMode(QtWidgets.QLineEdit.Password)

        # Modern Input field style
        input_style = f"""
            QLineEdit {{
                background-color: {COLOR_SECONDARY_BG};
                border: 1px solid {COLOR_BORDER};
                border-radius: 4px; /* Rounded corners */
                padding: 6px 10px; /* More padding */
                font-size: 14px;
                color: {COLOR_TEXT_PRIMARY};
            }}
            QLineEdit:focus {{
                border: 1px solid {COLOR_ACCENT}; /* Highlight border on focus */
            }}
        """
        self.username_edit.setStyleSheet(input_style)
        self.password_edit.setStyleSheet(input_style)
        self.username_edit.setPlaceholderText("Enter username") # Add placeholder text
        self.password_edit.setPlaceholderText("Enter password")

        # Modern Label style
        label_style = f"color: {COLOR_TEXT_SECONDARY}; font-size: 13px; padding-right: 5px;"
        username_label = QtWidgets.QLabel("Username:")
        username_label.setStyleSheet(label_style)
        password_label = QtWidgets.QLabel("Password:")
        password_label.setStyleSheet(label_style)

        input_layout.addRow(username_label, self.username_edit)
        input_layout.addRow(password_label, self.password_edit)

        form_layout_container.addWidget(input_fields_widget) # Add input fields group

        # Buttons Layout
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.setContentsMargins(0, 10, 0, 0) # Add some top margin
        btn_layout.setSpacing(10)

        ok_btn = QtWidgets.QPushButton("OK")
        cancel_btn = QtWidgets.QPushButton("Cancel")

        # Modern Button style
        button_style = f"""
            QPushButton {{
                background-color: {COLOR_ACCENT};
                color: white;
                border: none;
                padding: 8px 16px;
                font-size: 13px;
                border-radius: 4px;
                min-width: 80px;
            }}
            QPushButton:hover {{
                background-color: {COLOR_ACCENT_HOVER};
            }}
            QPushButton:pressed {{
                background-color: {COLOR_ACCENT};
            }}
            QPushButton:default {{
                 border: 2px solid {COLOR_ACCENT_HOVER}; /* Indicate default */
            }}
        """
        ok_btn.setStyleSheet(button_style)
        cancel_btn.setStyleSheet(button_style.replace(COLOR_ACCENT, "#95A5A6").replace(COLOR_ACCENT_HOVER, "#7F8C8D")) # Gray cancel button

        ok_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        ok_btn.setDefault(True)

        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        form_layout_container.addLayout(btn_layout) # Add buttons

        # Add the form area to the main layout
        main_layout.addWidget(form_area, 1) # Allow form area to stretch

        # --- Version Label ---
        version_label = QtWidgets.QLabel(f"(Version {self.version})")
        version_label.setAlignment(QtCore.Qt.AlignCenter)
        # Use secondary text color, transparent background
        version_label.setStyleSheet(f"font-size: 10px; color: {COLOR_TEXT_SECONDARY}; background-color: transparent; padding: 5px;")
        main_layout.addWidget(version_label)

        # Set initial focus
        self.username_edit.setFocus()

    def accept(self):
        self.username = self.username_edit.text().strip()
        self.password = self.password_edit.text().strip()
        if not self.username:
            QtWidgets.QMessageBox.warning(self, "Login", "Missing Login User Name !!")
            self.username_edit.setFocus()
            return
        if not self.password:
             QtWidgets.QMessageBox.warning(self, "Login", "Missing Password !!")
             self.password_edit.setFocus()
             return

        # --- Perform credential check HERE before accepting ---
        # Example: Replace with your actual validation logic
        if self.check_credentials(self.username, self.password):
            super().accept() # Close the dialog only if credentials are valid
        else:
            QtWidgets.QMessageBox.warning(self, "Login Failed", "Invalid username or password.")
            self.password_edit.clear()
            self.password_edit.setFocus()

    def check_credentials(self, username, password):
        """Validates username and password. Replace with real logic."""
        # Dummy check - replace with database lookup or other validation
        # IMPORTANT: Add your actual credential validation here!
        if username == "adm" and password == "adm": # Example credentials
             print(f"Credentials valid for user: {username}")
             return True
        print(f"Credentials invalid for user: {username}")
        return False

    def get_credentials(self):
        # This method might not be strictly needed if validation happens in accept()
        # But keep it if used elsewhere
        return self.username, self.password

# Example usage (Modified to handle potential DashboardSystem issues)
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    login_system = LoginSystem()

    if login_system.exec_() == QtWidgets.QDialog.Accepted:
        username, _ = login_system.get_credentials()
        print(f"Login successful: Username={username}")

        try:
            print("Attempting to import DashboardSystem...")
            from .MainMenu import DashboardSystem
            print("Successfully imported DashboardSystem using relative import.")

            # --- Modified Check for Placeholder ---
            is_placeholder = False
            docstring = getattr(DashboardSystem, '__doc__', None) # Get __doc__, default to None if missing entirely

            # Check if docstring is not None *before* using 'in'
            if docstring is not None and "Placeholder Dashboard" in docstring:
                is_placeholder = True
            # --- End of Modified Check ---

            if is_placeholder:
                print("Imported DashboardSystem appears to be the placeholder.")
                QtWidgets.QMessageBox.warning(None, "Warning",
                                              "The main DashboardSystem module could not be fully loaded (Placeholder detected).\n"
                                              "Please ensure MainMenu.py is correctly implemented.")
                sys.exit(1)

            print("Launching dashboard...")
            dashboard = DashboardSystem(username=username, system_type="Administration System")
            dashboard.show()
            sys.exit(app.exec_()) # Keep app running

        except ImportError as e:
            print(f"ImportError launching dashboard: {e}")
            QtWidgets.QMessageBox.critical(None, "Error", f"Could not import the main application module (MainMenu.py).\n{e}")
            sys.exit(1)
        except Exception as e:
            print(f"Error launching dashboard: {e}")
            # Display the specific error in the message box
            QtWidgets.QMessageBox.critical(None, "Error", f"Could not launch the main application.\n{e}")
            # import traceback # Uncomment for detailed traceback in terminal during dev
            # traceback.print_exc() # Uncomment for detailed traceback in terminal during dev
            sys.exit(1)

    else:
        print("Login cancelled.")
        sys.exit(0)