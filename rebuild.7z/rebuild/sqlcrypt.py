import os
import pyodbc
import base64
from dotenv import load_dotenv

# --- Imports from backup_sqlcrypt.py ---
import myCrypt as myCrypt # Needed for hashing inside encrypt/decrypt
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
# --- End imports from backup_sqlcrypt.py ---

# Load environment variables (can be loaded once at application start)
# load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '..', '.env')) # Optional: Load here or ensure loaded by caller

# --- connect_to_mssql from backup_sqlcrypt.py ---
def connect_to_mssql():
    """Connects to MSSQL using credentials from environment variables."""
    try:
        server = os.environ.get('DB_SERVER')
        database = os.environ.get('DB_DATABASE') # Use DB_DATABASE as in current sqlcrypt
        username = os.environ.get('DB_USERNAME')
        password = os.environ.get('DB_PASSWORD')
        driver = os.environ.get('DB_DRIVER', '{ODBC Driver 17 for SQL Server}') # Keep default driver
        trust_certificate = os.environ.get('DB_TRUST_CERTIFICATE', 'no').lower() == 'true' # Keep boolean conversion

        # --- DEBUG PRINTS (optional but kept for consistency) ---
        print("--- sqlcrypt.connect_to_mssql (from backup) ---")
        print(f"  Attempting connection with:")
        print(f"  Server: {server}")
        print(f"  Database: {database}")
        print(f"  Username: {username}")
        print(f"  Driver: {driver}")
        print(f"  TrustServerCertificate: {trust_certificate}")
        # --- END DEBUG PRINTS ---

        if not all([server, database, username, password, driver]):
             print("  ERROR: Missing one or more DB connection parameters in environment variables.")
             return None

        conn_str = (
            f"DRIVER={driver};"
            f"SERVER={server};"
            f"DATABASE={database};"
            f"UID={username};"
            f"PWD={password};"
        )
        # Add TrustServerCertificate based on the flag
        if trust_certificate:
            conn_str += "TrustServerCertificate=yes;"
        else:
             conn_str += "TrustServerCertificate=no;" # Keep explicit 'no'

        print(f"  Connection String: {conn_str}") # DEBUG

        conn = pyodbc.connect(conn_str)
        print("  Database connection successful (from sqlcrypt - backup version).") # DEBUG
        return conn

    except pyodbc.Error as ex:
        sqlstate = ex.args[0]
        print(f"  ERROR connecting to database (sqlcrypt - backup version): SQLSTATE={sqlstate} - {ex}")
        return None
    except Exception as e:
        print(f"  ERROR connecting to database (sqlcrypt - backup version): Unexpected error - {e}")
        return None

# --- sql_encrypt_with_iv from backup_sqlcrypt.py ---
def sql_encrypt_with_iv(plain_text, key=None, debug=False):
    """
    Encrypt data with IV stored at the beginning of the encrypted content.
    Format: IV + Encrypted Data, then base64 encoded

    Args:
        plain_text: The text to encrypt
        key: The encryption key (string or bytes). If string, it's hashed.
        debug: Whether to print debug information

    Returns:
        Base64 encoded string containing IV + encrypted data, or None if input is empty.
    """
    if not plain_text:
        return None

    try:
        # If key is a string, convert to bytes and hash it to get 32 bytes
        if key and isinstance(key, str):
            key_bytes = myCrypt.hashlib.sha256(key.encode('utf-8')).digest()
        elif isinstance(key, bytes):
             key_bytes = key # Use bytes key directly
        elif not key:
             # Generate a random key if none provided (or raise error depending on policy)
             print("WARN: No key provided for encryption, generating random key.")
             key_bytes = get_random_bytes(32) # AES-256 key
        else:
            raise TypeError("Encryption key must be string or bytes.")

        if debug:
            print(f"Encryption key (bytes used, hex): {key_bytes.hex()}")
            print(f"Plain text length: {len(plain_text)} characters")

        # Generate a random IV
        iv = get_random_bytes(16)  # AES block size is 16 bytes

        # Create cipher and encrypt
        cipher = AES.new(key_bytes, AES.MODE_CBC, iv)
        padded_data = pad(plain_text.encode('utf-8'), AES.block_size)
        encrypted_data = cipher.encrypt(padded_data)

        # Combine IV + encrypted data and base64 encode
        combined = iv + encrypted_data
        result = base64.b64encode(combined).decode('utf-8')

        if debug:
            print(f"IV size: {len(iv)} bytes")
            print(f"IV (hex): {iv.hex()}")
            print(f"Encrypted data size: {len(encrypted_data)} bytes")
            print(f"Total binary size: {len(combined)} bytes")
            print(f"Base64 result length: {len(result)} characters")

        return result
    except Exception as e:
        print(f"Error encrypting with IV: {e}")
        return None


# --- sql_decrypt_with_iv from backup_sqlcrypt.py ---
def sql_decrypt_with_iv(cipher_text, key=None, debug=False):
    """
    Decrypt data where IV is stored at the beginning of the encrypted content.
    Expected format: base64(IV + Encrypted Data)

    Args:
        cipher_text: Base64 encoded string containing IV + encrypted data
        key: The encryption key (string or bytes). If string, it's hashed.
        debug: Whether to print debug information

    Returns:
        Decrypted text (UTF-8 decoded), or None if decryption fails.
    """
    if not cipher_text:
        if debug: print("DEBUG: sql_decrypt_with_iv - Input cipher_text is empty.")
        return None

    try:
        # If key is a string, convert to bytes and hash it to get 32 bytes
        if key and isinstance(key, str):
            key_bytes = myCrypt.hashlib.sha256(key.encode('utf-8')).digest()
        elif isinstance(key, bytes):
            key_bytes = key # Use bytes key directly
        elif not key:
            raise ValueError("Decryption key must be provided")
        else:
             raise TypeError("Decryption key must be string or bytes.")

        if debug:
            print(f"Decryption key (bytes used, hex): {key_bytes.hex()}")
            print(f"Encrypted text length: {len(cipher_text)} characters")

        # Decode the base64 data
        encrypted_data_with_iv = base64.b64decode(cipher_text)

        if debug:
            print(f"Decoded binary size: {len(encrypted_data_with_iv)} bytes")

        # AES block size is 16 bytes (128 bits)
        iv_size = 16
        if len(encrypted_data_with_iv) <= iv_size:
            if debug: print(f"DEBUG: sql_decrypt_with_iv - Data length ({len(encrypted_data_with_iv)}) not greater than IV size ({iv_size}).")
            return None # Data must be longer than IV

        # Extract IV (first 16 bytes) and ciphertext
        iv = encrypted_data_with_iv[:iv_size]
        ciphertext = encrypted_data_with_iv[iv_size:]

        if debug:
            print(f"IV size: {len(iv)} bytes")
            print(f"IV (hex): {iv.hex()}")
            print(f"Encrypted data size: {len(ciphertext)} bytes")

        # Create cipher and decrypt
        cipher = AES.new(key_bytes, AES.MODE_CBC, iv)
        decrypted_padded = cipher.decrypt(ciphertext)

        # Unpad and return
        result = unpad(decrypted_padded, AES.block_size).decode('utf-8')

        if debug:
            print(f"Decrypted text length: {len(result)} characters")

        return result
    except (ValueError, base64.binascii.Error) as e:
        # Handle incorrect base64 or padding errors specifically
        print(f"ERROR: sql_decrypt_with_iv - Decryption failed (ValueError/Base64Error/PaddingError): {e}")
        return None
    except Exception as e:
        # Handle other potential errors during decryption
        print(f"ERROR: sql_decrypt_with_iv - Unexpected decryption error: {e}")
        return None

# --- You might want to keep other functions from the original sqlcrypt.py if needed ---
# --- Or remove the old ones if they are fully replaced ---