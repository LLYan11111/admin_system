from PyQt5 import QtWidgets, QtCore, QtGui
import datetime
import random
import json 
import os
import sys
import pyodbc
from dotenv import load_dotenv

# 載入環境變數
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(dotenv_path)

# 資料庫連接設定
DB_SERVER = os.environ.get('DB_SERVER')
DB_USERNAME = os.environ.get('DB_USERNAME')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_DATABASE = os.environ.get('DB_DATABASE')
DB_TRUST_CERTIFICATE = os.environ.get('DB_TRUST_CERTIFICATE', 'no').lower() == 'true'
DB_DRIVER = os.environ.get('DB_DRIVER', '{ODBC Driver 17 for SQL Server}')

# JSON 檔案路徑 (僅保留 PRINT_CODES_FILE 用於列印碼)
PRINT_CODES_FILE = r"c:\Users\johnny\Desktop\Dialing\print_codes.json" 

def connect_to_database():
    """連接到 MSSQL 資料庫"""
    try:
        conn_str = (
            f"DRIVER={DB_DRIVER};"
            f"SERVER={DB_SERVER};"
            f"DATABASE={DB_DATABASE};"
            f"UID={DB_USERNAME};"
            f"PWD={DB_PASSWORD};"
        )
        
        # 根據設置添加 TrustServerCertificate
        if DB_TRUST_CERTIFICATE:
            conn_str += "TrustServerCertificate=yes;"
        else:
            conn_str += "TrustServerCertificate=no;"
            
        conn = pyodbc.connect(conn_str)
        return conn
    except pyodbc.Error as e:
        print(f"資料庫連接錯誤: {e}")
        return None
    except Exception as e:
        print(f"未知錯誤: {e}")
        return None

class CodeGeneratorWindow(QtWidgets.QDialog):
    """提供三個按鈕的界面，用於產生和查看代碼"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.setWindowTitle("Code Generator")
        self.setMinimumWidth(300)
        self.setFixedHeight(150)  # 固定高度更美觀
        
        # 禁用 ? 按鈕
        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)
        
        # 設定布局
        layout = QtWidgets.QVBoxLayout()
        layout.setContentsMargins(1, 1, 1, 1)  # 減少佈局邊距
        layout.setSpacing(1)  # 減少按鈕間距
        
        # 創建三個按鈕
        self.btn_today_code = QtWidgets.QPushButton("1. Get Today Code")
        self.btn_print_code = QtWidgets.QPushButton("2. Get Print Code")
        self.btn_show_today_code = QtWidgets.QPushButton("3. Show Today Code")
        
        # 更強烈的移除邊框樣式
        button_style = """
            QPushButton {
                background-color: #c0c0c0;
                border: 0px none !important;
                border-width: 0px !important;
                border-style: none !important;
                outline: 0px !important;
                color: black;
                padding: 8px;
                text-align: left;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #d0d0d0;
                border: 0px none !important;
            }
            QPushButton:pressed {
                background-color: #b0b0b0;
                border: 0px none !important;
            }
            QPushButton:focus {
                border: 0px none !important;
                outline: 0px !important;
            }
        """
        
        # 套用按鈕樣式
        self.btn_today_code.setStyleSheet(button_style)
        self.btn_print_code.setStyleSheet(button_style)
        self.btn_show_today_code.setStyleSheet(button_style)
        
        # 通過程式碼直接設定按鈕屬性以移除邊框
        for btn in [self.btn_today_code, self.btn_print_code, self.btn_show_today_code]:
            btn.setFlat(True)  # 設置為平面按鈕
            btn.setAutoFillBackground(True)  # 允許自動填充背景
        
        # 添加按鈕到布局
        layout.addWidget(self.btn_today_code)
        layout.addWidget(self.btn_print_code)
        layout.addWidget(self.btn_show_today_code)
        
        # 設定布局
        self.setLayout(layout)
        
        # 連接按鈕信號到槽函數
        self.btn_today_code.clicked.connect(self.on_today_code_clicked)
        self.btn_print_code.clicked.connect(self.on_print_code_clicked)
        self.btn_show_today_code.clicked.connect(self.on_show_today_code_clicked)
        
        # 設定整個對話框的樣式，包括清除邊框
        self.setStyleSheet("""
            QDialog {
                background-color: #d4d0c8;
                border: none;
            }
            /* 確保對話框內所有按鈕都沒有邊框 */
            QPushButton {
                border: 0px none !important;
            }
        """)

    def on_today_code_clicked(self):
        """處理 Get Today Code 按鈕點擊"""
        # 驗證密碼
        if self.verify_password():
            # 密碼正確，調用生成函數
            generate_today_code(self)
    
    def on_print_code_clicked(self):
        """處理 Get Print Code 按鈕點擊"""
        # 驗證密碼
        if self.verify_password():
            # 密碼正確，調用生成函數
            generate_print_code(self)
    
    def on_show_today_code_clicked(self):
        """處理 Show Today Code 按鈕點擊"""
        # 不需要密碼驗證
        show_today_code(self)
    
    def verify_password(self):
        """顯示密碼輸入對話框並驗證密碼"""
        input_dialog = QtWidgets.QInputDialog(self)
        input_dialog.setWindowTitle("Password Required")
        input_dialog.setLabelText("Enter password:")
        input_dialog.setTextEchoMode(QtWidgets.QLineEdit.Password)
        input_dialog.setOkButtonText("OK")
        input_dialog.setCancelButtonText("Cancel")
        
        # 設定最小寬度和樣式
        input_dialog.setMinimumWidth(350)
        input_dialog.setStyleSheet("""
            QInputDialog {
                background-color: #d4d0c8;
                border: none !important; 
            }
            QInputDialog QLabel {
                color: black;
                border: none !important;
                background-color: transparent;
            }
            QInputDialog QLineEdit {
                background-color: white;
                border: 0px solid black !important;
                border-width: 0px !important;
                border-style: none !important;
                outline: none !important;
                color: black;
            }
            QInputDialog QPushButton {
                color: black;
                background-color: #c0c0c0;
                border: 0px solid black !important;
                border-width: 0px !important;
                border-style: none !important;
                outline: none !important;
                padding: 5px;
                min-width: 60px;
            }
        """)
        
        # 顯示對話框後，找到並直接修改子元件的樣式
        def post_dialog_show():
            for child in input_dialog.findChildren(QtWidgets.QLineEdit):
                child.setStyleSheet("border: 0px; background-color: white;")
            for child in input_dialog.findChildren(QtWidgets.QPushButton):
                child.setStyleSheet("border: 0px; background-color: #c0c0c0;")
        
        QtCore.QTimer.singleShot(10, post_dialog_show)
        
        result = input_dialog.exec_()
        
        if result == QtWidgets.QDialog.Accepted:
            password = input_dialog.textValue()
            if password == "adm":
                return True
            else:
                QtWidgets.QMessageBox.warning(self, "Error", "Incorrect password.")
                return False
        else:
            return False

def generate_today_code(parent_window):
    """
    自動產生今日的授權碼 (隨機6位數字)，在訊息框中顯示，
    並將其儲存到資料庫的 suser 表的 PASSWORD 欄位中。
    """
    # 1. 產生 TodayKey (隨機6位數字)
    today_key_raw = "".join([str(random.randint(0, 9)) for _ in range(6)])
    generation_time = datetime.datetime.now()

    # 2. 儲存到資料庫
    try:
        # 連接到資料庫
        conn = connect_to_database()
        if not conn:
            QtWidgets.QMessageBox.critical(parent_window, "資料庫連接錯誤", "無法連接到資料庫，請檢查連接設置。")
            return
            
        cursor = conn.cursor()
        
        # 更新 suser 表中的 PASSWORD 欄位
        cursor.execute("UPDATE [ICSBK_2].[dbo].[suser] SET PASSWORD = ?", today_key_raw)
        conn.commit()
        conn.close()
        
        print(f"今日代碼已更新到資料庫: {today_key_raw}")

    except pyodbc.Error as e:
        # 資料庫儲存錯誤時，仍然顯示代碼，但提示錯誤
        QtWidgets.QMessageBox.warning(parent_window, "資料庫儲存錯誤", f"儲存代碼到資料庫失敗: {e}\n產生的代碼仍會顯示。")
        print(f"資料庫儲存錯誤: {e}")
        return
    except Exception as e:
        QtWidgets.QMessageBox.critical(parent_window, "未知錯誤", f"儲存代碼時發生未知錯誤: {e}\n產生的代碼仍會顯示。")
        print(f"未知錯誤: {e}")
        return

    # 3. 顯示產生的代碼在訊息框中
    show_code_message_box(parent_window, "Supervisor password for admin/dialing changed to :", today_key_raw)

def generate_print_code(parent_window):
    """
    自動產生列印代碼 (隨機6位數字)，在訊息框中顯示，
    並將其記錄到 JSON 檔案 (覆蓋舊內容)。
    """
    # 1. 產生 PrintCode (隨機6位數字)
    print_code_raw = "".join([str(random.randint(0, 9)) for _ in range(6)])
    generation_time = datetime.datetime.now()

    # 2. 準備要儲存到 JSON 的資料
    new_code_entry = {
        "generated_at": generation_time.strftime('%Y-%m-%d %H:%M:%S'),
        "print_code": print_code_raw
    }

    # 3. 儲存到 JSON 檔案 (覆蓋模式)
    try:
        # 建立一個只包含當前新記錄的列表
        data_to_save = [new_code_entry] 
        
        # 直接以寫入模式開啟檔案，這會覆蓋現有檔案或建立新檔案
        with open(PRINT_CODES_FILE, 'w', encoding='utf-8') as f:
            json.dump(data_to_save, f, indent=4, ensure_ascii=False)
        
        print(f"列印代碼已儲存至 {PRINT_CODES_FILE} (已覆蓋舊記錄)")

    except IOError as e:
        # 檔案儲存錯誤時，仍然顯示代碼，但提示錯誤
        QtWidgets.QMessageBox.warning(parent_window, "檔案儲存錯誤", f"儲存代碼到檔案失敗: {e}\n產生的代碼仍會顯示。")
        print(f"檔案儲存錯誤: {e}")
        return
    except Exception as e:
        QtWidgets.QMessageBox.critical(parent_window, "未知錯誤", f"儲存代碼時發生未知錯誤: {e}\n產生的代碼仍會顯示。")
        print(f"未知錯誤: {e}")
        return

    # 4. 顯示產生的代碼在訊息框中
    show_code_message_box(parent_window, "Print code changed to :", print_code_raw)

def show_today_code(parent_window):
    """
    從資料庫的 suser 表讀取 PASSWORD 欄位並顯示。
    """
    try:
        # 連接到資料庫
        conn = connect_to_database()
        if not conn:
            QtWidgets.QMessageBox.critical(parent_window, "資料庫連接錯誤", "無法連接到資料庫，請檢查連接設置。")
            return
            
        cursor = conn.cursor()
        
        # 查詢 suser 表中的 PASSWORD 欄位
        cursor.execute("SELECT PASSWORD, CREATEDATE FROM [ICSBK_2].[dbo].[suser]")
        row = cursor.fetchone()
        conn.close()
        
        if not row or not row[0]:
            QtWidgets.QMessageBox.warning(parent_window, "無代碼記錄", "資料庫中沒有找到今日代碼。")
            return
            
        # 獲取密碼和最後修改日期
        today_key = row[0]
        created_date = row[1] if len(row) > 1 and row[1] else "未知時間"
        
        # 格式化日期時間（如果是 datetime 對象）
        if isinstance(created_date, datetime.datetime):
            created_date = created_date.strftime('%Y-%m-%d %H:%M:%S')
        
        # 顯示代碼
        message = f"Today code (last updated: {created_date}):"
        show_code_message_box(parent_window, message, today_key)
        
    except pyodbc.Error as e:
        QtWidgets.QMessageBox.critical(parent_window, "資料庫錯誤", f"讀取資料庫時發生錯誤: {e}")
        print(f"資料庫錯誤: {e}")
    except Exception as e:
        QtWidgets.QMessageBox.critical(parent_window, "未知錯誤", f"讀取今日代碼時發生錯誤: {e}")
        print(f"未知錯誤: {e}")

def show_code_message_box(parent_window, message_prefix, code):
    """
    顯示一個帶有特定樣式的訊息框，用於顯示生成的代碼。
    """
    title = "ICS Dialing System (Administration)"
    message = f"{message_prefix}\n\n{code}"
    
    msg_box = QtWidgets.QMessageBox(parent_window)
    msg_box.setWindowTitle(title)
    msg_box.setText(message)
    msg_box.setIcon(QtWidgets.QMessageBox.Information)
    msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)

    # 新增更強力的自訂 QSS
    qmessagebox_style = """
        QMessageBox {
            background-color: #d4d0c8;
            border: none !important; 
        }
        QMessageBox QLabel { /* 針對所有訊息文字 */
            color: black;
            background-color: transparent; 
            border: none !important;
        }
        
        /* 特別針對包含圖示的 QLabel */
        QMessageBox QLabel#qt_msgbox_icon_label,
        QMessageBox QLabel#qt_msgboxex_icon_label {
            border: none !important;
            background: transparent !important;
            padding: 0px !important;
            margin: 0px !important;
        }
        
        /* 針對圖示 */
        QMessageBox QPixmap {
            border: none !important;
            background: transparent !important;
        }
        
        QMessageBox QPushButton { /* 針對按鈕 */
            background-color: #c0c0c0; /* 按鈕使用稍深一點的灰色 */
            border: 0px solid black !important;
            border-width: 0px !important;
            border-style: none !important;
            outline: none !important;
            padding: 5px;
            min-width: 60px;
            color: black;
        }
        QMessageBox QPushButton:hover {
            background-color: #d0d0d0;
        }
        QMessageBox QPushButton:pressed {
            background-color: #b0b0b0;
        }
    """
    msg_box.setStyleSheet(qmessagebox_style)
    
    # 顯示後處理：找到並直接修改所有元件的樣式
    def post_msgbox_setup():
        # 1. 修改所有按鈕邊框
        for btn in msg_box.findChildren(QtWidgets.QPushButton):
            btn.setStyleSheet("border: 0px; background-color: #c0c0c0;")
        
        # 2. 特別尋找並處理圖示標籤
        for label in msg_box.findChildren(QtWidgets.QLabel):
            # 檢查是否是圖示標籤（通常大小較小且包含圖示）
            if label.pixmap() and not label.text():
                # 完全移除圖示標籤的邊框和背景
                label.setStyleSheet("border: none; background: none; padding: 0px; margin: 0px;")
                label.setContentsMargins(0, 0, 0, 0)
    
    # 使用計時器確保在對話框顯示後執行
    QtCore.QTimer.singleShot(10, post_msgbox_setup)
    
    msg_box.exec_()

def generate_today_code_dialog(parent_window=None):
    """
    創建並顯示代碼生成器對話框
    """
    dialog = CodeGeneratorWindow(parent_window)
    dialog.exec_()

if __name__ == '__main__':
    # 直接運行此模塊時顯示對話框
    app = QtWidgets.QApplication([])
    generate_today_code_dialog()