import sys
import datetime
from PyQt5 import QtWidgets, QtCore, QtGui

# --- Style Constants (Updated to match Batch.py, keeping Report specifics) ---
# Fonts (from Batch.py)
BASE_FONT = "'Segoe UI', Arial"
FONT_SIZE_NORMAL = "13px"
FONT_SIZE_SMALL = "11px" # Added from Batch.py
FONT_SIZE_LARGE = "16px" # Updated from Batch.py

# Basic Colors (Updated from Batch.py, content background now matches Batch.py)
COLOR_WINDOW_BACKGROUND = "#F5F5F5" # Updated from Batch.py
COLOR_CONTENT_BACKGROUND = "#FFFFFF" # Changed from "#C0C0C0" to match Batch.py (White)
COLOR_BORDER = "#CCCCCC" # Updated from Batch.py
COLOR_TEXT_PRIMARY = "#222222" # Updated from Batch.py
COLOR_TEXT_SECONDARY = "#555555" # Updated from Batch.py
COLOR_ACCENT = "#0078D4" # Updated from Batch.py
COLOR_ACCENT_HOVER = "#005A9E" # Added from Batch.py
COLOR_ACCENT_PRESSED = "#004C87" # Added from Batch.py
COLOR_TABLE_HEADER_BG = "#E1E1E1" # Added from Batch.py (for potential future use)
COLOR_TABLE_HEADER_FG = "#333333" # Added from Batch.py (for potential future use)

# --- Input Style (Updated with new constants) ---
INPUT_STYLE = f"""
    QLineEdit {{
        background-color: white; /* Keep white background for inputs */
        border: 1px solid {COLOR_BORDER};
        border-radius: 3px; /* Match Batch.py radius */
        padding: 4px 6px; /* Match Batch.py padding */
        color: {COLOR_TEXT_PRIMARY};
        font-family: {BASE_FONT};
        font-size: {FONT_SIZE_NORMAL};
        selection-background-color: {COLOR_ACCENT};
        selection-color: white;
    }}
    QLineEdit:focus {{
        border: 1px solid {COLOR_ACCENT};
    }}
    QLineEdit[readOnly="true"] {{
        background-color: #E0E0E0; /* Keep slightly different gray for read-only */
    }}
"""

# --- Label Style (Updated with new constants) ---
# Keep bold for Report labels as per original Report.py style
LABEL_STYLE = f"color: {COLOR_TEXT_PRIMARY}; font-family: {BASE_FONT}; font-size: {FONT_SIZE_NORMAL}; font-weight: bold;"

# --- Standard Button Style (Updated with new constants, keeping Report's size/padding) ---
BUTTON_STYLE = f"""
    QPushButton {{
        background-color: #E1E1E1; /* Match Batch.py */
        color: {COLOR_TEXT_PRIMARY};
        border: 1px solid {COLOR_BORDER}; /* Match Batch.py border */
        /* Keep the 3D effect from original Report.py button */
        border-top-color: #FFFFFF;
        border-left-color: #FFFFFF;
        border-radius: 3px; /* Match Batch.py */
        padding: 5px 15px; /* Keep Report's padding */
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 25px; /* Keep Report's height */
        min-width: 150px; /* Keep Report's width */
        outline: none;
    }}
    QPushButton:hover {{
        background-color: #D1D1D1; /* Match Batch.py */
        border-color: #BDBDBD; /* Match Batch.py hover border */
    }}
    QPushButton:pressed {{
        background-color: #C1C1C1; /* Match Batch.py */
        /* Keep the pressed 3D effect from original Report.py button */
        border-top-color: #808080;
        border-left-color: #808080;
        border-bottom-color: #FFFFFF;
        border-right-color: #FFFFFF;
    }}
    QPushButton:disabled {{
        background-color: #EFEFEF; /* Match Batch.py */
        color: #AAAAAA; /* Match Batch.py */
    }}
"""

# --- Function Key Button Style (Updated with new constants) ---
FUNC_KEY_BUTTON_STYLE = f"""
    QPushButton {{
        background-color: #D4D0C8; /* Match Batch.py */
        color: black;
        border: 1px solid #808080; /* Match Batch.py border */
        border-top-color: #FFFFFF; /* Match Batch.py 3D effect */
        border-left-color: #FFFFFF; /* Match Batch.py 3D effect */
        padding: 3px 8px; /* Match Batch.py padding */
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 20px; /* Match Batch.py height */
        min-width: 70px; /* Match Batch.py width */
        outline: none; /* Remove focus outline */
    }}
    QPushButton:pressed {{
        background-color: #C0C0C0; /* Match Batch.py pressed */
        border-color: #404040; /* Match Batch.py pressed border */
        border-top-color: #808080; /* Match Batch.py pressed 3D effect */
        border-left-color: #808080; /* Match Batch.py pressed 3D effect */
    }}
"""

# --- Checkbox Style (Updated with new constants) ---
CHECKBOX_STYLE = f"""
    QCheckBox {{
        spacing: 5px; /* Space between checkbox and text */
        color: {COLOR_TEXT_PRIMARY};
        font-family: {BASE_FONT};
        font-size: {FONT_SIZE_NORMAL};
    }}
    QCheckBox::indicator {{
        width: 15px; /* Keep slightly larger indicator */
        height: 15px;
        border: 1px solid {COLOR_BORDER};
        background-color: white;
    }}
    QCheckBox::indicator:checked {{
        background-color: {COLOR_ACCENT};
        border: 1px solid {COLOR_ACCENT};
        /* image: url(check.png); Optional: Add a checkmark image */
    }}
    QCheckBox::indicator:unchecked:hover {{
        border: 1px solid {COLOR_ACCENT};
    }}
"""

class CaseEntryReportDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._configure_window()
        self._create_widgets()
        self._create_layout()
        self._apply_styles()
        self._connect_signals()

    def _configure_window(self):
        self.setWindowTitle("Case Entry Report")
        self.setMinimumSize(480, 380) # Slightly adjusted size
        # Use updated background color
        self.setStyleSheet(f"background-color: {COLOR_WINDOW_BACKGROUND};")

    def _create_widgets(self):
        # --- Title ---
        self.title_label = QtWidgets.QLabel("Case Entry Report")
        self.title_label.setAlignment(QtCore.Qt.AlignCenter)
        # Use updated font constants and COLOR_ACCENT for background
        self.title_label.setStyleSheet(f"""
            background-color: {COLOR_ACCENT}; /* Changed from black to COLOR_ACCENT */
            color: white;
            font-size: {FONT_SIZE_LARGE};
            font-weight: bold;
            padding: 6px 10px; /* Adjusted padding to match Batch.py */
            font-family: {BASE_FONT};
        """)

        # --- Action Bar ---
        self.esc_button = QtWidgets.QPushButton("ESC - Exit")

        # --- Content Area ---
        self.content_widget = QtWidgets.QWidget() # Container for the gray area
        self.content_widget.setObjectName("contentWidget") # For specific styling

        # Form Fields
        self.refno_from_label = QtWidgets.QLabel("Refno From")
        self.refno_from_edit = QtWidgets.QLineEdit()
        self.refno_to_label = QtWidgets.QLabel("to")
        self.refno_to_edit = QtWidgets.QLineEdit()

        self.client_label = QtWidgets.QLabel("Client")
        self.client_edit = QtWidgets.QLineEdit("***") # Default value

        self.assign_date_from_label = QtWidgets.QLabel("Assign Date From")
        self.assign_date_from_edit = QtWidgets.QLineEdit()
        self.assign_date_from_edit.setInputMask("99 / 99 / 9999") # Date mask
        self.assign_date_to_label = QtWidgets.QLabel("to")
        self.assign_date_to_edit = QtWidgets.QLineEdit()
        self.assign_date_to_edit.setInputMask("99 / 99 / 9999") # Date mask
        today_str = datetime.date.today().strftime("%m/%d/%Y")
        self.assign_date_to_edit.setText(today_str) # Default to today

        self.use_collector_checkbox = QtWidgets.QCheckBox("Use Current Collector")

        # Action Buttons
        self.layout_button = QtWidgets.QPushButton("Layout")
        self.display_button = QtWidgets.QPushButton("3. Display Report")
        self.print_button = QtWidgets.QPushButton("4. Print Report")

    def _create_layout(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # --- Title ---
        main_layout.addWidget(self.title_label)

        # --- Action Bar ---
        action_bar_widget = QtWidgets.QWidget()
        action_bar_layout = QtWidgets.QHBoxLayout(action_bar_widget)
        action_bar_layout.setContentsMargins(5, 3, 5, 3)
        action_bar_layout.addWidget(self.esc_button)
        action_bar_layout.addStretch()
        # Use updated border color
        action_bar_widget.setStyleSheet(f"background-color: #D4D0C8; border-bottom: 1px solid {COLOR_BORDER};")
        main_layout.addWidget(action_bar_widget)

        # --- Content Area ---
        content_layout = QtWidgets.QVBoxLayout(self.content_widget)
        content_layout.setContentsMargins(20, 20, 20, 20) # Padding inside gray area
        content_layout.setSpacing(15)

        # Form Grid
        form_grid_layout = QtWidgets.QGridLayout()
        form_grid_layout.setHorizontalSpacing(10)
        form_grid_layout.setVerticalSpacing(10)

        form_grid_layout.addWidget(self.refno_from_label, 0, 0)
        form_grid_layout.addWidget(self.refno_from_edit, 0, 1)
        form_grid_layout.addWidget(self.refno_to_label, 0, 2, QtCore.Qt.AlignCenter)
        form_grid_layout.addWidget(self.refno_to_edit, 0, 3)

        form_grid_layout.addWidget(self.client_label, 1, 0)
        form_grid_layout.addWidget(self.client_edit, 1, 1)

        form_grid_layout.addWidget(self.assign_date_from_label, 2, 0)
        form_grid_layout.addWidget(self.assign_date_from_edit, 2, 1)
        form_grid_layout.addWidget(self.assign_date_to_label, 2, 2, QtCore.Qt.AlignCenter)
        form_grid_layout.addWidget(self.assign_date_to_edit, 2, 3)
        form_grid_layout.addWidget(self.use_collector_checkbox, 2, 4, QtCore.Qt.AlignLeft)

        # Set column stretch (make input fields expand more)
        form_grid_layout.setColumnStretch(1, 1)
        form_grid_layout.setColumnStretch(3, 1)
        form_grid_layout.setColumnStretch(4, 0) # Checkbox column takes minimum space

        content_layout.addLayout(form_grid_layout)
        content_layout.addSpacing(20) # Space before buttons

        # Action Buttons Layout
        button_layout = QtWidgets.QVBoxLayout()
        button_layout.setSpacing(10)
        button_layout.addWidget(self.layout_button, 0, QtCore.Qt.AlignCenter)
        button_layout.addWidget(self.display_button, 0, QtCore.Qt.AlignCenter)
        button_layout.addWidget(self.print_button, 0, QtCore.Qt.AlignCenter)
        content_layout.addLayout(button_layout)

        content_layout.addStretch() # Push content upwards

        main_layout.addWidget(self.content_widget)

    def _apply_styles(self):
        # Apply specific styles (using updated style constants)
        self.esc_button.setStyleSheet(FUNC_KEY_BUTTON_STYLE)
        self.layout_button.setStyleSheet(BUTTON_STYLE)
        self.display_button.setStyleSheet(BUTTON_STYLE)
        self.print_button.setStyleSheet(BUTTON_STYLE)

        # Apply global styles to children of content_widget (using updated style constants)
        # The background-color will now use the updated COLOR_CONTENT_BACKGROUND (#FFFFFF)
        self.content_widget.setStyleSheet(f"""
            #contentWidget {{
                background-color: {COLOR_CONTENT_BACKGROUND}; /* Now uses white */
                border: 1px solid {COLOR_BORDER}; /* Use updated border color */
                border-top: none; /* Remove top border as it's covered by action bar */
            }}
            QLabel {{ {LABEL_STYLE} }}
            QLineEdit {{ {INPUT_STYLE} }}
            QCheckBox {{ {CHECKBOX_STYLE} }}
        """)
        # Re-apply specific button styles to ensure they override any potential
        # general QPushButton style if it were applied globally (it's not in this case, but good practice)
        self.layout_button.setStyleSheet(BUTTON_STYLE)
        self.display_button.setStyleSheet(BUTTON_STYLE)
        self.print_button.setStyleSheet(BUTTON_STYLE)

    def _connect_signals(self):
        self.esc_button.clicked.connect(self.reject) # Close dialog on ESC click
        # Connect other buttons to their respective functions (placeholders)
        # self.layout_button.clicked.connect(self.handle_layout)
        # self.display_button.clicked.connect(self.handle_display)
        # self.print_button.clicked.connect(self.handle_print)

    def keyPressEvent(self, event):
        # Close dialog if Escape key is pressed
        if event.key() == QtCore.Qt.Key_Escape:
            self.reject()
        else:
            super().keyPressEvent(event)

    # --- Placeholder Slots ---
    # def handle_layout(self):
    #     print("Layout button clicked")

    # def handle_display(self):
    #     print("Display Report button clicked")

    # def handle_print(self):
    #     print("Print Report button clicked")


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    dialog = CaseEntryReportDialog()
    dialog.show()
    sys.exit(app.exec_())