import sys
from PyQt5 import QtWidgets, QtGui, QtCore
from datetime import datetime
from decimal import Decimal, InvalidOperation # <-- Import Decimal
# --- Imports needed for data fetching/decryption ---
import base64
import re # <-- Ensure re is imported
import os
import pyodbc
from dotenv import load_dotenv


# --- Use Direct Imports for files in the same directory ---
import_error_message = None
try:
    # Import directly since they are in the same 'rebuild' directory
    import sqlcrypt
    import myCrypt
    import CaseList # Direct import
    print("Successfully imported local modules (sqlcrypt, myCrypt, CaseList).")
except ImportError as e:
    error_msg = f"ERROR: Failed direct import: {e}. Ensure sqlcrypt.py, myCrypt.py, and CaseList.py are in the 'rebuild' directory."
    print(error_msg)
    import_error_message = error_msg
    # Set placeholders if imports fail
    sqlcrypt = None
    myCrypt = None
    CaseList = None

# --- Load .env file ---
# Assuming .env is directly in 'rebuild'
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
if not os.path.exists(dotenv_path):
    print(f"ERROR: .env file not found at {dotenv_path}")
    if not import_error_message: # Don't overwrite existing import error
         import_error_message = f".env file not found at the expected location: {dotenv_path}"
else:
    load_dotenv(dotenv_path=dotenv_path)
    print(f".env file loaded from {dotenv_path}")


# --- Configuration from test.py (can be moved to a config module) ---
KEY_ID_TO_USE = 1
BASE64_REGEX = re.compile(r'^[A-Za-z0-9+/]*={0,2}$')
MIN_ENCRYPTED_LEN = 24
# --- End Configuration ---


# ===== Updated Constants for Styles =====
BASE_FONT = "'Segoe UI', Arial"
FONT_SIZE_NORMAL = "13px"
FONT_SIZE_SMALL = "11px"
FONT_SIZE_LARGE = "16px"

COLOR_BACKGROUND = "#F5F5F5" # Light gray background
COLOR_CONTENT_BACKGROUND = "#FFFFFF" # White for content areas
COLOR_BORDER = "#CCCCCC" # Light gray border
COLOR_TEXT_PRIMARY = "#222222" # Dark gray text
COLOR_TEXT_SECONDARY = "#555555" # Medium gray text
COLOR_ACCENT = "#0078D4" # Blue accent
COLOR_ACCENT_HOVER = "#005A9E"
COLOR_ACCENT_PRESSED = "#004C87"
COLOR_TABLE_HEADER_BG = "#E1E1E1" # Light gray table header
COLOR_TABLE_HEADER_FG = "#333333"
COLOR_TABLE_ALT_ROW = "#F0F8FF" # Light blue for alternating rows

# ===== Updated Styles =====
INPUT_STYLE = f"""
    background-color: {COLOR_CONTENT_BACKGROUND};
    border: 1px solid {COLOR_BORDER};
    border-radius: 3px;
    padding: 4px 6px;
    color: {COLOR_TEXT_PRIMARY};
    font-family: {BASE_FONT};
    font-size: {FONT_SIZE_NORMAL};
    selection-background-color: {COLOR_ACCENT};
    selection-color: white;
"""
LABEL_STYLE = f"color: {COLOR_TEXT_PRIMARY}; font-family: {BASE_FONT}; font-size: {FONT_SIZE_NORMAL}; font-weight: bold;"
BUTTON_STYLE = f"""
    QPushButton {{
        background-color: #E1E1E1;
        color: {COLOR_TEXT_PRIMARY};
        border: 1px solid {COLOR_BORDER};
        border-radius: 3px;
        padding: 5px 10px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 20px; /* Ensure minimum height */
    }}
    QPushButton:hover {{
        background-color: #D1D1D1;
        border-color: #BDBDBD;
    }}
    QPushButton:pressed {{
        background-color: #C1C1C1;
    }}
    QPushButton:disabled {{
        background-color: #EFEFEF;
        color: #AAAAAA;
    }}
"""
ACTIVE_TAB_STYLE = f"""
    QPushButton {{
        background-color: {COLOR_ACCENT};
        color: white;
        border: 1px solid {COLOR_ACCENT};
        border-bottom: 2px solid {COLOR_CONTENT_BACKGROUND}; /* Blend bottom border */
        border-radius: 3px 3px 0 0; /* Rounded top corners */
        padding: 5px 10px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        font-weight: bold;
        min-height: 20px;
    }}
"""
INACTIVE_TAB_STYLE = f"""
    QPushButton {{
        background-color: #E1E1E1;
        color: {COLOR_TEXT_SECONDARY};
        border: 1px solid {COLOR_BORDER};
        border-bottom: 1px solid {COLOR_BORDER}; /* Ensure bottom border matches */
        border-radius: 3px 3px 0 0;
        padding: 5px 10px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 20px;
    }}
    QPushButton:hover {{
        background-color: #D1D1D1;
    }}
"""

TABLE_HEADER_STYLE = f"""
    QHeaderView::section {{
        background-color: {COLOR_TABLE_HEADER_BG};
        color: {COLOR_TABLE_HEADER_FG};
        padding: 4px;
        border: 1px solid {COLOR_BORDER};
        font-weight: bold;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
    }}
"""
TABLE_STYLE = f"""
    QTableWidget {{
        background-color: {COLOR_CONTENT_BACKGROUND};
        color: {COLOR_TEXT_PRIMARY};
        gridline-color: {COLOR_BORDER};
        border: 1px solid {COLOR_BORDER};
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        alternate-background-color: {COLOR_TABLE_ALT_ROW}; /* Zebra striping */
    }}
    QTableWidget::item {{
        padding: 4px;
        border-bottom: 1px solid {COLOR_BORDER}; /* Lighter border between rows */
        border-right: 1px dotted {COLOR_BORDER}; /* Dotted border between columns */
    }}
    QTableWidget::item:selected {{
        background-color: {COLOR_ACCENT};
        color: white;
    }}
"""
# Simplified Data Table Styles (assuming they are similar to regular tables now)
DATA_TABLE_STYLE = TABLE_STYLE
DATA_TABLE_HEADER_STYLE = TABLE_HEADER_STYLE # Reuse header style

class CaseEnquiry(QtWidgets.QDialog):
    """
    案件查詢對話框 - 用於查看和管理案件詳細信息的主界面。
    提供多個詳細信息頁面，用於顯示案件的不同方面。
    """

    # ===== INITIALIZATION METHODS =====
    def __init__(self, parent=None):
        """初始化 CaseEnquiry 對話框"""
        super().__init__(parent)
        self.setWindowTitle("Case Enquiry")
        self._configure_window()
        # Initialize detail page widgets to None initially
        self._initialize_detail_widgets() # Keep this
        self.init_ui() # Call init_ui after initializing widgets

    def _configure_window(self):
        """配置窗口的基本屬性 (大小, 樣式, 標誌)"""
        # Increased width from 805 to 880
        self.setFixedSize(880, 850) # Consider if fixed size is truly needed, maybe allow resizing?
        self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.FramelessWindowHint) # Frameless might hinder usability (moving/resizing)

        # --- Updated Global Stylesheet ---
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {COLOR_BACKGROUND};
                border: 1px solid {COLOR_BORDER}; /* Lighter border for the dialog */
                border-radius: 5px; /* Softer corners */
            }}
            QWidget {{ /* Apply base font to all widgets */
                font-family: {BASE_FONT};
                font-size: {FONT_SIZE_NORMAL};
            }}
            QLabel {{ {LABEL_STYLE} }}
            QLineEdit, QTextEdit, QListWidget {{ {INPUT_STYLE} }}
            /* Style for read-only fields */
            QLineEdit:read-only, QTextEdit:read-only {{
                background-color: #E9E9E9; /* Lighter gray for read-only */
                /* border: 1px solid #D0D0D0; */ /* Optional: different border */
            }}
            QCheckBox {{
                color: {COLOR_TEXT_PRIMARY};
                font-size: {FONT_SIZE_NORMAL};
                spacing: 5px; /* Space between box and text */
            }}
            QCheckBox::indicator {{
                width: 15px;
                height: 15px;
            }}
            QTableWidget {{
                /* Base table styles are in TABLE_STYLE */
                 {TABLE_STYLE} /* Apply base table style */
            }}
            QHeaderView::section {{ /* Style for default table headers */
                {TABLE_HEADER_STYLE}
            }}
            /* Apply base button style globally */
            {BUTTON_STYLE}
        """)

    def _initialize_detail_widgets(self):
        """將所有詳細頁面的屬性初始化為 None"""
        # Keep references for Detail 1 parts
        self.financial_area = None
        self.data_table_area = None
        self.bottom_area = None
        # Keep references for other pages
        self.payment_area = None
        self.payment_summary_area = None # Detail 2 part 2
        self.personal_info_area = None
        self.company_info_area = None
        self.block_info_area = None
        self.detail_code_area = None
        self.case_history_area = None
        self.transfer_info_area = None
        # Add containers for multi-part pages
        self.detail1_container = None
        self.detail2_container = None

    def init_ui(self):
        """初始化用戶界面組件"""
        self.main_layout = QtWidgets.QVBoxLayout(self) # Store reference to main layout
        self.main_layout.setContentsMargins(1, 1, 1, 1) # Reduce margins for frameless look
        self.main_layout.setSpacing(0) # No spacing between main sections

        # --- UI Components (Fixed Sections) ---
        self.title_bar = self.create_title_bar()
        self.ref_row = self.create_ref_row()
        self.form_area = self.create_form_area() # Ensure row stretch is applied here
        self.tab_area = self.create_tab_area()

        # --- Stacked Widget for Detail Pages ---
        self.stacked_widget = QtWidgets.QStackedWidget()

        # --- Create and Add Detail Page 1 Container ---
        self.detail1_container = QtWidgets.QWidget()
        detail1_layout = QtWidgets.QVBoxLayout(self.detail1_container)
        detail1_layout.setContentsMargins(0, 0, 0, 0)
        detail1_layout.setSpacing(0) # No spacing within detail page parts
        # Call the methods to create the parts of Detail 1
        self.financial_area = self.create_financial_area()
        self.data_table_area = self.create_data_table_area()
        self.bottom_area = self.create_bottom_area()
        # Add the parts to the container's layout
        detail1_layout.addWidget(self.financial_area)
        detail1_layout.addWidget(self.data_table_area)
        detail1_layout.addWidget(self.bottom_area)
        self.stacked_widget.addWidget(self.detail1_container) # Add page 1 container to stack

        # --- Add Components to Main Layout ---
        self.main_layout.addWidget(self.title_bar)
        self.main_layout.addWidget(self.ref_row)
        self.main_layout.addWidget(self.form_area)
        self.main_layout.addWidget(self.tab_area)
        self.main_layout.addWidget(self.stacked_widget) # Add the stack
        self.main_layout.addStretch(1) # Add stretch at the bottom

        # --- Initial Page Display ---
        self.show_detail_page(1) # Show Detail 1 by default

    # ===== MAIN UI COMPONENT CREATION METHODS =====
    def create_title_bar(self):
        """創建標題欄 (使用純色背景)"""
        title_widget = QtWidgets.QWidget()
        title_widget.setFixedHeight(40)
        # --- Updated Title Bar Style ---
        title_widget.setStyleSheet(f"""
            background-color: {COLOR_ACCENT}; /* Use accent color */
            border-top-left-radius: 5px; /* Match dialog radius */
            border-top-right-radius: 5px;
            border-bottom: 1px solid {COLOR_BORDER}; /* Separator line */
        """)

        title_layout = QtWidgets.QHBoxLayout(title_widget)
        title_layout.setContentsMargins(15, 0, 15, 0)

        title_label = QtWidgets.QLabel("Case Enquiry")
        # --- Updated Title Label Style ---
        title_label.setStyleSheet(f"color: white; font-size: {FONT_SIZE_LARGE}; font-weight: bold;")

        keys_label = QtWidgets.QLabel("F3-Edit | F4-Del | F5-Brow | F6-Goto")
        # --- Updated Keys Label Style ---
        keys_label.setStyleSheet(f"color: #FFFFFF; font-size: {FONT_SIZE_SMALL};")

        esc_label = QtWidgets.QLabel("ESC-Exit")
        # --- Updated Esc Label Style ---
        esc_label.setStyleSheet(f"color: #FFFFFF; font-size: {FONT_SIZE_SMALL};")

        self.mode_label = QtWidgets.QLabel("VIEW")
        self.mode_label.setObjectName("mode_label")
        # --- Updated Mode Label Style ---
        self.mode_label.setStyleSheet(f"color: white; font-size: {FONT_SIZE_NORMAL}; font-weight: bold; padding: 2px 8px; background-color: rgba(255, 255, 255, 0.2); border-radius: 3px;")
        self.mode_label.setAlignment(QtCore.Qt.AlignCenter)

        title_layout.addWidget(title_label)
        title_layout.addStretch()
        title_layout.addWidget(self.mode_label)
        title_layout.addStretch()
        title_layout.addWidget(keys_label)
        title_layout.addSpacing(20)
        title_layout.addWidget(esc_label)

        return title_widget

    def create_ref_row(self):
        """創建頂部參考編號行"""
        ref_widget = QtWidgets.QWidget()
        ref_widget.setFixedHeight(35) # Slightly taller
        # --- Updated Ref Row Style ---
        ref_widget.setStyleSheet(f"background-color: {COLOR_TABLE_HEADER_BG}; border-bottom: 1px solid {COLOR_BORDER};")

        ref_layout = QtWidgets.QHBoxLayout(ref_widget)
        ref_layout.setContentsMargins(8, 0, 8, 0) # Add some horizontal margin
        ref_layout.setSpacing(5) # Add spacing between elements

        # Helper to create label/input pairs
        def create_field(label_text, input_width, input_value=None):
            label = QtWidgets.QLabel(label_text)
            # --- Updated Ref Field Label Style ---
            label.setStyleSheet(f"color: {COLOR_TEXT_SECONDARY}; font-size: {FONT_SIZE_SMALL}; font-weight: bold; padding-right: 5px;")
            label.setAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignRight)
            input_field = QtWidgets.QLineEdit()
            input_field.setFixedWidth(input_width)
            # --- Use global INPUT_STYLE (applied via _configure_window) ---
            # input_field.setStyleSheet(INPUT_STYLE)
            input_field.setStyleSheet(f"""
                background-color: {COLOR_CONTENT_BACKGROUND}; /* Set background to white */
                border: 1px solid {COLOR_BORDER};
                border-radius: 3px;
                padding: 4px 6px;
                color: {COLOR_TEXT_PRIMARY};
                font-family: {BASE_FONT};
                font-size: {FONT_SIZE_NORMAL};
                selection-background-color: {COLOR_ACCENT};
                selection-color: white;
            """)
            if input_value:
                input_field.setText(input_value)
            return label, input_field

        # --- Assign widgets to self (These remain editable) ---
        ref_label, self.ref_input = create_field("Ref:", 70, "0")
        no_label, self.no_field = create_field("No:", 140)
        name_label, self.name_field = create_field("Name:", 230)
        hkid_label, self.hkid_field = create_field("HKID:", 115)
        # --- End Assignment ---

        # --- Connect returnPressed signal for Ref input ---
        self.ref_input.returnPressed.connect(self._fetch_and_display_case_by_ref)
        # --- End Connection ---

        # Use QHBoxLayout for better alignment and spacing control
        ref_layout.addWidget(ref_label)
        ref_layout.addWidget(self.ref_input)
        ref_layout.addSpacing(10)
        ref_layout.addWidget(no_label)
        ref_layout.addWidget(self.no_field)
        ref_layout.addSpacing(10)
        ref_layout.addWidget(name_label)
        ref_layout.addWidget(self.name_field)
        ref_layout.addSpacing(10)
        ref_layout.addWidget(hkid_label)
        ref_layout.addWidget(self.hkid_field)
        ref_layout.addStretch() # Push elements to the left

        return ref_widget

    def create_form_area(self):
        """創建主要表單區域，包含客戶信息"""
        form_widget = QtWidgets.QWidget()
        # --- Updated Form Area Style ---
        form_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-bottom: 1px solid {COLOR_BORDER};")

        form_layout = QtWidgets.QGridLayout(form_widget)
        form_layout.setContentsMargins(15, 15, 15, 15) # Increased margins
        form_layout.setHorizontalSpacing(15) # Increased spacing
        form_layout.setVerticalSpacing(10) # Increased spacing

        # Helper to add label and widget
        def add_form_field(label_text, widget, row, col, col_span=1, label_alignment=QtCore.Qt.AlignLeft):
            label = QtWidgets.QLabel(label_text)
            label.setAlignment(label_alignment | QtCore.Qt.AlignVCenter)
            form_layout.addWidget(label, row, col * 2)
            form_layout.addWidget(widget, row, col * 2 + 1, 1, col_span * 2 -1 if col_span > 1 else 1)
            # Input style applied globally

        # --- Fields (Assign to self and set ReadOnly) ---
        self.ref_no = QtWidgets.QLineEdit(); self.ref_no.setFixedWidth(120); self.ref_no.setReadOnly(True)
        self.client_code = QtWidgets.QLineEdit(); self.client_code.setFixedWidth(120); self.client_code.setReadOnly(True)
        self.ac_name = QtWidgets.QLineEdit(); self.ac_name.setFixedWidth(250); self.ac_name.setReadOnly(True)
        self.ac_no = QtWidgets.QLineEdit(); self.ac_no.setFixedWidth(250); self.ac_no.setReadOnly(True)
        self.chinese = QtWidgets.QLineEdit(); self.chinese.setFixedWidth(200); self.chinese.setReadOnly(True)
        self.english = QtWidgets.QLabel("N"); self.english.setFixedWidth(40); self.english.setAlignment(QtCore.Qt.AlignCenter)
        self.sex = QtWidgets.QLineEdit(); self.sex.setFixedWidth(40); self.sex.setReadOnly(True)
        self.currency = QtWidgets.QLineEdit(); self.currency.setFixedWidth(80); self.currency.setReadOnly(True)
        self.loan_type = QtWidgets.QLineEdit(); self.loan_type.setFixedWidth(80); self.loan_type.setReadOnly(True)
        self.date_assign = QtWidgets.QLineEdit(); self.date_assign.setFixedWidth(120); self.date_assign.setPlaceholderText("MM/DD/YYYY"); self.date_assign.setReadOnly(True)
        self.collector = QtWidgets.QLineEdit(); self.collector.setFixedWidth(120); self.collector.setReadOnly(True)
        self.status = QtWidgets.QLineEdit(); self.status.setFixedWidth(120); self.status.setReadOnly(True)
        self.card_type = QtWidgets.QLineEdit(); self.card_type.setFixedWidth(120); self.card_type.setReadOnly(True)
        self.id_no = QtWidgets.QLineEdit(); self.id_no.setFixedWidth(180); self.id_no.setReadOnly(True)
        self.corp = QtWidgets.QLabel("N"); self.corp.setFixedWidth(40); self.corp.setAlignment(QtCore.Qt.AlignCenter)
        self.debtor_id = QtWidgets.QLineEdit(); self.debtor_id.setFixedWidth(180); self.debtor_id.setReadOnly(True)
        # --- End Assignment ---

        # --- Layout (Use self.widget_name) ---
        add_form_field("Ref No", self.ref_no, 0, 0)
        add_form_field("Client Code", self.client_code, 1, 0)
        add_form_field("A/C name", self.ac_name, 2, 0, col_span=2)
        add_form_field("A/C no.", self.ac_no, 3, 0, col_span=2)
        add_form_field("Chinese", self.chinese, 4, 0, col_span=1)
        add_form_field("English", self.english, 5, 0)
        add_form_field("Sex", self.sex, 6, 0)
        # Moved Currency back to row 6, col 1
        add_form_field("Currency", self.currency, 6, 1)
        # Removed Currency from row 7

        add_form_field("Loan Type", self.loan_type, 1, 1)

        add_form_field("Date Assign", self.date_assign, 0, 2)
        add_form_field("Collector", self.collector, 1, 2)
        add_form_field("Status", self.status, 2, 2)
        add_form_field("Card Type", self.card_type, 3, 2)
        add_form_field("I.D no.", self.id_no, 4, 2)
        add_form_field("Corp", self.corp, 5, 2)
        add_form_field("Debtor ID", self.debtor_id, 6, 2) # Debtor ID remains in row 6, col 2
        # --- End Layout ---

        # Set column stretch factors
        form_layout.setColumnStretch(1, 1) # Widget column 1
        form_layout.setColumnStretch(3, 1) # Widget column 2
        form_layout.setColumnStretch(5, 1) # Widget column 3

        # Add row stretch to the row *after* the last content row
        # This pushes all content upwards and absorbs extra vertical space.
        last_content_row = 7 # The highest row index used is 6, so the next row is 7
        form_layout.setRowStretch(last_content_row, 1)

        return form_widget

    def create_tab_area(self):
        """創建細節標籤頁按鈕區域"""
        tab_widget = QtWidgets.QWidget()
        tab_widget.setFixedHeight(40) # Slightly taller for better click target
        # --- Updated Tab Area Style ---
        tab_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-bottom: 1px solid {COLOR_BORDER};")

        tab_layout = QtWidgets.QHBoxLayout(tab_widget)
        tab_layout.setContentsMargins(8, 0, 8, 0) # Margin at bottom is handled by border
        tab_layout.setSpacing(2) # Spacing between tabs

        self.detail_buttons = []
        for i in range(1, 9):
            btn = QtWidgets.QPushButton(f"Detail {i}")
            # btn.setFixedSize(80, 30) # Let buttons size naturally or set min-width
            btn.setMinimumWidth(75)
            btn.setStyleSheet(INACTIVE_TAB_STYLE) # Start all as inactive
            btn.setCheckable(True) # Make tabs checkable for easier state management (optional)
            btn.clicked.connect(lambda checked, idx=i: self.show_detail_page(idx))
            self.detail_buttons.append(btn)
            tab_layout.addWidget(btn)

        tab_layout.addStretch()
        return tab_widget

    # ===== DETAIL PAGE MANAGEMENT =====
    def show_detail_page(self, page_number):
        """根據頁面編號顯示對應的詳細頁面內容 (using QStackedWidget)"""
        # Update button styles
        for i, btn in enumerate(self.detail_buttons):
            is_active = (i + 1 == page_number)
            btn.setStyleSheet(ACTIVE_TAB_STYLE if is_active else INACTIVE_TAB_STYLE)

        # --- Get or Create the target widget/container ---
        target_widget = None
        if page_number == 1:
            target_widget = self.detail1_container # Already created in init_ui
        elif page_number == 2:
            # Detail 2 has two parts, group them in a container
            if self.detail2_container is None:
                self.detail2_container = QtWidgets.QWidget()
                layout = QtWidgets.QVBoxLayout(self.detail2_container)
                layout.setContentsMargins(0,0,0,0)
                layout.setSpacing(0)
                # Ensure parts are created and added to the container's layout
                # Pass add_to_stack=False because they belong to the container, not directly to the stack
                self.payment_area = self._ensure_widget_exists('payment_area', self.create_payment_area, add_to_stack=False)
                self.payment_summary_area = self._ensure_widget_exists('payment_summary_area', self.create_payment_summary_area, add_to_stack=False)
                layout.addWidget(self.payment_area)
                layout.addWidget(self.payment_summary_area)
                self.stacked_widget.addWidget(self.detail2_container) # Add container to stack
            target_widget = self.detail2_container
        elif page_number == 3:
            target_widget = self._ensure_widget_exists('personal_info_area', self.create_personal_info_area)
        elif page_number == 4:
            target_widget = self._ensure_widget_exists('company_info_area', self.create_company_info_area)
        elif page_number == 5:
            target_widget = self._ensure_widget_exists('block_info_area', self.create_block_info_area)
        elif page_number == 6:
            target_widget = self._ensure_widget_exists('detail_code_area', self.create_detail_code_area)
        elif page_number == 7:
            target_widget = self._ensure_widget_exists('case_history_area', self.create_case_history_area)
        elif page_number == 8:
            target_widget = self._ensure_widget_exists('transfer_info_area', self.create_transfer_info_area)

        # --- Switch the visible page in the stack ---
        if target_widget:
            self.stacked_widget.setCurrentWidget(target_widget)
        else:
            # This might happen if a create_* method failed or returned None
            print(f"Error: Could not find or create widget/container for page {page_number}")

    def _ensure_widget_exists(self, attr_name, create_method, add_to_stack=True):
        """如果控件不存在，則創建它。可選地添加到 QStackedWidget。"""
        widget = getattr(self, attr_name, None)
        if widget is None:
            # Check if create_method is callable
            if not callable(create_method):
                 print(f"Error: {create_method.__name__} is not callable or defined correctly.")
                 return None # Or raise an error

            widget = create_method() # Call the creation method
            if widget is None: # Check if create_method returned None unexpectedly
                print(f"Error: {create_method.__name__} returned None.")
                return None

            # Apply consistent background (might be redundant if set in create_method)
            # It's generally better to set styles within the create methods themselves
            # widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
            setattr(self, attr_name, widget) # Store the created widget

            if add_to_stack:
                # Add the widget to the QStackedWidget
                self.stacked_widget.addWidget(widget)
        return widget

    # ===== DETAIL PAGE CREATION METHODS =====

    def create_financial_area(self):
        """創建財務信息區域 (Detail 1 - Part 1)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};") # Set background
        layout = QtWidgets.QGridLayout(widget) # Use GridLayout for structure
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # --- Assign Fields to self and set ReadOnly ---
        self.ass_amt_input = QtWidgets.QLineEdit("0.00"); self.ass_amt_input.setReadOnly(True)
        self.late_fee_input = QtWidgets.QLineEdit("0.00"); self.late_fee_input.setReadOnly(True)
        self.interest_oa_checkbox = QtWidgets.QCheckBox("OA") # Mapped to INTERESTOA
        self.interest_input = QtWidgets.QLineEdit("0.00"); self.interest_input.setReadOnly(True)
        self.os_amt_oa_checkbox = QtWidgets.QCheckBox("OA") # Mapped to OTHERSOA? Verify mapping.

        self.legal_fee_input = QtWidgets.QLineEdit("0.00"); self.legal_fee_input.setReadOnly(True)
        self.oahers_input = QtWidgets.QLineEdit("0.00"); self.oahers_input.setReadOnly(True)
        self.legal_oa_checkbox = QtWidgets.QCheckBox("OA") # Mapped to LEGALOA
        self.os_amt_input = QtWidgets.QLineEdit("0.00"); self.os_amt_input.setReadOnly(True)
        self.latefee_oa_checkbox = QtWidgets.QCheckBox("OA") # Mapped to LATEFEEOA

        self.commission_input = QtWidgets.QLineEdit("0.00"); self.commission_input.setReadOnly(True)
        self.comm_rate_input = QtWidgets.QLineEdit("0.00"); self.comm_rate_input.setReadOnly(True)
        self.total_balance_input = QtWidgets.QLineEdit("0.00"); self.total_balance_input.setReadOnly(True)

        self.all_billed_button = QtWidgets.QPushButton("All Billed") # Mapped to ALLBILLED
        self.discounted_amt_input = QtWidgets.QLineEdit("0.00"); self.discounted_amt_input.setReadOnly(True)
        self.dis_end_date_input = QtWidgets.QLineEdit(); self.dis_end_date_input.setPlaceholderText("MM/DD/YYYY"); self.dis_end_date_input.setReadOnly(True)
        self.charging_order_checkbox = QtWidgets.QCheckBox("Charging Order") # Need DB field mapping
        # --- End Assignment ---

        # --- Layout (Use self.widget_name) ---
        layout.addWidget(QtWidgets.QLabel("Ass. Amt:"), 0, 0)
        layout.addWidget(self.ass_amt_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Late Fee:"), 0, 2)
        layout.addWidget(self.late_fee_input, 0, 3)
        layout.addWidget(self.interest_oa_checkbox, 0, 4) # Checkbox for Interest OA
        layout.addWidget(QtWidgets.QLabel("Interest:"), 0, 5)
        layout.addWidget(self.interest_input, 0, 6)
        layout.addWidget(self.os_amt_oa_checkbox, 0, 7) # Checkbox for O/S Amt OA (Verify mapping)

        layout.addWidget(QtWidgets.QLabel("Legal Fee:"), 1, 0)
        layout.addWidget(self.legal_fee_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("OAhers:"), 1, 2) # Typo? Should be "Others"?
        layout.addWidget(self.oahers_input, 1, 3)
        layout.addWidget(self.legal_oa_checkbox, 1, 4) # Checkbox for Legal OA
        layout.addWidget(QtWidgets.QLabel("O/S Amt:"), 1, 5)
        layout.addWidget(self.os_amt_input, 1, 6)
        layout.addWidget(self.latefee_oa_checkbox, 1, 7) # Checkbox for Late Fee OA

        layout.addWidget(QtWidgets.QLabel("Commission:"), 2, 0)
        layout.addWidget(self.commission_input, 2, 1)
        layout.addWidget(QtWidgets.QLabel("Comm Rate:"), 2, 2)
        layout.addWidget(self.comm_rate_input, 2, 3)
        layout.addWidget(QtWidgets.QLabel("Total Balance:"), 2, 5)
        layout.addWidget(self.total_balance_input, 2, 6)

        layout.addWidget(self.all_billed_button, 3, 0)
        layout.addWidget(QtWidgets.QLabel("Discounted Amt:"), 3, 2)
        layout.addWidget(self.discounted_amt_input, 3, 3)
        layout.addWidget(QtWidgets.QLabel("Dis. End Date:"), 3, 5)
        layout.addWidget(self.dis_end_date_input, 3, 6)
        layout.addWidget(self.charging_order_checkbox, 3, 7)
        # --- End Layout ---

        # Add stretch to push content up if needed, or manage row/column stretches
        layout.setRowStretch(4, 1) # Add stretch below the last row
        layout.setColumnStretch(8, 1) # Add stretch after the last column

        return widget

    def create_data_table_area(self):
        """創建數據表格區域 (Detail 1 - Part 2)，包含 Linked/Package 摘要和列表"""
        # Main widget for this entire area (summary + main table)
        area_widget = QtWidgets.QWidget()
        # Use background color for the container to ensure consistency
        area_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        area_layout = QtWidgets.QVBoxLayout(area_widget)
        # Reduced top margin, increased bottom margin slightly
        area_layout.setContentsMargins(15, 5, 15, 10)
        area_layout.setSpacing(10) # Spacing between summary and main table
        

        # --- Linked/Package Data Table (Modified) ---
        # Changed column count from 8 to 9
        self.main_data_table = QtWidgets.QTableWidget(0, 9) # Assign to self, start with 0 rows
        # Changed header labels
        self.main_data_table.setHorizontalHeaderLabels([
            "Refno", "Bank", "A/C No.", "Ass Amt",
            "Col", "CT", "ST", "O/S Amt", "Balance"
        ])
        
        # Apply Table Styles (Matching Detail 2 Table)
        self.main_data_table.horizontalHeader().setStyleSheet(DATA_TABLE_HEADER_STYLE)
        self.main_data_table.verticalHeader().setVisible(False) # Hide row numbers
        self.main_data_table.setAlternatingRowColors(True)
        self.main_data_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.main_data_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers) # Read-only
        self.main_data_table.horizontalHeader().setStretchLastSection(True) # Stretch last column like Detail 2

        # Remove or comment out fixed column widths to allow stretching 
        self.main_data_table.setColumnWidth(0, 120)  # Refno
        self.main_data_table.setColumnWidth(1, 50)  # Client Code
        self.main_data_table.setColumnWidth(2, 200) # A/C No.
        self.main_data_table.setColumnWidth(3, 90)  # Ass Amt
        self.main_data_table.setColumnWidth(4, 40)  # Col
        self.main_data_table.setColumnWidth(5, 30)  # CT
        self.main_data_table.setColumnWidth(6, 30)  # ST
        self.main_data_table.setColumnWidth(7, 90)  # O/S Amt
        self.main_data_table.setColumnWidth(8, 10)  # Balance

        # Set a minimum height for the main table to avoid it collapsing
        self.main_data_table.setMinimumHeight(100) # Adjust as needed

        # --- Linked/Package Summary Area ---
        # ... (existing summary area code remains unchanged) ...
        summary_widget = QtWidgets.QWidget()
        # summary_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};") # Background set on parent
        summary_layout = QtWidgets.QVBoxLayout(summary_widget) # Use QVBoxLayout for header + table
        summary_layout.setContentsMargins(0, 0, 0, 0) # No internal margins for the summary widget itself
        summary_layout.setSpacing(0) # No spacing between header and table rows

        # Header Labels for Summary Table
        header_layout = QtWidgets.QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(0) # No spacing between header labels

        # Define header labels and their approximate widths (adjust as needed)
        # Widths adjusted slightly based on image proportions
        headers = [(" ", 65), ("No.", 45), ("Ass. Amt", 95), ("All Others", 95),
                   ("Commission", 95), ("Total Paid", 95), ("Total O/S", 95),
                   ("Total Balance", 95), (" ", 30)] # Added spacer for "**"

        # Create and add header labels
        for idx, (text, width) in enumerate(headers):
            lbl = QtWidgets.QLabel(text)
            lbl.setFixedWidth(width)
            lbl.setAlignment(QtCore.Qt.AlignCenter)
            # Style similar to table headers but slightly different background/border
            lbl_style = f"""
                background-color: {COLOR_TABLE_HEADER_BG};
                color: {COLOR_TABLE_HEADER_FG};
                font-weight: bold;
                font-size: {FONT_SIZE_SMALL}; /* Smaller font for summary header */
                padding: 3px;
                border-top: 1px solid {COLOR_BORDER};
                border-bottom: 1px solid {COLOR_BORDER};
                border-right: 1px solid {COLOR_BORDER};
            """
            if idx == 0: # First label needs left border
                 lbl_style += f"border-left: 1px solid {COLOR_BORDER};"
            lbl.setStyleSheet(lbl_style)
            header_layout.addWidget(lbl)
        # header_layout.addStretch() # Removed stretch as fixed widths are used

        summary_layout.addLayout(header_layout) # Add header row to summary layout

        # --- Data Rows for Summary (Using QGridLayout for precise alignment) ---
        summary_grid_widget = QtWidgets.QWidget()
        summary_grid_layout = QtWidgets.QGridLayout(summary_grid_widget)
        summary_grid_layout.setContentsMargins(0,0,0,0)
        summary_grid_layout.setSpacing(0)

        row_labels = ["Linked", "Package"]
        default_values = ["0", "0.00", "0.00", "0.00", "0.00", "0.00", "0.00"]

        # --- Assign summary labels to self ---
        self.linked_no_label = None
        self.linked_ass_amt_label = None
        self.linked_all_others_label = None
        self.linked_commission_label = None
        self.linked_total_paid_label = None
        self.linked_total_os_label = None
        self.linked_total_balance_label = None
        self.package_no_label = None
        self.package_ass_amt_label = None
        self.package_all_others_label = None
        self.package_commission_label = None
        self.package_total_paid_label = None
        self.package_total_os_label = None
        self.package_total_balance_label = None
        # --- End Assignment ---

        for r, row_label_text in enumerate(row_labels):
            # Row Label
            row_lbl = QtWidgets.QLabel(row_label_text)
            row_lbl.setFixedWidth(headers[0][1]) # Match first header width
            row_lbl.setAlignment(QtCore.Qt.AlignCenter)
            row_lbl.setStyleSheet(f"""
                background-color: {COLOR_TABLE_HEADER_BG};
                color: {COLOR_TABLE_HEADER_FG};
                font-weight: bold;
                font-size: {FONT_SIZE_NORMAL};
                padding: 4px;
                border-left: 1px solid {COLOR_BORDER};
                border-bottom: 1px solid {COLOR_BORDER};
                border-right: 1px solid {COLOR_BORDER};
            """)
            summary_grid_layout.addWidget(row_lbl, r, 0)

            # Data Fields
            current_row_labels = []
            for c, default_val in enumerate(default_values):
                data_lbl = QtWidgets.QLabel(default_val)
                data_lbl.setFixedWidth(headers[c+1][1]) # Match corresponding header width
                data_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
                data_lbl.setStyleSheet(f"""
                    background-color: {COLOR_CONTENT_BACKGROUND};
                    color: {COLOR_TEXT_PRIMARY};
                    font-size: {FONT_SIZE_NORMAL};
                    padding: 4px;
                    border-bottom: 1px solid {COLOR_BORDER};
                    border-right: 1px solid {COLOR_BORDER};
                """)
                summary_grid_layout.addWidget(data_lbl, r, c + 1)
                current_row_labels.append(data_lbl) # Store label reference

            # Assign labels to self attributes based on row
            if r == 0: # Linked row
                self.linked_no_label = current_row_labels[0]
                self.linked_ass_amt_label = current_row_labels[1]
                self.linked_all_others_label = current_row_labels[2]
                self.linked_commission_label = current_row_labels[3]
                self.linked_total_paid_label = current_row_labels[4]
                self.linked_total_os_label = current_row_labels[5]
                self.linked_total_balance_label = current_row_labels[6]
            elif r == 1: # Package row
                self.package_no_label = current_row_labels[0]
                self.package_ass_amt_label = current_row_labels[1]
                self.package_all_others_label = current_row_labels[2]
                self.package_commission_label = current_row_labels[3]
                self.package_total_paid_label = current_row_labels[4]
                self.package_total_os_label = current_row_labels[5]
                self.package_total_balance_label = current_row_labels[6]

            # "**" Label
            star_lbl = QtWidgets.QLabel("**")
            star_lbl.setFixedWidth(headers[8][1]) # Match last header width
            star_lbl.setAlignment(QtCore.Qt.AlignCenter)
            star_lbl.setStyleSheet(f"""
                background-color: {COLOR_TABLE_HEADER_BG}; /* Match header background */
                color: red;
                font-weight: bold;
                font-size: {FONT_SIZE_NORMAL};
                padding: 4px;
                border-bottom: 1px solid {COLOR_BORDER};
                border-right: 1px solid {COLOR_BORDER};
            """)
            summary_grid_layout.addWidget(star_lbl, r, 8)

        summary_layout.addWidget(summary_grid_widget) # Add grid layout to the main summary layout

        # --- Add Widgets to Layout (Reversed Order) ---
        area_layout.addWidget(self.main_data_table) # Add the main table FIRST
        area_layout.addWidget(summary_widget) # Add the complete summary widget SECOND
        area_layout.addStretch() # Add stretch to push tables up if area is larger

        return area_widget # Return the widget containing both summary and main table

    

    def create_bottom_area(self):
        """創建底部信息區域 (Detail 1 - Part 3)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-top: 1px solid {COLOR_BORDER};") # Add top border
        widget.setFixedHeight(50) # Example fixed height
        layout = QtWidgets.QHBoxLayout(widget)
        layout.setContentsMargins(15, 5, 15, 5)
        layout.setSpacing(10)

        # --- Assign Buttons to self (if needed for interaction) ---
        # self.f8_more_button = QtWidgets.QPushButton("F8 - More")
        # self.ctrl_f8_phone_button = QtWidgets.QPushButton("Ctrl+F8 - Phone")
        # # --- End Assignment ---

        # layout.addWidget(self.f8_more_button)
        # layout.addWidget(self.ctrl_f8_phone_button)
        layout.addStretch() # Push buttons to the left

        return widget

    def create_payment_area(self):
        """創建付款信息區域 (Detail 2 - Part 1)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # --- Assign Fields to self and set ReadOnly ---
        self.total_paid_input = QtWidgets.QLineEdit("0.00"); self.total_paid_input.setReadOnly(True)
        self.no_of_payments_input = QtWidgets.QLineEdit("0"); self.no_of_payments_input.setReadOnly(True)
        self.total_bound_input = QtWidgets.QLineEdit("0.00"); self.total_bound_input.setReadOnly(True)
        self.no_of_bound_input = QtWidgets.QLineEdit("0"); self.no_of_bound_input.setReadOnly(True)
        self.total_oa_paid_input = QtWidgets.QLineEdit("0.00"); self.total_oa_paid_input.setReadOnly(True)
        self.outstanding_amt_input = QtWidgets.QLineEdit("0.00"); self.outstanding_amt_input.setReadOnly(True)
        self.oa_remain_input = QtWidgets.QLineEdit("0.00"); self.oa_remain_input.setReadOnly(True)
        self.ass_amount_d2_input = QtWidgets.QLineEdit("0.00"); self.ass_amount_d2_input.setReadOnly(True)
        self.total_balance_d2_input = QtWidgets.QLineEdit("0.00"); self.total_balance_d2_input.setReadOnly(True)
        # --- End Assignment ---

        # --- Layout (Use self.widget_name) ---
        layout.addWidget(QtWidgets.QLabel("Total Paid:"), 0, 0)
        layout.addWidget(self.total_paid_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("No. of payments:"), 0, 2)
        layout.addWidget(self.no_of_payments_input, 0, 3)

        layout.addWidget(QtWidgets.QLabel("Total bound:"), 1, 0)
        layout.addWidget(self.total_bound_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("No. of bound:"), 1, 2)
        layout.addWidget(self.no_of_bound_input, 1, 3)

        layout.addWidget(QtWidgets.QLabel("Total O/A paid:"), 2, 0)
        layout.addWidget(self.total_oa_paid_input, 2, 1)
        layout.addWidget(QtWidgets.QLabel("Outstanding amt:"), 2, 2)
        layout.addWidget(self.outstanding_amt_input, 2, 3)
        layout.addWidget(QtWidgets.QLabel("O/A Remain:"), 2, 4)
        layout.addWidget(self.oa_remain_input, 2, 5)


        layout.addWidget(QtWidgets.QLabel("Ass. amount:"), 3, 0)
        layout.addWidget(self.ass_amount_d2_input, 3, 1)
        layout.addWidget(QtWidgets.QLabel("Total Balance:"), 3, 2)
        layout.addWidget(self.total_balance_d2_input, 3, 3)
        # --- End Layout ---

        # Add stretch
        layout.setRowStretch(4, 1)
        layout.setColumnStretch(6, 1)

        return widget

    def create_payment_summary_area(self):
        """創建付款摘要區域 (Detail 2 - Part 2)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-top: 1px solid {COLOR_BORDER};")
        layout = QtWidgets.QVBoxLayout(widget) # Use QVBoxLayout for the table
        layout.setContentsMargins(15, 5, 15, 15) # Adjust margins
        layout.setSpacing(5)

        # --- Assign Table to self ---
        self.payment_summary_table = QtWidgets.QTableWidget(4, 7) # Example rows/cols
        # --- End Assignment ---

        self.payment_summary_table.setHorizontalHeaderLabels([
            "Paid Date", "Paid Amount", "OS/Amount", "OA paid",
            "Adjustment", "MD Col", "Bills" # Example Headers
        ])
        # Apply Table Styles
        self.payment_summary_table.horizontalHeader().setStyleSheet(DATA_TABLE_HEADER_STYLE)
        self.payment_summary_table.verticalHeader().setVisible(False)
        self.payment_summary_table.setAlternatingRowColors(True)
        self.payment_summary_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.payment_summary_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.payment_summary_table.horizontalHeader().setStretchLastSection(True)

        layout.addWidget(self.payment_summary_table)
        return widget

    def create_personal_info_area(self):
        """創建個人信息區域 (Detail 3)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10) # Horizontal spacing between label/widget columns
        layout.setVerticalSpacing(8)   # Vertical spacing between rows

        # --- Helper to create input fields with fixed width and ReadOnly ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            line_edit.setReadOnly(True) # Set Read Only here
            return line_edit

        # --- Assign Fields to self ---
        self.birthday_input = create_input(80, placeholder="//") # Mapped to BIRTHDAY
        self.age_input = create_input(50, "0") # Calculated? No direct map yet.
        self.marital_status_input = create_input(150) # Mapped to MARRY
        self.nationality_input = create_input(200) # Mapped to NATION
        self.education_input = create_input(200) # Mapped to EDUCATION
        self.home_address_edit = QtWidgets.QTextEdit() # Mapped to ADD1-ADD4
        self.home_address_edit.setFixedHeight(100)
        self.home_address_edit.setReadOnly(True) # Read Only
        self.home_phone_input = create_input(250) # Mapped to PHONE
        self.pager_input = create_input(150) # Mapped to PAGER
        self.pager_ac_input = create_input(50) # Need DB field mapping
        self.mobile_input = create_input(150) # Mapped to MOBILE
        self.house_status_input = create_input(150) # Mapped to HOUSE
        self.years_lived_input = create_input(50, "0") # Mapped to YEARLIVED
        # --- End Assignment ---

        # --- Row 0: Birthday, Age, Marital Status ---
        layout.addWidget(QtWidgets.QLabel("Birthday:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.birthday_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Age:"), 0, 2, QtCore.Qt.AlignRight)
        layout.addWidget(self.age_input, 0, 3)
        layout.addWidget(QtWidgets.QLabel("Marital Status:"), 0, 4, QtCore.Qt.AlignRight)
        layout.addWidget(self.marital_status_input, 0, 5) # Adjust width as needed

        # --- Row 1: Nationality ---
        layout.addWidget(QtWidgets.QLabel("Nationality:"), 1, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.nationality_input, 1, 1, 1, 3) # Span columns 1-3

        # --- Row 2: Education ---
        layout.addWidget(QtWidgets.QLabel("Education:"), 2, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.education_input, 2, 1, 1, 3) # Span columns 1-3

        # --- Row 3-6: Home Address and Buttons ---
        layout.addWidget(QtWidgets.QLabel("Home Address:"), 3, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        layout.addWidget(self.home_address_edit, 3, 1, 4, 5) # Span 4 rows, 5 columns (1 to 5)

        # Buttons next to address
        address_button_layout = QtWidgets.QVBoxLayout()
        address_button_layout.setContentsMargins(0, 0, 0, 0)
        address_button_layout.setSpacing(5)
        btn_f8_add = QtWidgets.QPushButton("F8 - Add")
        btn_ctrl_f8_phone = QtWidgets.QPushButton("Ctrl+F8-Phone")
        btn_f8_add.setFixedWidth(110) # Fixed width for buttons
        btn_ctrl_f8_phone.setFixedWidth(110)
        address_button_layout.addWidget(btn_f8_add)
        address_button_layout.addWidget(btn_ctrl_f8_phone)
        address_button_layout.addStretch() # Push buttons up
        # Add this button layout to the grid, spanning relevant rows next to the address label
        layout.addLayout(address_button_layout, 3, 0, 4, 1, QtCore.Qt.AlignTop | QtCore.Qt.AlignRight) # Span 4 rows in column 0

        # --- Row 7: Home Phone ---
        layout.addWidget(QtWidgets.QLabel("Home Phone:"), 7, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.home_phone_input, 7, 1, 1, 3) # Span columns 1-3

        # --- Row 8: Pager Number, A/C, Mobile phone ---
        layout.addWidget(QtWidgets.QLabel("Pager Number:"), 8, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.pager_input, 8, 1)
        layout.addWidget(QtWidgets.QLabel("A/C:"), 8, 2, QtCore.Qt.AlignRight)
        layout.addWidget(self.pager_ac_input, 8, 3)
        layout.addWidget(QtWidgets.QLabel("Mobile phone:"), 8, 4, QtCore.Qt.AlignRight)
        layout.addWidget(self.mobile_input, 8, 5)

        # --- Row 9: House Status, Years Lived ---
        layout.addWidget(QtWidgets.QLabel("House Status:"), 9, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.house_status_input, 9, 1)
        layout.addWidget(QtWidgets.QLabel("Years Lived:"), 9, 4, QtCore.Qt.AlignRight) # Positioned further right
        layout.addWidget(self.years_lived_input, 9, 5)

        # --- Stretch and Column Configuration ---
        # Add row stretch below the last content row
        layout.setRowStretch(10, 1)
        # Configure column widths/stretch if needed (example)
        layout.setColumnMinimumWidth(0, 100) # Minimum width for labels column
        layout.setColumnStretch(1, 1)
        layout.setColumnStretch(3, 1)
        layout.setColumnStretch(5, 1)
        layout.setColumnStretch(6, 1) # Add stretch after the last column

        return widget

    def create_company_info_area(self):
        """創建公司信息區域 (Detail 4)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(8)

        # --- Helper to create input fields with fixed width and ReadOnly ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            line_edit.setReadOnly(True) # Set Read Only here
            return line_edit

        # --- Assign Fields to self ---
        self.company_name_input = create_input(350) # Mapped to COMPANY
        self.office_address_edit = QtWidgets.QTextEdit() # Mapped to OADD1-OADD4
        self.office_address_edit.setFixedHeight(100)
        self.office_address_edit.setReadOnly(True) # Read Only
        self.office_phone1_input = create_input(250) # Mapped to OPHONE1
        self.office_phone2_input = create_input(250) # Mapped to OPHONE2
        self.position_input = create_input(250) # Mapped to POS
        self.annual_income_input = create_input(150); self.annual_income_input.setAlignment(QtCore.Qt.AlignRight) # Mapped to INCOME
        self.self_employed_label = QtWidgets.QLabel("N") # Mapped to SELFEMP
        self.self_employed_label.setFixedWidth(40)
        self.self_employed_label.setAlignment(QtCore.Qt.AlignCenter)
        self.self_employed_label.setStyleSheet(f"""
            {INPUT_STYLE} /* Use base input style */
            background-color: #E9E9E9; /* Slightly different background like disabled */
            font-weight: bold;
        """)
        # --- End Assignment ---

        # --- Row 0: Company name ---
        layout.addWidget(QtWidgets.QLabel("Company name:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.company_name_input, 0, 1, 1, 3) # Span 3 columns

        # --- Row 1-4: Office Address ---
        layout.addWidget(QtWidgets.QLabel("Office Address:"), 1, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        layout.addWidget(self.office_address_edit, 1, 1, 4, 5) # Span 4 rows, 5 columns

        # --- Row 5: Office phone 1 ---
        layout.addWidget(QtWidgets.QLabel("Office phone 1:"), 5, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.office_phone1_input, 5, 1, 1, 3) # Span 3 columns

        # --- Row 6: Office Phone 2 ---
        layout.addWidget(QtWidgets.QLabel("Office Phone 2:"), 6, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.office_phone2_input, 6, 1, 1, 3) # Span 3 columns

        # --- Row 7: Position ---
        layout.addWidget(QtWidgets.QLabel("Position:"), 7, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.position_input, 7, 1, 1, 3) # Span 3 columns

        # --- Row 8: Annual income ---
        layout.addWidget(QtWidgets.QLabel("Annual income:"), 8, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.annual_income_input, 8, 1) # Shorter width

        # --- Row 9: Self-employed ---
        layout.addWidget(QtWidgets.QLabel("Self-employed:"), 9, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.self_employed_label, 9, 1)

        # --- Stretch and Column Configuration ---
        layout.setRowStretch(10, 1) # Stretch below last content row
        layout.setColumnMinimumWidth(0, 110) # Min width for labels
        layout.setColumnStretch(1, 1)
        layout.setColumnStretch(6, 1) # Stretch after last used column

        return widget

    def create_block_info_area(self):
        """創建封鎖信息區域 (Detail 5) - 根據圖片更新"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(8)

        # --- Helper to create input fields with fixed width and ReadOnly ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            line_edit.setReadOnly(True) # Set Read Only here
            return line_edit

        # --- Assign Fields to self ---
        self.block_code_input = create_input(100) # Mapped to BLOCKCODE
        self.placement_input = create_input(100) # Mapped to PLACEMENT
        self.block_remark_input = create_input(210) # Mapped to BCREMARK
        self.agency_code_input = create_input(100) # Mapped to AGENCYCODE

        # --- Date/Time Inputs ---
        self.receive_date_input = create_input(80, placeholder="//") # Mapped to RECVDAT
        self.receive_time_input = create_input(50, placeholder=" : ") # Mapped to RECVTIME
        # --- End Date/Time Inputs ---

        self.hkb_oversea_label = QtWidgets.QLabel("N") # Mapped to HKBOSEA
        self.hkb_oversea_label.setFixedWidth(40)
        self.hkb_oversea_label.setAlignment(QtCore.Qt.AlignCenter)
        self.hkb_oversea_label.setStyleSheet(f"""
            {INPUT_STYLE}
            background-color: #E9E9E9;
            font-weight: bold;
        """)
        self.bank_alert_checkbox = QtWidgets.QCheckBox("Bank Information Alert") # Mapped to AINFO
        self.bank_alert_text = QtWidgets.QTextEdit() # Mapped to AINFOD
        self.bank_alert_text.setFixedHeight(80)
        self.bank_alert_text.setReadOnly(True) # Read Only

        self.date_to_return_input = create_input(100, placeholder="//") # Mapped to RETURNDATE
        self.first_call_before_input = create_input(100, placeholder="//") # Need DB mapping
        self.first_visit_before_input = create_input(100, placeholder="//") # Need DB mapping

        self.co_date_input = create_input(100, placeholder="//") # Need DB mapping
        self.date_to_co_input = create_input(100, placeholder="//") # Need DB mapping
        self.net_co_amt_input = create_input(150, placeholder=".") # Need DB mapping
        self.case_refer_by_input = create_input(200) # Mapped to REFER
        self.hold_by_input = create_input(200) # Need DB mapping
        self.auto_trans_date_input = create_input(100, placeholder="//") # Need DB mapping
        self.last_pay_date_input = create_input(100, placeholder="//") # Need DB mapping
        self.last_pay_amt_input = create_input(150, placeholder=".") # Need DB mapping
        self.visit_collector_input = create_input(100) # Need DB mapping
        self.sub_client_name_input = create_input(200) # Mapped to SUBCLNAME
        # --- End Assignment ---

        # --- Column 0 & 1 (Left Side) ---
        layout.addWidget(QtWidgets.QLabel("Block Code:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.block_code_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Placement:"), 0, 2, QtCore.Qt.AlignRight) # Placement next to Block Code
        layout.addWidget(self.placement_input, 0, 3)

        layout.addWidget(QtWidgets.QLabel("Block Code Remark:"), 1, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.block_remark_input, 1, 1, 1, 3) # Span columns 1-3

        layout.addWidget(QtWidgets.QLabel("Agency Code:"), 2, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.agency_code_input, 2, 1)

        layout.addWidget(QtWidgets.QLabel("Receive Date:"), 3, 0, QtCore.Qt.AlignRight)
        receive_date_layout = QtWidgets.QHBoxLayout()
        receive_date_layout.setSpacing(5)
        receive_date_layout.addWidget(self.receive_date_input) # Use self.
        receive_date_layout.addWidget(self.receive_time_input) # Use self.
        receive_date_layout.addStretch()
        layout.addLayout(receive_date_layout, 3, 1, 1, 2) # Span columns 1-2

        layout.addWidget(QtWidgets.QLabel("HKB Oversea:"), 4, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.hkb_oversea_label, 4, 1)

        layout.addWidget(self.bank_alert_checkbox, 5, 0, 1, 2) # Span columns 0-1

        layout.addWidget(self.bank_alert_text, 6, 0, 3, 4) # Span 3 rows, 4 columns (0-3)

        # --- Bottom Left Dates ---
        layout.addWidget(QtWidgets.QLabel("Date To Return:"), 9, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.date_to_return_input, 9, 1)

        layout.addWidget(QtWidgets.QLabel("First Call Before:"), 10, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.first_call_before_input, 10, 1)

        layout.addWidget(QtWidgets.QLabel("First Visit Before:"), 11, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.first_visit_before_input, 11, 1)

        # --- Column 4 & 5 (Right Side) ---
        right_col_start = 4 # Starting column index for the right section

        layout.addWidget(QtWidgets.QLabel("C/O Date:"), 0, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.co_date_input, 0, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Date to C/O:"), 1, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.date_to_co_input, 1, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Net C/O Amt:"), 2, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.net_co_amt_input, 2, right_col_start + 1) # Placeholder '.'

        layout.addWidget(QtWidgets.QLabel("Case Refer By:"), 3, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.case_refer_by_input, 3, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("HOLD By:"), 4, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.hold_by_input, 4, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Auto Trans Date:"), 5, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.auto_trans_date_input, 5, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Last pay date:"), 6, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.last_pay_date_input, 6, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Last pay amt:"), 7, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.last_pay_amt_input, 7, right_col_start + 1) # Placeholder '.'

        layout.addWidget(QtWidgets.QLabel("Visit Collector:"), 8, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.visit_collector_input, 8, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Sub Client Name:"), 9, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.sub_client_name_input, 9, right_col_start + 1, 1, 1) # Ensure it doesn't span too far if grid expands

        # --- Stretch and Column Configuration ---
        layout.setRowStretch(12, 1) # Stretch below last content row
        layout.setColumnMinimumWidth(0, 120) # Adjust min width for left labels
        layout.setColumnMinimumWidth(right_col_start, 110) # Adjust min width for right labels
        layout.setColumnStretch(1, 1) # Allow input columns to stretch
        layout.setColumnStretch(3, 1)
        layout.setColumnStretch(right_col_start + 1, 2) # Give more stretch to right input column
        layout.setColumnStretch(right_col_start + 2, 1) # Add stretch after last column

        return widget

    def create_detail_code_area(self):
        """創建詳細代碼區域 (Detail 6) - 根據圖片更新"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(15) # Increased vertical spacing

        # --- Helper (ensure accessible) and set ReadOnly ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            line_edit.setReadOnly(True) # Set Read Only here
            return line_edit

        # --- Assign Fields to self ---
        self.detail_code_input = create_input(150) # Mapped to DETAILCODE? Verify DB field name
        self.last_input_date_d6 = create_input(100, placeholder="//") # Need DB mapping
        self.detail_code_text = QtWidgets.QTextEdit() # Mapped to DETAIL? Verify DB field name
        self.detail_code_text.setMinimumHeight(200)
        self.detail_code_text.setReadOnly(True) # Read Only
        # --- End Assignment ---

        # --- Row 0: Detail Code and Last Input Date ---
        layout.addWidget(QtWidgets.QLabel("Detail Code:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(self.detail_code_input, 0, 1)

        layout.addWidget(QtWidgets.QLabel("Last Input Date:"), 0, 3, QtCore.Qt.AlignRight)
        layout.addWidget(self.last_input_date_d6, 0, 4)

        # --- Row 1: Large Text Area ---
        layout.addWidget(self.detail_code_text, 1, 0, 1, 6) # Span across columns

        # --- Stretch ---
        layout.setRowStretch(2, 1) # Stretch below the text area
        layout.setColumnStretch(2, 1) # Add some stretch between fields
        layout.setColumnStretch(5, 1) # Stretch after last input date
        layout.setColumnStretch(6, 2) # More stretch at the end

        return widget

    def create_case_history_area(self):
        """創建案件歷史區域 (Detail 7) - 使用 QTableWidget 顯示歷史"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        # Main layout using QHBoxLayout to split left and right
        main_layout = QtWidgets.QHBoxLayout(widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(20) # Spacing between left and right sections

        # --- Left Section (Collector History Table) ---
        left_widget = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        # --- Assign Table and Input to self ---
        self.history_table = QtWidgets.QTableWidget()
        self.history_bottom_input = QtWidgets.QLineEdit()
        self.history_bottom_input.setReadOnly(True) # Read Only
        # --- End Assignment ---

        self.history_table.setMinimumWidth(350) # Adjust width as needed
        self.history_table.setColumnCount(4)
        self.history_table.setHorizontalHeaderLabels(["Collector", "From", "To", "By"])

        # Apply Table Styles
        self.history_table.setStyleSheet(DATA_TABLE_STYLE) # Apply base table style
        self.history_table.horizontalHeader().setStyleSheet(DATA_TABLE_HEADER_STYLE)
        self.history_table.verticalHeader().setVisible(False) # Hide row numbers
        self.history_table.setAlternatingRowColors(True)
        self.history_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.history_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers) # Read-only

        # Example data (replace with actual data loading)
        history_data = [
            ("CB", "10/20/2000", "10/20/2000", "ADM"),
            ("ICL", "10/20/2000", "11/20/2000", "ADM"),
            ("CA", "10/20/2000", "11/20/2000", "ADM"),
            ("CL", "11/20/2000", "03/06/2004", "ADM"),
            ("ADM", "03/06/2004", "05/13/2004", "ADM"),
            ("CB", "05/13/2004", "09/06/2004", "ADM"),
            ("CD", "09/06/2004", "08/11/2005", "ADM"),
            ("ADM", "08/11/2005", "09/15/2005", "ADM"),
            ("DB", "09/15/2005", "11/04/2005", "ADM"),
            ("DVD", "11/04/2005", "NOW", "SYS")
        ]

        self.history_table.setRowCount(len(history_data))
        for row, record in enumerate(history_data):
            for col, value in enumerate(record):
                item = QtWidgets.QTableWidgetItem(value)
                # Center align date/by columns, left align collector
                if col == 0:
                    item.setTextAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
                else:
                    item.setTextAlignment(QtCore.Qt.AlignCenter | QtCore.Qt.AlignVCenter)

                # Example: Basic color for ADM/SYS in 'By' column
                if col == 3 and (value == "ADM" or value == "SYS"):
                     item.setForeground(QtGui.QColor(COLOR_ACCENT)) # Blue color
                self.history_table.setItem(row, col, item)

        # Adjust column widths
        self.history_table.setColumnWidth(0, 60)  # Collector
        self.history_table.setColumnWidth(1, 95)  # From
        self.history_table.setColumnWidth(2, 95)  # To
        self.history_table.setColumnWidth(3, 50)  # By
        # self.history_table.horizontalHeader().setStretchLastSection(True) # Optional: Stretch last column

        left_layout.addWidget(self.history_table)
        left_layout.addWidget(self.history_bottom_input)

        # --- Right Section (Case Details) ---
        right_widget = QtWidgets.QWidget()
        right_layout = QtWidgets.QGridLayout(right_widget) # This is the correct layout variable
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setHorizontalSpacing(10)
        right_layout.setVerticalSpacing(8)

        # Helper (ensure accessible) and set ReadOnly
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            line_edit.setReadOnly(True) # Set Read Only here
            return line_edit

        # --- Assign Fields to self ---
        self.entered_by_input = create_input(100, "ADM") # Mapped to ENTEREDBY
        self.entry_date_input = create_input(100, placeholder="MM/DD/YYYY") # Mapped to ENTRYDATE
        self.settle_letter_input = create_input(150, "BO10602001S") # Need DB mapping
        self.return_letter_text = QtWidgets.QTextEdit() # Mapped to RETURNNOTE
        self.return_letter_text.setFixedHeight(60)
        self.return_letter_text.setReadOnly(True) # Read Only
        self.monthly_report_text = QtWidgets.QTextEdit() # Mapped to MONTHNOTE
        self.monthly_report_text.setFixedHeight(60)
        self.monthly_report_text.setReadOnly(True) # Read Only
        # --- End Assignment ---

        # Fields - Use right_layout and self.widget_name
        right_layout.addWidget(QtWidgets.QLabel("Case entered by:"), 0, 0, QtCore.Qt.AlignRight)
        right_layout.addWidget(self.entered_by_input, 0, 1)

        right_layout.addWidget(QtWidgets.QLabel("Entry date:"), 1, 0, QtCore.Qt.AlignRight)
        right_layout.addWidget(self.entry_date_input, 1, 1)

        right_layout.addWidget(QtWidgets.QLabel("Settle Letter:"), 2, 0, QtCore.Qt.AlignRight)
        right_layout.addWidget(self.settle_letter_input, 2, 1)

        right_layout.addWidget(QtWidgets.QLabel("Return Letter:"), 3, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        right_layout.addWidget(self.return_letter_text, 3, 1, 2, 1) # Span 2 rows

        right_layout.addWidget(QtWidgets.QLabel("Monthly Report:"), 5, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)     # --- Row 5: Monthly Report ---
        right_layout.addWidget(self.monthly_report_text, 5, 1, 2, 1) # Span 2 rows

        # Stretch for right layout
        right_layout.setRowStretch(7, 1)
        right_layout.setColumnStretch(2, 1)

        # --- Add Left and Right to Main Layout ---
        main_layout.addWidget(left_widget)
        main_layout.addWidget(right_widget)
        main_layout.addStretch() # Add stretch to the main horizontal layout

        return widget

    def create_transfer_info_area(self):
        """創建轉移信息區域 (Detail 8) - 根據圖片更新"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(15) # Increased spacing between columns
        layout.setVerticalSpacing(8)

        # --- Helper (ensure accessible) and set ReadOnly ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            line_edit.setReadOnly(True) # Set Read Only here
            return line_edit

        # --- Assign Fields to self ---
        self.sub_ac_inputs = [create_input(200) for _ in range(5)] # Need DB mapping
        self.region_id_input = create_input(200) # Need DB mapping
        self.agent_id_input = create_input(200) # Need DB mapping
        self.manager_id_input = create_input(200) # Need DB mapping
        self.agency_id_input = create_input(200) # Need DB mapping

        self.drp_date_input = create_input(100, placeholder="//") # Need DB mapping
        self.next_transfer_text = QtWidgets.QTextEdit() # Need DB mapping
        self.next_transfer_text.setFixedSize(180, 80)
        self.next_transfer_text.setReadOnly(True) # Read Only
        self.f10_transfer_notes_button = QtWidgets.QPushButton("F10 - Transfer Notes")

        self.target_date_label = QtWidgets.QLabel("") # Assuming label for Target Date
        self.target_total_os_input = create_input(100, "0.00"); self.target_total_os_input.setAlignment(QtCore.Qt.AlignRight) # Need DB mapping
        self.target_target_input = create_input(100, "0.00"); self.target_target_input.setAlignment(QtCore.Qt.AlignRight) # Need DB mapping
        self.target_permanent_input = create_input(100, "0.00"); self.target_permanent_input.setAlignment(QtCore.Qt.AlignRight) # Need DB mapping
        self.target_current_input = create_input(100, "0.00"); self.target_current_input.setAlignment(QtCore.Qt.AlignRight) # Need DB mapping

        self.col_list_widget = QtWidgets.QListWidget() # Need population logic
        self.col_list_widget.setFixedWidth(120) # Adjust width
        # Note: QListWidget doesn't have setReadOnly, interaction is controlled differently
        self.col_list_reset_button = QtWidgets.QPushButton("Reset")
        self.col_list_reset_button.setFixedWidth(120)
        # --- End Assignment ---

        # --- Column 0 & 1 (Left Side: Sub A/C and IDs) ---
        sub_ac_labels = [f"Sub A/C no. {i}:" for i in range(1, 6)]
        for i, label_text in enumerate(sub_ac_labels):
            layout.addWidget(QtWidgets.QLabel(label_text), i, 0, QtCore.Qt.AlignRight)
            layout.addWidget(self.sub_ac_inputs[i], i, 1) # Use self.

        # Spacer row
        layout.setRowMinimumHeight(5, 15) # Add space before Region ID

        id_labels = ["Region ID:", "Agent ID:", "Manager ID:", "Agency ID:"]
        id_inputs = [self.region_id_input, self.agent_id_input, self.manager_id_input, self.agency_id_input]
        start_row_ids = 6
        for i, label_text in enumerate(id_labels):
            layout.addWidget(QtWidgets.QLabel(label_text), start_row_ids + i, 0, QtCore.Qt.AlignRight)
            layout.addWidget(id_inputs[i], start_row_ids + i, 1) # Use self.

        # --- Column 2 & 3 (Middle Section: Dates, Notes, Targets) ---
        mid_col_start = 2

        # DRP Date
        layout.addWidget(QtWidgets.QLabel("DRP Date:"), 0, mid_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(self.drp_date_input, 0, mid_col_start + 1) # Use self.

        # Next 4 Transfer Date Label (Row 1)
        layout.addWidget(QtWidgets.QLabel("Next 4 Transfer Date:"), 1, mid_col_start, 1, 2, QtCore.Qt.AlignLeft) # Span 2 columns for label

        # Next 4 Transfer Date Text Edit (Starts Row 2)
        layout.addWidget(self.next_transfer_text, 2, mid_col_start, 3, 2) # Use self. Span rows 2-4, cols mid_col_start to mid_col_start+1

        # Extended Date (Label only - Row 5)
        layout.addWidget(QtWidgets.QLabel("Extended Date"), 5, mid_col_start, 1, 2, QtCore.Qt.AlignLeft) # Span 2 columns

        # F10 Button (Row 6)
        layout.addWidget(self.f10_transfer_notes_button, 6, mid_col_start, 1, 2) # Use self. Span 2 columns

        # Target Section (using a sub-grid for alignment)
        target_grid = QtWidgets.QGridLayout()
        target_grid.setSpacing(5)
        target_labels_text = ["Target Date:", "Total OS:", "Target:", "Permanent:", "Current:"]
        target_widgets = [self.target_date_label, self.target_total_os_input, self.target_target_input, self.target_permanent_input, self.target_current_input]
        for i, label_text in enumerate(target_labels_text):
            target_grid.addWidget(QtWidgets.QLabel(label_text), i, 0, QtCore.Qt.AlignRight)
            target_grid.addWidget(target_widgets[i], i, 1) # Use self.
        target_grid.setColumnStretch(2, 1) # Stretch after input column
        # Add the target grid to the main layout, starting at ROW 2, next to transfer text
        layout.addLayout(target_grid, 2, mid_col_start + 2, 5, 1) # Span rows 2-6 in the next column

        # --- Column 4 (Right Side: Col List) ---
        right_col_start = mid_col_start + 3 # This should now be column 5

        layout.addWidget(QtWidgets.QLabel("Col List"), 0, right_col_start, QtCore.Qt.AlignLeft)
        layout.addWidget(self.col_list_widget, 1, right_col_start, 8, 1) # Use self. Span multiple rows (1 to 8)
        layout.addWidget(self.col_list_reset_button, 9, right_col_start, QtCore.Qt.AlignBottom) # Use self. Align to bottom

        # --- Stretch and Column Configuration ---
        # Stretch below last row on left (row 9 is last used by IDs)
        layout.setRowStretch(start_row_ids + len(id_labels), 1)
        layout.setColumnStretch(1, 1) # Stretch Sub A/C input column
        # No stretch for middle columns
        layout.setColumnStretch(mid_col_start + 1, 0)
        layout.setColumnStretch(mid_col_start + 2, 0)
        # Stretch after Col List (column right_col_start + 1, which is 6)
        layout.setColumnStretch(right_col_start + 1, 1)

        return widget

    # ===== EVENT HANDLERS AND ACTIONS =====

    def browse_cases(self):
        """顯示 CaseList，獲取選擇的 RefNo, 獲取完整數據, 並填充欄位"""
        print("--- browse_cases called ---")
        # Check if the CaseList module and its class were imported successfully
        if CaseList is None or not hasattr(CaseList, 'CaseList') or not isinstance(CaseList.CaseList, type):
            print("ERROR: CaseList module or class is not available.")
            # Show import error if it exists
            error_to_show = import_error_message or "Case List functionality is unavailable (Import failed)."
            QtWidgets.QMessageBox.critical(self, "Error", error_to_show)
            return

        # 1. Call get_selected_case to get RefNo
        selected_ref_no = CaseList.CaseList.get_selected_case(parent=self)

        if selected_ref_no:
            print(f"RefNo selected from CaseList: {selected_ref_no}")
            # Update the Ref input field with the selected RefNo
            if self.ref_input:
                self.ref_input.setText(str(selected_ref_no)) # Update the input field

            # 2. Call get_case using the selected RefNo to get full details
            self._fetch_and_display_case(selected_ref_no) # Use the common fetch method
        else:
            print("Case selection cancelled or failed in CaseList.")

    def _fetch_and_display_case_by_ref(self):
        """當在 Ref: 輸入框按下 Enter 時，獲取 RefNo 並查詢顯示案件"""
        print("--- _fetch_and_display_case_by_ref called ---")
        if not self.ref_input:
            print("ERROR: self.ref_input is not initialized.")
            return

        ref_no_str = self.ref_input.text().strip()
        if not ref_no_str:
            QtWidgets.QMessageBox.warning(self, "Input Required", "Please enter a Ref No.")
            self._populate_fields(None) # Clear fields if input is empty
            return

        # Optional: Validate if ref_no_str is numeric if needed
        # try:
        #     ref_no_int = int(ref_no_str)
        # except ValueError:
        #     QtWidgets.QMessageBox.warning(self, "Invalid Input", "Ref No must be a number.")
        #     self._populate_fields(None) # Clear fields on invalid input
        #     return

        # Use the common fetch method
        self._fetch_and_display_case(ref_no_str)

    def _fetch_and_display_case(self, ref_no):
        """根據提供的 RefNo 獲取並顯示案件詳細信息 (通用方法)"""
        print(f"Attempting to fetch full details for RefNo: {ref_no} using CaseList.get_case...")

        # Check if CaseList and get_case are available
        if CaseList is None or not hasattr(CaseList, 'CaseList') or not hasattr(CaseList.CaseList, 'get_case'):
            print("ERROR: CaseList module or get_case method is not available.")
            error_to_show = import_error_message or "Cannot fetch case details (CaseList or get_case missing)."
            QtWidgets.QMessageBox.critical(self, "Error", error_to_show)
            return

        try:
            # Call the static method get_case from CaseList class
            case_details = CaseList.CaseList.get_case(ref_no)

            if case_details:
                print(f"Full case details fetched successfully for RefNo {ref_no}.")
                # Populate fields using the fetched details
                self._populate_fields(case_details)
            else:
                print(f"CaseList.get_case returned None for RefNo {ref_no}.")
                QtWidgets.QMessageBox.warning(self, "Data Not Found", f"Could not retrieve details for Ref No {ref_no}.")
                self._populate_fields(None) # Clear fields if record not found

        except Exception as e:
             print(f"ERROR calling CaseList.get_case or populating fields for RefNo {ref_no}: {e}")
             import traceback
             traceback.print_exc()
             QtWidgets.QMessageBox.critical(self, "Error", f"An error occurred while fetching or displaying case details:\n{e}")
             self._populate_fields(None) # Clear fields on error

    # ===== DATA HANDLING METHODS =====

    def _create_field_map(self):
        """
        創建資料庫欄位名稱到 UI 輸入元件的映射。
        **重要**: 請根據你的實際資料庫欄位名稱和 UI 元件變數名稱進行調整。
        """
        # 使用 getattr(self, 'widget_name', None) 安全地獲取元件
        # 如果元件在 init_ui 或其子方法中尚未創建，則返回 None
        field_map = {
            # --- Top Ref Row (Editable) ---
            "RefNo": getattr(self, 'ref_input', None),
            # "No": getattr(self, 'no_field', None), # Map if 'No' comes from DB
            # "Name": getattr(self, 'name_field', None), # Map if 'Name' comes from DB
            "HKID": getattr(self, 'hkid_field', None), # Top HKID field

            # --- Main Form Area (ReadOnly) ---
            "REFNO": getattr(self, 'ref_no', None),
            "CLCODE": getattr(self, 'client_code', None),
            "ACNAME": getattr(self, 'ac_name', None),
            "ACNO": getattr(self, 'ac_no', None),
            "CHINAME": getattr(self, 'chinese', None),
            "ENGLISH": getattr(self, 'english', None), # QLabel
            "SEX": getattr(self, 'sex', None),
            "CURR": getattr(self, 'currency', None),
            "LOANTYPE": getattr(self, 'loan_type', None),
            "ASSIGNDATE": getattr(self, 'date_assign', None),
            "COLLECTOR": getattr(self, 'collector', None),
            "STATUS": getattr(self, 'status', None),
            "CARDTYPE": getattr(self, 'card_type', None),
            "HKID": getattr(self, 'id_no', None), # NOTE: Duplicate HKID key, last one wins. Check DB names.
            "ISCORP": getattr(self, 'corp', None), # QLabel
            "DEBTORID": getattr(self, 'debtor_id', None),

            # --- Detail 1: Financial Area (ReadOnly) ---
            "ASSAMOUNT": getattr(self, 'ass_amt_input', None),
            "LATEFEE": getattr(self, 'late_fee_input', None),
            "INTEREST": getattr(self, 'interest_input', None),
            "LEGALCH": getattr(self, 'legal_fee_input', None),
            "OTHERSFEE": getattr(self, 'oahers_input', None),
            "OSAMOUNT": getattr(self, 'os_amt_input', None),
            "COMMISSION": getattr(self, 'commission_input', None),
            "COMRATE": getattr(self, 'comm_rate_input', None),
            "TOTALB": getattr(self, 'total_balance_input', None),
            "DISAMOUNT": getattr(self, 'discounted_amt_input', None),
            "DISEXPDATE": getattr(self, 'dis_end_date_input', None),
            "LEGALOA": getattr(self, 'legal_oa_checkbox', None), # QCheckBox
            "INTERESTOA": getattr(self, 'interest_oa_checkbox', None), # QCheckBox
            "LATEFEEOA": getattr(self, 'latefee_oa_checkbox', None), # QCheckBox
            "OTHERSOA": getattr(self, 'os_amt_oa_checkbox', None), # QCheckBox
            "ALLBILLED": getattr(self, 'all_billed_button', None), # QPushButton
            # "Charging Order": getattr(self, 'charging_order_checkbox', None), # QCheckBox

            # --- Detail 1: Bottom Summary (Labels - inherently read-only) ---
            # "LinkedCount": getattr(self, 'linked_no_label', None),
            # "LinkedAssAmt": getattr(self, 'linked_ass_amt_label', None),
            # ... map other summary labels ...

            # --- Detail 2: Payment Area (ReadOnly) ---
            "TOTALPAID": getattr(self, 'total_paid_input', None),
            # "No. of payments": getattr(self, 'no_of_payments_input', None), # Need DB field
            "TOTALBP": getattr(self, 'total_bound_input', None),
            # "No. of bound": getattr(self, 'no_of_bound_input', None), # Need DB field
            "TOTALOAPAI": getattr(self, 'total_oa_paid_input', None),
            # "Outstanding amt": getattr(self, 'outstanding_amt_input', None), # Need DB field (Maybe OSAMOUNT?)
            "OAREMAIN": getattr(self, 'oa_remain_input', None),
            # "Ass. amount": getattr(self, 'ass_amount_d2_input', None), # Need DB field (Maybe ASSAMOUNT?)
            # "Total Balance": getattr(self, 'total_balance_d2_input', None), # Need DB field (Maybe TOTALB?)

            # --- Detail 3: Personal Info (ReadOnly) ---
            "BIRTHDAY": getattr(self, 'birthday_input', None),
            # "Age": getattr(self, 'age_input', None), # Calculated?
            "MARRY": getattr(self, 'marital_status_input', None),
            "NATION": getattr(self, 'nationality_input', None),
            "EDUCATION": getattr(self, 'education_input', None),
            "ADD1": getattr(self, 'home_address_edit', None), # QTextEdit
            "ADD2": getattr(self, 'home_address_edit', None), # QTextEdit
            "ADD3": getattr(self, 'home_address_edit', None), # QTextEdit
            "ADD4": getattr(self, 'home_address_edit', None), # QTextEdit
            "PHONE": getattr(self, 'home_phone_input', None),
            "PAGER": getattr(self, 'pager_input', None),
            # "A/C": getattr(self, 'pager_ac_input', None), # Need DB field
            "MOBILE": getattr(self, 'mobile_input', None),
            "HOUSE": getattr(self, 'house_status_input', None),
            "YEARLIVED": getattr(self, 'years_lived_input', None),

            # --- Detail 4: Company Info (ReadOnly) ---
            "COMPANY": getattr(self, 'company_name_input', None),
            "OADD1": getattr(self, 'office_address_edit', None), # QTextEdit
            "OADD2": getattr(self, 'office_address_edit', None), # QTextEdit
            "OADD3": getattr(self, 'office_address_edit', None), # QTextEdit
            "OADD4": getattr(self, 'office_address_edit', None), # QTextEdit
            "OPHONE1": getattr(self, 'office_phone1_input', None),
            "OPHONE2": getattr(self, 'office_phone2_input', None),
            "POS": getattr(self, 'position_input', None),
            "INCOME": getattr(self, 'annual_income_input', None),
            "SELFEMP": getattr(self, 'self_employed_label', None), # QLabel

            # --- Detail 5: Block Info (ReadOnly) ---
            "BLOCKCODE": getattr(self, 'block_code_input', None),
            "PLACEMENT": getattr(self, 'placement_input', None),
            "BCREMARK": getattr(self, 'block_remark_input', None),
            "AGENCYCODE": getattr(self, 'agency_code_input', None),
            "RECVDAT": getattr(self, 'receive_date_input', None),
            "RECVTIME": getattr(self, 'receive_time_input', None),
            "HKBOSEA": getattr(self, 'hkb_oversea_label', None), # QLabel
            "AINFO": getattr(self, 'bank_alert_checkbox', None), # QCheckBox
            "AINFOD": getattr(self, 'bank_alert_text', None), # QTextEdit
            "RETURNDATE": getattr(self, 'date_to_return_input', None),
            # "First Call Before": getattr(self, 'first_call_before_input', None), # Need DB field
            # "First Visit Before": getattr(self, 'first_visit_before_input', None), # Need DB field
            # "C/O Date": getattr(self, 'co_date_input', None), # Need DB field
            # "Date to C/O": getattr(self, 'date_to_co_input', None), # Need DB field
            # "Net C/O Amt": getattr(self, 'net_co_amt_input', None), # Need DB field
            "REFER": getattr(self, 'case_refer_by_input', None),
            # "HOLD By": getattr(self, 'hold_by_input', None), # Need DB field
            # "Auto Trans Date": getattr(self, 'auto_trans_date_input', None), # Need DB field
            # "Last pay date": getattr(self, 'last_pay_date_input', None), # Need DB field
            # "Last pay amt": getattr(self, 'last_pay_amt_input', None), # Need DB field
            # "Visit Collector": getattr(self, 'visit_collector_input', None), # Need DB field
            "SUBCLNAME": getattr(self, 'sub_client_name_input', None),

            # --- Detail 6: Detail Code (ReadOnly) ---
            "DETAILCODE": getattr(self, 'detail_code_input', None),
            "DETAILDATE": getattr(self, 'last_input_date_d6', None),
            "DETAIL": getattr(self, 'detail_code_text', None), # QTextEdit

            # --- Detail 7: Case History (ReadOnly) ---
            "ENTEREDBY": getattr(self, 'entered_by_input', None),
            "ENTRYDATE": getattr(self, 'entry_date_input', None),
            # "Settle Letter": getattr(self, 'settle_letter_input', None), # Need DB field
            "RETURNNOTE": getattr(self, 'return_letter_text', None), # QTextEdit
            "MONTHNOTE": getattr(self, 'monthly_report_text', None), # QTextEdit
            # "History Bottom Input": getattr(self, 'history_bottom_input', None),

            # --- Detail 8: Transfer Info (ReadOnly) ---
            # Map Sub A/C inputs if they come from DB
            # "SUBACT1": getattr(self, 'sub_ac_inputs', [None])[0],
            # ...
            # "REGIONID": getattr(self, 'region_id_input', None),
            # "AGENTID": getattr(self, 'agent_id_input', None),
            # "MANAGERID": getattr(self, 'manager_id_input', None),
            # "AGENCYID": getattr(self, 'agency_id_input', None),
            # "DRPDATE": getattr(self, 'drp_date_input', None),
            # "NEXTTRANSFERNOTE": getattr(self, 'next_transfer_text', None), # QTextEdit
            # "TARGETDATE": getattr(self, 'target_date_label', None), # QLabel
            # "TARGETOS": getattr(self, 'target_total_os_input', None),
            # "TARGETAMT": getattr(self, 'target_target_input', None),
            # "TARGETPERM": getattr(self, 'target_permanent_input', None),
            # "TARGETCURR": getattr(self, 'target_current_input', None),

            # Add other mappings as needed...
        }
        # Filter out entries where the widget is None
        return {k: v for k, v in field_map.items() if v is not None}

    def _populate_fields(self, data):
        """根據獲取的案件資料字典填充 UI 欄位"""
        print("--- _populate_fields called ---")
        field_map = self._create_field_map() # Get the current mapping

        if not data:
            print("No data provided to populate fields. Clearing fields.")
            # Clear fields if no data
            for widget in field_map.values():
                # Don't clear the top row editable fields
                if widget in [getattr(self, 'ref_input', None), getattr(self, 'no_field', None), getattr(self, 'name_field', None), getattr(self, 'hkid_field', None)]:
                    continue

                if isinstance(widget, QtWidgets.QLineEdit) or isinstance(widget, QtWidgets.QTextEdit):
                    widget.clear()
                elif isinstance(widget, QtWidgets.QLabel) and widget not in [self.mode_label]:
                    if widget in [getattr(self, 'english', None), getattr(self, 'corp', None), getattr(self, 'self_employed_label', None), getattr(self, 'hkb_oversea_label', None)]:
                         widget.setText("?")
                    else:
                         widget.clear()
                elif isinstance(widget, QtWidgets.QCheckBox):
                    widget.setChecked(False)
                elif isinstance(widget, QtWidgets.QPushButton):
                     if widget is getattr(self, 'all_billed_button', None):
                         widget.setEnabled(True) # Or set default text/style
                         widget.setText("All Billed") # Reset text
            # Clear top row Ref field specifically if needed (e.g., set to "0")
            ref_input_widget = getattr(self, 'ref_input', None)
            if ref_input_widget:
                ref_input_widget.setText("0")
            # Clear other top row fields
            no_field_widget = getattr(self, 'no_field', None)
            if no_field_widget: no_field_widget.clear()
            name_field_widget = getattr(self, 'name_field', None)
            if name_field_widget: name_field_widget.clear()
            hkid_field_widget = getattr(self, 'hkid_field', None)
            if hkid_field_widget: hkid_field_widget.clear()
            return

        # --- Special handling for multi-field addresses ---
        home_address_parts = []
        office_address_parts = []

        for db_field_name, widget in field_map.items():
            value = data.get(db_field_name)

            # --- Handle multi-part addresses BEFORE general processing ---
            if widget is getattr(self, 'home_address_edit', None) and db_field_name in ["ADD1", "ADD2", "ADD3", "ADD4"]:
                if value: home_address_parts.append(str(value).strip())
                continue
            if widget is getattr(self, 'office_address_edit', None) and db_field_name in ["OADD1", "OADD2", "OADD3", "OADD4"]:
                if value: office_address_parts.append(str(value).strip())
                continue

            # --- General Field Processing ---
            display_value = None

            # 1. Handle None
            if value is None:
                display_value = ""
            # 2. Handle Boolean
            elif isinstance(value, bool):
                if isinstance(widget, QtWidgets.QCheckBox):
                    widget.setChecked(value)
                    continue
                elif isinstance(widget, QtWidgets.QPushButton):
                    if db_field_name == "ALLBILLED":
                        widget.setEnabled(not value)
                        widget.setText("Billed" if value else "All Billed")
                        continue
                elif widget in [getattr(self, 'english', None), getattr(self, 'corp', None), getattr(self, 'self_employed_label', None), getattr(self, 'hkb_oversea_label', None)]:
                     display_value = "Y" if value else "N"
                else:
                     display_value = "True" if value else "False"
            # 3. Handle Datetime
            elif isinstance(value, datetime):
                if db_field_name == "RECVDAT":
                    display_value = value.strftime("%m/%d/%Y")
                elif db_field_name == "RECVTIME":
                    # Check if time part is meaningful (not midnight)
                    if value.hour == 0 and value.minute == 0 and value.second == 0:
                        # If it's likely just a date stored in datetime, format as date only
                        if db_field_name.endswith("DATE"):
                             display_value = value.strftime("%m/%d/%Y")
                        else: # Otherwise, show full date/time even if midnight
                             display_value = value.strftime("%m/%d/%Y %H:%M:%S")
                    else: # Has a time component
                        display_value = value.strftime("%H:%M:%S") # Only show time for RECVTIME
                elif value.hour == 0 and value.minute == 0 and value.second == 0:
                     display_value = value.strftime("%m/%d/%Y")
                elif db_field_name.endswith("DATE"): # General rule for fields ending in DATE
                     display_value = value.strftime("%m/%d/%Y")
                else: # Default full date/time
                     display_value = value.strftime("%m/%d/%Y %H:%M:%S")
            # 4. Handle Numbers (Decimal, float, int)
            elif isinstance(value, (Decimal, float, int)):
                 # Check if the field is specifically for amounts/currency
                 is_currency_field = ("Amt" in db_field_name or "Fee" in db_field_name or
                                      "Balance" in db_field_name or "Commission" in db_field_name or
                                      "Interest" in db_field_name or "Income" in db_field_name or
                                      db_field_name in ["OSAMOUNT", "ASSAMOUNT", "TOTALPAID", "TOTALBP",
                                                        "TOTALOAPAI", "OAREMAIN", "DISAMOUNT", "SETTLEAMT",
                                                        "NETCOAMT", "LASTPAYAMT"]) # Added LASTPAYAMT
                 is_rate_field = "Rate" in db_field_name or db_field_name == "COMRATE"

                 if is_currency_field:
                     try:
                         # Format as currency with commas and 2 decimal places
                         display_value = f"{float(value):,.2f}"
                     except (ValueError, TypeError):
                         display_value = str(value) # Fallback
                 elif is_rate_field:
                      try:
                         # Format as rate with 2 decimal places (no commas)
                         display_value = f"{float(value):.2f}"
                      except (ValueError, TypeError):
                         display_value = str(value) # Fallback
                 else:
                     # For other numbers (like counts, IDs), just convert to string
                     display_value = str(value)
            # 5. Handle Strings (Default)
            else:
                if db_field_name == "RECVTIME" and isinstance(value, str):
                    # Basic validation for time string format H:M or H:M:S
                    if re.match(r'^\d{1,2}:\d{2}(:\d{2})?$', value.strip()):
                        display_value = value.strip()
                    else:
                        # If not a valid time string, treat as regular string
                        display_value = str(value).strip()
                else:
                    display_value = str(value).strip()

            # --- Set Value in Widget ---
            try:
                if isinstance(widget, QtWidgets.QLineEdit) or isinstance(widget, QtWidgets.QTextEdit) or isinstance(widget, QtWidgets.QLabel):
                    if display_value is not None:
                        widget.setText(display_value)
                    else:
                        widget.clear() # Clear if display_value ended up as None
            except AttributeError:
                 print(f"ERROR: Widget for {db_field_name} does not have appropriate 'setText' method.")
            except Exception as e:
                 print(f"ERROR setting widget for {db_field_name} with value '{display_value}': {e}")

        # --- Set combined addresses AFTER loop ---
        home_address_widget = getattr(self, 'home_address_edit', None)
        if home_address_widget:
            home_address_widget.setText("\n".join(filter(None, home_address_parts))) # Filter out empty parts

        office_address_widget = getattr(self, 'office_address_edit', None)
        if office_address_widget:
            office_address_widget.setText("\n".join(filter(None, office_address_parts))) # Filter out empty parts

        print("--- Field population finished ---")


    # ===== EVENT HANDLERS AND ACTIONS =====

    def keyPressEvent(self, event):
        """處理按鍵事件"""
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()
        elif event.key() == QtCore.Qt.Key_F5: # <-- Ensure F5 calls browse_cases
            print("F5 key pressed in CaseEnquiry")
            self.browse_cases()
        # Add other key handlers (F3, F4, etc.)
        # elif event.key() == QtCore.Qt.Key_F3:
        #     self.edit_action() # Example
        # elif event.key() == QtCore.Qt.Key_F4:
        #     self.delete_action() # Example
        else:
            super().keyPressEvent(event) # Pass other keys to parent

# ===== MAIN EXECUTION BLOCK =====
if __name__ == "__main__":
    # Check for import errors before creating the app
    if import_error_message:
         print(f"Critical import error detected:\n{import_error_message}")
         # Optionally show a simple message box even without full app init
         # QtWidgets.QMessageBox.critical(None, "Startup Error", import_error_message)
         sys.exit(f"Exiting due to import error: {import_error_message}") # Exit if critical modules failed

    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(sys.argv)

    window = CaseEnquiry()
    window.show()
    sys.exit(app.exec_())