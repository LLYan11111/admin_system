import sys
import os # Added
import pyodbc # Added
import base64 # Added
import re # Added
from dotenv import load_dotenv # Added
from datetime import datetime

# --- Ensure direct imports for modules in the same directory ---
import_error_message = None
try:
    import sqlcrypt
    import myCrypt
    print("Successfully imported local modules (sqlcrypt, myCrypt).")
except ImportError as e:
    error_msg = f"ERROR: Failed direct import: {e}. Ensure sqlcrypt.py and myCrypt.py are in the 'rebuild' directory."
    print(error_msg)
    import_error_message = error_msg
    sqlcrypt = None
    myCrypt = None

from PyQt5 import QtWidgets, QtGui, QtCore

# --- Load .env file (Important for DB credentials) ---
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
if not os.path.exists(dotenv_path):
    print(f"ERROR: .env file not found at {dotenv_path}")
    if not import_error_message:
         import_error_message = f".env file not found at the expected location: {dotenv_path}"
else:
    load_dotenv(dotenv_path=dotenv_path)
    print(f".env file loaded from {dotenv_path}")

# --- Constants for Data Fetching/Decryption ---
KEY_ID_TO_USE = 1 # Default key ID to use for decryption
BASE64_REGEX = re.compile(r'^[A-Za-z0-9+/]*={0,2}$') # Basic check for base64 format
MIN_ENCRYPTED_LEN = 24 # Heuristic minimum length for potentially encrypted data
# --- NEW SQL STRING ---
SQL_string = "SELECT TOP (100) ACNO, RefNo, ACName, HKID FROM [ICSBK_2].[dbo].[case]" # Select specific columns
# --- Column names expected by the query (must match SELECT statement) ---
EXPECTED_COLUMNS = ["ACNO", "RefNo", "ACName", "HKID"]

# --- Reusing Styles from CaseEnquiry (or define similar ones) ---
BASE_FONT = "'Segoe UI', Arial"
FONT_SIZE_NORMAL = "13px"
COLOR_BACKGROUND = "#F5F5F5"
COLOR_CONTENT_BACKGROUND = "#FFFFFF" # Corrected typo here
COLOR_BORDER = "#CCCCCC"
COLOR_TEXT_PRIMARY = "#222222"
COLOR_TABLE_FG = COLOR_TEXT_PRIMARY # Define COLOR_TABLE_FG using COLOR_TEXT_PRIMARY
COLOR_ACCENT = "#0078D4"
COLOR_TABLE_HEADER_BG = "#E1E1E1"
COLOR_TABLE_HEADER_FG = "#333333"
COLOR_HIGHLIGHT = "#0078D4" # Assuming this is the highlight color you want to use
COLOR_BUTTON_BG = "#E1E1E1"
COLOR_BUTTON_FG = "#222222"
COLOR_BUTTON_HOVER_BG = "#D1D1D1"
COLOR_BUTTON_PRESSED_BG = "#C1C1C1"

# --- Define style constants WITHOUT outer selectors/braces ---

TABLE_STYLE_RULES = f"""
    background-color: {COLOR_CONTENT_BACKGROUND}; /* Use CSS comment if needed */
    color: {COLOR_TABLE_FG};
    gridline-color: {COLOR_BORDER};
    border: 1px solid {COLOR_BORDER};
    font-size: {FONT_SIZE_NORMAL};
    font-family: {BASE_FONT};
"""

TABLE_ITEM_STYLE_RULES = f"""
    padding: 4px;
    border-bottom: 1px solid {COLOR_BORDER};
    border-right: 1px dotted {COLOR_BORDER};
"""

TABLE_ITEM_SELECTED_STYLE_RULES = f"""
    background-color: {COLOR_HIGHLIGHT};
    color: white;
"""

TABLE_HEADER_STYLE_RULES = f"""
    background-color: {COLOR_TABLE_HEADER_BG};
    color: {COLOR_TABLE_HEADER_FG};
    padding: 4px;
    border: 1px solid {COLOR_BORDER};
    font-weight: bold;
    font-size: {FONT_SIZE_NORMAL};
    font-family: {BASE_FONT};
"""

BUTTON_STYLE_RULES = f"""
    background-color: {COLOR_BUTTON_BG};
    color: {COLOR_BUTTON_FG};
    border: 1px solid {COLOR_BORDER};
    border-radius: 3px;
    padding: 5px 15px;
    font-size: {FONT_SIZE_NORMAL};
    font-family: {BASE_FONT};
    min-height: 25px;
    min-width: 100px;
"""

BUTTON_HOVER_STYLE_RULES = f"background-color: {COLOR_BUTTON_HOVER_BG};"
BUTTON_PRESSED_STYLE_RULES = f"background-color: {COLOR_BUTTON_PRESSED_BG};"


class CaseList(QtWidgets.QDialog):
    """
    A dialog to display a list of cases in a table, allowing selection.
    """
    def __init__(self, data, parent=None):
        """
        Initializes the CaseList dialog.
        Args:
            data (list): A list of lists, where each inner list represents a row.
                         Expected order: [ac_no, ref_no, ac_name, hkid]
            parent: The parent widget.
        """
        super().__init__(parent)
        self.selected_data = None
        # Ensure data is a list, even if None is passed
        self._data = data if data is not None else []
        self.setWindowTitle("Case List")
        self._configure_window()
        self.init_ui()
        self.populate_table()

    def _configure_window(self):
        """Configures basic window properties."""
        self.setMinimumSize(600, 400) # Set a minimum size

        # --- Construct the stylesheet correctly ---
        style_string = f"""
            QDialog {{
                background-color: {COLOR_BACKGROUND};
            }}
            QWidget {{
                font-family: {BASE_FONT};
                font-size: {FONT_SIZE_NORMAL};
            }}
            QTableWidget {{
                {TABLE_STYLE_RULES}
            }}
            QTableWidget::item {{
                {TABLE_ITEM_STYLE_RULES}
            }}
            QTableWidget::item:selected {{
                {TABLE_ITEM_SELECTED_STYLE_RULES}
            }}
            QHeaderView::section {{
                {TABLE_HEADER_STYLE_RULES}
            }}
            QPushButton {{
                {BUTTON_STYLE_RULES}
            }}
            QPushButton:hover {{
                {BUTTON_HOVER_STYLE_RULES}
            }}
            QPushButton:pressed {{
                {BUTTON_PRESSED_STYLE_RULES}
            }}
        """
        self.setStyleSheet(style_string)
        # Make the dialog modal
        self.setWindowModality(QtCore.Qt.ApplicationModal)

    def init_ui(self):
        """Initializes the UI components."""
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # --- Table Widget ---
        self.table_widget = QtWidgets.QTableWidget()
        # Set column count based on EXPECTED_COLUMNS
        self.table_widget.setColumnCount(len(EXPECTED_COLUMNS))
        # Set headers based on EXPECTED_COLUMNS
        self.table_widget.setHorizontalHeaderLabels(["A/C No", "Ref No", "A/C Name", "HK ID"]) # User-friendly headers
        self.table_widget.verticalHeader().setVisible(False)
        self.table_widget.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table_widget.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table_widget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table_widget.horizontalHeader().setStretchLastSection(True)
        self.table_widget.itemDoubleClicked.connect(self.accept_selection) # Double-click selects

        # Adjust column widths (example)
        self.table_widget.setColumnWidth(0, 150) # ACNO
        self.table_widget.setColumnWidth(1, 80)  # RefNo
        self.table_widget.setColumnWidth(2, 200) # ACName
        # Last column (HK ID) will stretch

        layout.addWidget(self.table_widget)

        # --- Button Layout ---
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch() # Push buttons to the right

        self.select_button = QtWidgets.QPushButton("ENTER - SELECT")
        self.cancel_button = QtWidgets.QPushButton("ESC - CANCEL")

        self.select_button.clicked.connect(self.accept_selection)
        self.cancel_button.clicked.connect(self.reject) # QDialog's reject slot

        button_layout.addWidget(self.select_button)
        button_layout.addWidget(self.cancel_button)
        button_layout.addStretch() # Center buttons horizontally

        layout.addLayout(button_layout)

    def populate_table(self):
        """Fills the table with the provided data."""
        print(f"--- CaseList.populate_table START ---") # DEBUG
        if not hasattr(self, 'table_widget'):
            print("ERROR: self.table_widget does not exist!") # DEBUG
            return
        if self._data is None:
            print("WARNING: self._data is None.") # DEBUG
            self._data = [] # Ensure it's an empty list to avoid errors below

        print(f"Populating table with {len(self._data)} rows.") # DEBUG
        if self._data:
            print(f"Data sample (first row): {self._data[0]}") # DEBUG

        try:
            self.table_widget.setRowCount(0) # Clear existing rows first
            self.table_widget.setRowCount(len(self._data))
            print(f"Table row count set to {self.table_widget.rowCount()}") # DEBUG

            expected_cols = self.table_widget.columnCount()
            print(f"Expected columns: {expected_cols}") # DEBUG

            for row_idx, row_data in enumerate(self._data):
                # print(f"Processing row {row_idx}: {row_data}") # DEBUG (can be verbose)
                if len(row_data) != expected_cols:
                     print(f"WARNING: Row {row_idx} has {len(row_data)} items, expected {expected_cols}. Skipping. Data: {row_data}") # DEBUG
                     continue

                for col_idx, item_data in enumerate(row_data):
                    try:
                        item_text = str(item_data) if item_data is not None else "" # Ensure data is string, handle None
                        item = QtWidgets.QTableWidgetItem(item_text)
                        self.table_widget.setItem(row_idx, col_idx, item)
                        # print(f"  Set item at ({row_idx}, {col_idx}) to '{item_text}'") # DEBUG (very verbose)
                    except Exception as e_inner:
                        print(f"ERROR setting item at ({row_idx}, {col_idx}): {e_inner}") # DEBUG

            # Select the first row by default if data exists
            if self.table_widget.rowCount() > 0:
                self.table_widget.selectRow(0)
                print("Selected first row.") # DEBUG
            else:
                print("No rows to select.") # DEBUG

        except Exception as e_outer:
            print(f"ERROR during populate_table: {e_outer}") # DEBUG

        print(f"--- CaseList.populate_table END ---") # DEBUG

    def accept_selection(self):
        """Handles the selection confirmation."""
        selected_items = self.table_widget.selectedItems()
        if selected_items:
            selected_row = self.table_widget.currentRow()
            if 0 <= selected_row < len(self._data): # Bounds check
                 self.selected_data = self._data[selected_row] # Store the original data list
                 self.accept() # QDialog's accept slot
            else:
                 print(f"ERROR: Selected row index {selected_row} out of bounds for data length {len(self._data)}")
                 QtWidgets.QMessageBox.warning(self, "Selection Error", "Invalid row selected.")
        else:
            # Optionally show a message if nothing is selected
            QtWidgets.QMessageBox.warning(self, "No Selection", "Please select a case.")


    def keyPressEvent(self, event):
        """Handle Enter and Escape keys."""
        if event.key() == QtCore.Qt.Key_Return or event.key() == QtCore.Qt.Key_Enter:
            self.accept_selection()
        elif event.key() == QtCore.Qt.Key_Escape:
            self.reject()
        else:
            super().keyPressEvent(event)

    # --- ADD THIS STATIC METHOD ---
    @staticmethod
    def get_case(ref_no, key_id=KEY_ID_TO_USE):
        """
        Fetches the complete details for a single case by RefNo and decrypts fields.

        Args:
            ref_no (str): The RefNo of the case to fetch.
            key_id (int): The ID of the decryption key to use.

        Returns:
            dict or None: A dictionary containing all fields and their (decrypted) values,
                          or None if the case is not found or an error occurs.
        """
        print(f"--- get_case called for RefNo: {ref_no} ---")

        # Use Decimal for financial data if needed
        from decimal import Decimal # Import Decimal here or at the top

        if sqlcrypt is None or myCrypt is None:
            print(f"ERROR (get_case): Missing sqlcrypt or myCrypt modules.")
            return None

        decryption_key = None
        conn = None
        cursor = None
        case_details = None

        # 1. Get Decryption Key
        try:
            decryption_key = myCrypt.getkeyfromkeydb(key_id)
            if not decryption_key:
                print(f"ERROR (get_case): Failed to retrieve decryption key for ID {key_id}.")
                return None
        except Exception as e:
            print(f"ERROR (get_case) retrieving decryption key: {e}")
            return None

        # 2. Connect and Fetch Data
        try:
            conn = sqlcrypt.connect_to_mssql()
            if not conn:
                print("ERROR (get_case): Failed to connect to the database.")
                return None
            cursor = conn.cursor()

            query = "SELECT * FROM [ICSBK_2].[dbo].[case] WHERE RefNo = ?"
            print(f"Executing query: {query} with param: '{ref_no}'")
            cursor.execute(query, (ref_no,))
            row = cursor.fetchone()

            if row:
                print("Record found. Processing and decrypting...")
                columns = [column[0] for column in cursor.description]
                case_details = {}
                for i, col_name in enumerate(columns):
                    value = row[i]
                    display_value = value # Default

                    # Decrypt if necessary
                    if isinstance(value, str) and len(value) >= MIN_ENCRYPTED_LEN and BASE64_REGEX.match(value):
                        try:
                            decrypted_value = sqlcrypt.sql_decrypt_with_iv(value, key=decryption_key, debug=False)
                            if decrypted_value is not None:
                                display_value = decrypted_value
                                # print(f"  Decrypted field '{col_name}'") # Optional debug
                            # else: keep original if decryption returns None
                        except Exception as decrypt_err:
                            print(f"  WARNING (get_case): Error decrypting field '{col_name}': {decrypt_err}. Using original.")
                            display_value = value # Use original on error

                    # Store original or decrypted value (handle Decimal conversion if needed)
                    # Example: Convert specific fields known to be numeric/decimal
                    # if col_name in ["ASSAMOUNT", "LATEFEE", "INTEREST", "LEGALCH", "OTHERSFEE", "OSAMOUNT", "COMMISSION", "COMRATE", "TOTALB", "TOTALPAID", "TOTALBP", "TOTALOAPAI", "OAREMAIN", "DISAMOUNT", "SETTLEAMT", "INCOME"] and display_value is not None and display_value != '':
                    #     try:
                    #         case_details[col_name] = Decimal(display_value)
                    #     except (ValueError, TypeError, InvalidOperation):
                    #         print(f"  WARNING (get_case): Could not convert '{col_name}' value '{display_value}' to Decimal. Storing as is.")
                    #         case_details[col_name] = display_value # Store original string on conversion error
                    # else:
                    case_details[col_name] = display_value # Store other types as they are

                print("Processing complete.")

            else:
                print(f"No record found for RefNo: {ref_no}")
                case_details = None # Explicitly set to None if not found

        except pyodbc.Error as db_error:
            print(f"Database error during get_case: {db_error}")
            case_details = None
        except Exception as e:
            print(f"An unexpected error occurred during get_case: {e}")
            import traceback
            traceback.print_exc()
            case_details = None
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
                print("Database connection for get_case closed.")

        return case_details
    # --- END OF get_case METHOD ---

    @staticmethod
    def get_selected_case(parent=None, key_id=KEY_ID_TO_USE):
        """
        Static method to fetch data using SQL_string, decrypt, create, show the dialog,
        and return the RefNo of the selected case. Also prints full details of the selected case.

        Args:
            parent: The parent widget.
            key_id (int): The ID of the decryption key to use.

        Returns:
            str or None: The RefNo of the selected row, or None if cancelled or an error occurs.
        """
        print("--- get_selected_case called (fetching data) ---")

        # Check if necessary modules were imported
        if sqlcrypt is None or myCrypt is None:
             print(f"ERROR: Cannot execute get_selected_case due to import errors: {import_error_message}")
             QtWidgets.QMessageBox.critical(parent, "Import Error", f"Cannot fetch case data due to missing modules:\n{import_error_message}")
             return None

        decryption_key = None
        conn_list = None # Connection for the list
        cursor_list = None
        fetched_data = [] # List to hold processed data for the dialog

        # 1. Get Decryption Key (Remains the same)
        try:
            print(f"Attempting to get decryption key with ID: {key_id}")
            decryption_key = myCrypt.getkeyfromkeydb(key_id)
            if not decryption_key:
                print(f"ERROR: Failed to retrieve decryption key for ID {key_id}.")
                QtWidgets.QMessageBox.critical(parent, "Key Error", f"Could not retrieve decryption key (ID: {key_id}).")
                return None
            print("Decryption key retrieved successfully.")
        except AttributeError:
             print("ERROR: myCrypt module or getkeyfromkeydb function not available.")
             QtWidgets.QMessageBox.critical(parent, "Code Error", "myCrypt module or getkeyfromkeydb function not found.")
             return None
        except Exception as e:
            print(f"ERROR retrieving decryption key: {e}")
            QtWidgets.QMessageBox.critical(parent, "Key Error", f"Error retrieving decryption key:\n{e}")
            return None

        # 2. Connect and Fetch Data for List (Remains the same)
        try:
            print("Attempting database connection for list...")
            conn_list = sqlcrypt.connect_to_mssql()
            if not conn_list:
                print("ERROR: Failed to connect to the database for list.")
                return None
            print("Database connection for list successful.")
            cursor_list = conn_list.cursor()

            print(f"Executing query for list: {SQL_string}")
            cursor_list.execute(SQL_string)
            rows = cursor_list.fetchall()
            print(f"Fetched {len(rows)} rows from database for list.")

            # 3. Process and Decrypt Rows for List (Remains the same)
            if rows:
                db_columns = [column[0] for column in cursor_list.description]
                col_indices = {name: idx for idx, name in enumerate(db_columns)}
                missing_cols = [name for name in EXPECTED_COLUMNS if name not in col_indices]
                if missing_cols:
                    print(f"ERROR: Query result missing expected columns: {missing_cols}")
                    QtWidgets.QMessageBox.critical(parent, "Query Error", f"Database query result is missing columns:\n{', '.join(missing_cols)}")
                    return None

                for row in rows:
                    processed_row = []
                    for col_name in EXPECTED_COLUMNS:
                        col_idx = col_indices[col_name]
                        value = row[col_idx]
                        if isinstance(value, str) and len(value) >= MIN_ENCRYPTED_LEN and BASE64_REGEX.match(value):
                            try:
                                decrypted_value = sqlcrypt.sql_decrypt_with_iv(value, key=decryption_key, debug=False)
                                processed_row.append(decrypted_value if decrypted_value is not None else value)
                            except Exception as decrypt_err:
                                print(f"  ERROR decrypting {col_name}: {decrypt_err}")
                                processed_row.append(value)
                        else:
                            processed_row.append(value)
                    fetched_data.append(processed_row)

            print(f"Processed {len(fetched_data)} rows for dialog.")

        except pyodbc.Error as db_error:
            print(f"Database error during data retrieval: {db_error}")
            QtWidgets.QMessageBox.critical(parent, "Database Error", f"Error fetching case list:\n{db_error}")
            return None
        except AttributeError as ae:
             print(f"AttributeError during DB operation: {ae}. Is sqlcrypt.py complete?")
             QtWidgets.QMessageBox.critical(parent, "Code Error", f"Error calling database function:\n{ae}")
             return None
        except Exception as e:
            print(f"An unexpected error occurred fetching data: {e}")
            import traceback
            traceback.print_exc()
            QtWidgets.QMessageBox.critical(parent, "Error", f"An unexpected error occurred fetching case list:\n{e}")
            return None
        finally:
            if cursor_list:
                cursor_list.close()
            if conn_list:
                conn_list.close()
                print("Database connection for list closed.")

        # 4. Show Dialog with Fetched Data (Remains the same)
        dialog = CaseList(fetched_data, parent)
        result = dialog.exec_()

        # 5. Process Selection and Fetch/Print Full Details
        if result == QtWidgets.QDialog.Accepted and dialog.selected_data:
            selected_ref_no = None
            try:
                # Extract RefNo
                selected_ref_no = str(dialog.selected_data[1]) # Index 1 corresponds to 'RefNo'
                print(f"CaseList returning selected RefNo: {selected_ref_no}")

                # --- NEW: Query and Print Full Details ---
                print(f"\n--- Fetching full details for selected RefNo: {selected_ref_no} ---")
                conn_detail = None
                cursor_detail = None
                try:
                    # Define the query string using a parameter placeholder (?)
                    quiry_string = "SELECT * FROM [ICSBK_2].[dbo].[case] WHERE RefNo = ?"

                    print("Attempting database connection for details...")
                    conn_detail = sqlcrypt.connect_to_mssql()
                    if conn_detail:
                        print("Database connection for details successful.")
                        cursor_detail = conn_detail.cursor()

                        print(f"Executing detail query: {quiry_string} with param: '{selected_ref_no}'")
                        # Execute with parameter to prevent SQL injection
                        cursor_detail.execute(quiry_string, (selected_ref_no,))
                        detail_row = cursor_detail.fetchone()

                        if detail_row:
                            print("--- Full Record Details ---")
                            columns = [column[0] for column in cursor_detail.description]
                            record_details = dict(zip(columns, detail_row))

                            # --- MODIFICATION START: Decrypt and Print ---
                            for field, value in record_details.items():
                                display_value = value # Default to original value
                                decrypted = False # Flag to indicate if decryption was attempted

                                # Check if value looks like it needs decryption
                                if isinstance(value, str) and len(value) >= MIN_ENCRYPTED_LEN and BASE64_REGEX.match(value):
                                    try:
                                        # Attempt decryption using the same key
                                        decrypted_value = sqlcrypt.sql_decrypt_with_iv(value, key=decryption_key, debug=False)
                                        if decrypted_value is not None:
                                            display_value = decrypted_value # Use decrypted value
                                            decrypted = True
                                        # else: keep original value if decryption returns None
                                    except Exception as decrypt_detail_err:
                                        # Keep original value on decryption error
                                        print(f"  WARNING: Error decrypting field '{field}': {decrypt_detail_err}. Displaying original.")
                                        display_value = value # Ensure original value is used

                                # Format the display value (handle None, datetime, etc.)
                                if display_value is None:
                                    formatted_display = ""
                                elif isinstance(display_value, datetime):
                                    formatted_display = display_value.strftime("%Y-%m-%d %H:%M:%S") # Example format
                                elif not isinstance(display_value, (str, int, float)): # Avoid printing raw bytes etc.
                                     formatted_display = f"<{type(display_value).__name__}>"
                                else:
                                     formatted_display = str(display_value)

                                # Print field name and formatted value
                                print(f"  {field}: {formatted_display}" + ("" if decrypted else ""))
                            # --- MODIFICATION END ---

                            print("---------------------------\n")
                        else:
                            print(f"ERROR: Could not find record details for RefNo {selected_ref_no} in the second query.")

                    else:
                        print("ERROR: Failed to connect to database for details.")

                except pyodbc.Error as db_detail_error:
                    print(f"Database error during detail retrieval: {db_detail_error}")
                except Exception as detail_error:
                    print(f"An unexpected error occurred during detail retrieval: {detail_error}")
                finally:
                    if cursor_detail:
                        cursor_detail.close()
                    if conn_detail:
                        conn_detail.close()
                        print("Database connection for details closed.")
                # --- END NEW SECTION ---

                return selected_ref_no # Return the RefNo as before

            except (IndexError, TypeError) as e:
                 print(f"ERROR extracting RefNo from selected data ({dialog.selected_data}): {e}")
                 QtWidgets.QMessageBox.warning(parent, "Selection Error", "Could not get RefNo from the selected row.")
                 return None
            except Exception as final_e: # Catch any other unexpected error in this block
                 print(f"An unexpected error occurred after selection: {final_e}")
                 return None # Return None if something went wrong after selection
        else:
            print("CaseList dialog cancelled or no selection.")
            return None
    # --- END MODIFIED STATIC METHOD ---


# Example usage (for testing CaseList directly)
if __name__ == "__main__":
    # Check for import errors before creating the app
    if import_error_message:
         print(f"Critical import error detected:\n{import_error_message}")
         sys.exit(f"Exiting due to import error: {import_error_message}")

    app = QtWidgets.QApplication(sys.argv)
    print("\n--- Testing get_selected_case (Dialog with DB data) ---")
    selected = CaseList.get_selected_case()
    if selected:
        print("\nSelected Case from Dialog:", selected)
    else:
        print("\nDialog cancelled or no data.")
    sys.exit() # Exit after testing