import os
import sqlcrypt
import migrate_to_mssql
# import reencrypt_demo
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def demo_migration():
    """Run the migration from DBF to MSSQL"""
    print("=== STARTING MIGRATION FROM DBF TO MSSQL ===")
    migrate_to_mssql.migrate_dbf_to_mssql()
    print("=== MIGRATION COMPLETE ===\n")

def demo_encryption():
    """Demonstrate the encryption/decryption functionality"""
    print("=== DEMONSTRATING ENCRYPTION/DECRYPTION ===")
    
    # Create encryption keys table if it doesn't exist
    sqlcrypt.ensure_key_table_exists()
    
    # Store a new encryption key
    key_name = "application_key"
    key_value = "MySecretKey123!"
    key_id = sqlcrypt.store_encryption_key(key_name, key_value)
    
    if key_id:
        print(f"Created new encryption key with ID: {key_id}")
        
        # Encrypt some data using the key
        plain_text = "This is sensitive information"
        encrypted_text = sqlcrypt.sql_encrypt(plain_text, key_id)
        print(f"Encrypted: {encrypted_text}")
        
        # Decrypt the data
        decrypted_text = sqlcrypt.sql_decrypt(encrypted_text)
        print(f"Decrypted: {decrypted_text}")
        
        # Show backward compatibility with old format
        old_format = "ylAcVkA9lcNSsUbl1Xb5uQ==::"  # From test.py
        decrypted_old = sqlcrypt.sql_decrypt(old_format)
        print(f"Decrypted (old format): {decrypted_old}")
    
    print("=== ENCRYPTION DEMO COMPLETE ===\n")

def demo_reencryption():
    """Demonstrate the re-encryption from old format to new format"""
    print("=== DEMONSTRATING RE-ENCRYPTION ===")
    reencrypt_demo.demo_reencryption()
    print("=== RE-ENCRYPTION DEMO COMPLETE ===\n")

def demo_query():
    """Demonstrate querying with encryption/decryption"""
    print("=== DEMONSTRATING ENCRYPTED QUERIES ===")
    
    # Insert data with encryption
    sql = "INSERT INTO encrypted_demo (name, sensitive_data) VALUES (?, ?)"
    params = ["John Doe", "Social Security: 123-45-6789"]
    encrypted_param_indices = [1]  # Encrypt the second parameter (sensitive_data)
    
    result = sqlcrypt.execute_encrypted_sql(sql, params, encrypted_param_indices)
    print(f"Inserted encrypted data: {result}")
    
    # Query with automatic decryption
    sql = "SELECT name, sensitive_data FROM encrypted_demo"
    encrypted_fields = ["sensitive_data"]
    
    results = sqlcrypt.query_with_decryption(sql, encrypted_fields=encrypted_fields)
    print(f"Query results with decryption: {results}")
    
    print("=== QUERY DEMO COMPLETE ===\n")

def demo_iv_encryption():
    """Demonstrate the new encryption with IV stored in front"""
    print("=== DEMONSTRATING IV-BASED ENCRYPTION ===")
    
    # Create sample data
    plain_text = "This is a secret message that needs strong encryption"
    encryption_key = "my_secure_encryption_key"  #myCrypt.getkeyfromkeydb(1)
    
    # Encrypt using the new method (IV in front)
    encrypted = sqlcrypt.sql_encrypt_with_iv(plain_text, encryption_key)
    print(f"Encrypted with IV in front: {encrypted}")
    
    # Decrypt the data
    decrypted = sqlcrypt.sql_decrypt_with_iv(encrypted, encryption_key)
    print(f"Decrypted: {decrypted}")
    print(f"Decryption successful: {plain_text == decrypted}")
    
    # Show detailed technical information about the format
    encrypted_bytes = sqlcrypt.base64.b64decode(encrypted)
    iv = encrypted_bytes[:16]  # First 16 bytes are the IV
    ciphertext = encrypted_bytes[16:]  # The rest is the ciphertext
    
    print(f"\nTechnical details:")
    print(f"  - IV (hexadecimal): {iv.hex()}")
    print(f"  - Ciphertext length: {len(ciphertext)} bytes")
    print(f"  - Total encrypted length: {len(encrypted_bytes)} bytes")
    
    print("=== IV-BASED ENCRYPTION DEMO COMPLETE ===\n")

def setup_demo_table():
    """Create a demo table for encrypted data"""
    print("=== SETTING UP DEMO TABLE ===")
    
    sql = """
    IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'encrypted_demo')
    BEGIN
        CREATE TABLE encrypted_demo (
            id INT PRIMARY KEY IDENTITY(1,1),
            name VARCHAR(100) NOT NULL,
            sensitive_data VARCHAR(255) NULL,
            created_date DATETIME DEFAULT GETDATE()
        )
    END
    """
    
    result = sqlcrypt.execute_encrypted_sql(sql)
    print(f"Demo table setup result: {result}")
    print("=== DEMO TABLE SETUP COMPLETE ===\n")

if __name__ == "__main__":
    print("MSSQL Encryption and Migration Demo")
    print("===================================\n")
    
    choice = input("Select demo:\n1. Migration\n2. Encryption\n3. Query\n4. Re-encryption\n5. IV-based Encryption\n6. Run All\n7. Setup demo table\nChoice: ")
    
    if choice == "1":
        demo_migration()
    elif choice == "2":
        demo_encryption()
    elif choice == "3":
        setup_demo_table()
        demo_query()
    elif choice == "4":
        demo_reencryption()
    elif choice == "5":
        demo_iv_encryption()
    elif choice == "6":
        setup_demo_table()
        demo_migration()
        demo_encryption()
        demo_reencryption()
        demo_iv_encryption()
        demo_query()
    elif choice == "7":
        setup_demo_table()
    else:
        print("Invalid choice.") 