import sqlcrypt
import myCrypt 
import sys
import base64 
import re # Import regular expressions
from dotenv import load_dotenv 
import os 
import pyodbc # Import pyodbc for database interaction

# Load environment variables from .env file
load_dotenv() 

# --- Configuration ---
KEY_ID_TO_USE = 1 
# Regular expression to check for Base64-like strings (allows A-Z, a-z, 0-9, +, /, =)
BASE64_REGEX = re.compile(r'^[A-Za-z0-9+/]*={0,2}$')
# Minimum length for a string to be considered potentially encrypted (IV + some data)
MIN_ENCRYPTED_LEN = 24 

# --- Get Decryption Key ---
decryption_key = None
print(f"--- Attempting to retrieve decryption key from KeyDB (keyid={KEY_ID_TO_USE}) ---")
try:
    decryption_key = myCrypt.getkeyfromkeydb(KEY_ID_TO_USE)
    if decryption_key:
        print("Key retrieved successfully.")
    else:
        print(f"Warning: Failed to retrieve key with ID {KEY_ID_TO_USE} from KeyDB. Decryption attempts might fail.")
except Exception as e:
    print(f"Error retrieving decryption key: {e}")
    print("Decryption will not be possible.")

# --- Database Query Section ---
print("\n--- Connecting to MSSQL and querying TOP 5 cases ---")
conn = None # Initialize connection variable
cursor = None # Initialize cursor variable
rows = [] # Initialize rows to an empty list
columns = [] # Initialize columns to an empty list

try:
    # Connect to the database using the function that reads .env
    conn = sqlcrypt.connect_to_mssql()

    if conn:
        print("Successfully connected to the database.")
        cursor = conn.cursor()

        # Define the SQL query
        sql_query = "SELECT TOP 1 * FROM [ICSBK_2].[dbo].[case]" # Using TOP 5 as per initial request

        print(f"Executing query: {sql_query}")
        cursor.execute(sql_query)

        # Get column names from cursor description *before* fetching
        columns = [column[0] for column in cursor.description]

        # Fetch all the results
        # Fetch as list of dictionaries for easier access by column name
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]

        if rows:
            print(f"\nQuery Results (TOP {len(rows)}):")
            
            # --- Process and Display Results with Automatic Decryption Attempt ---
            for i, row_dict in enumerate(rows):
                print(f"\n--- Record {i+1} ---")
                max_col_width = max(len(col) for col in columns) 
                
                for col_name in columns:
                    original_value = row_dict.get(col_name)
                    display_value = original_value # Start with the original value

                    # Attempt decryption ONLY if we have a key AND the value looks like potential encrypted data
                    if (decryption_key and 
                        isinstance(original_value, str) and 
                        len(original_value) >= MIN_ENCRYPTED_LEN and 
                        len(original_value) % 4 == 0 and 
                        BASE64_REGEX.match(original_value)):
                        
                        try:
                            # Try to decrypt using the IV-based method
                            decrypted = sqlcrypt.sql_decrypt_with_iv(original_value, decryption_key, debug=False) 

                            if decrypted is not None:
                                # If decryption succeeds and returns a non-None value
                                display_value = f"{decrypted} (Decrypted)"
                            # else: 
                                # If sql_decrypt_with_iv returns None (e.g., padding error), 
                                # it implies it wasn't encrypted with this key/method.
                                # We keep the original_value as display_value.
                                pass 

                        except (ValueError, base64.binascii.Error, TypeError):
                            # If it's not valid Base64, or decryption fails fundamentally,
                            # assume it's not encrypted data for this key.
                            # Keep the original value.
                            pass # display_value remains original_value
                        except Exception as decrypt_error:
                            # Catch any other unexpected decryption errors
                            print(f"  WARN: Unexpected error decrypting {col_name}: {decrypt_error}")
                            display_value = f"{original_value} (Decryption Error)"

                    # Print the column name and the determined display value
                    # Handle None values gracefully for printing
                    print_val = display_value if display_value is not None else "None"
                    print(f"{col_name:<{max_col_width}} : {print_val}") 
            # --- End of Processing and Display Logic ---

        else:
            print("Query executed successfully, but returned no rows.")

    else:
        print("Failed to establish database connection. Please check .env settings and network.")

except pyodbc.Error as db_err:
    print(f"Database error occurred: {db_err}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

finally:
    # Ensure cursor and connection are closed even if errors occur
    if cursor:
        cursor.close()
        print("\nDatabase cursor closed.")
    if conn:
        conn.close()
        print("Database connection closed.")
# --- End of Database Query Section ---

