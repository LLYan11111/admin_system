import sqlcrypt
import myCrypt # Ensure myCrypt is imported
import sys
import base64 # For catching Base64 errors
from dotenv import load_dotenv # Import dotenv
import os # Import os to read environment variables (though DB_KEY value isn't used directly here)

# Load environment variables from .env file
# This is important for DB connection info potentially needed inside myCrypt.getkeyfromkeydb
load_dotenv() 
# GP5H3v/fVoKJq1Q2UchIViGq8CwrkEj3J4KHlcpU6fE=
# The string to decrypt (from ACNO field in cases table)
encrypted_string = "urOITaRtBSQoQe9DOEHXHxzslWgF264Zflck0gLkUoQ="
print(f"String to decrypt: {encrypted_string}\n")

decryption_key = None   
decryption_successful = False

# --- Attempting to get the key from KeyDB (myCrypt.getkeyfromkeydb(1)) ---
print("--- Attempting to get key from KeyDB (myCrypt.getkeyfromkeydb(1)) ---")
try:
    # Directly call the function to get the key
    decryption_key = myCrypt.getkeyfromkeydb(1) 

    if decryption_key:
        print(f"Successfully retrieved key from KeyDB.")
        print(f"decrypt key: {decryption_key}")
        
        # --- Decrypting using the key obtained from DB ---
        print(f"--- Decrypting using the key obtained from KeyDB ---")
        try:
            # Call the decryption function
            #decoded = base64.b64decode(encrypted_string)
            decrypted_value = sqlcrypt.sql_decrypt_with_iv(encrypted_string, key=decryption_key)

            if decrypted_value is not None:
                print(f"\n*** Decryption Successful! ***")
                print(f"Decrypted using the key from getkeyfromkeydb(1)")
                print(f"Original ACNO value: '{decrypted_value}'")
                decryption_successful = True
            else:
                # This might happen if decryption fails for reasons other than padding, though less common with debug=True
                print("Decryption returned None (possibly not a Padding error, but still failed)") 

        except (ValueError, base64.binascii.Error) as ve:
            # Catch common errors during decryption or Base64 decoding
            print(f"Error during decryption/decoding with KeyDB key: {ve}")
        except Exception as e:
            print(f"Unexpected error during decryption with KeyDB key: {e}")
        
        print("-" * 60 + "\n")

    else:
        print("Failed to retrieve key from KeyDB (myCrypt.getkeyfromkeydb(1) returned None or empty). Please check KeyDB connection and data for keyid=1.")

except Exception as e:
    print(f"Error occurred while trying to call myCrypt.getkeyfromkeydb(1): {e}")
    print("Please ensure the database connection info in the .env file is correct and KeyDB is accessible.")
# --- End of getting and using KeyDB key ---


if not decryption_successful:
    print("\nDecryption failed using the key from myCrypt.getkeyfromkeydb(1).")

# (Optional: Keep or remove the code below that tries other hardcoded keys)
# print("\n--- Attempting other potential hardcoded keys ---")
# potential_key_strings = [ ... ] # List of other keys
# for key_string in potential_key_strings:
#    # ... attempt decryption ...

