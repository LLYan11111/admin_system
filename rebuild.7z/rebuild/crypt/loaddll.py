import clr
import sys

# Add the path to the directory containing the DLL
sys.path.append(r'D:\Simon\Projects\ICS\python\ICSCryptor')

# Load the DLL
clr.AddReference('Utils.NET')

# Import the namespace
from Utils.NET import myCrypt

# Create an instance of the C# class
my_instance = myCrypt()

# Call the method
result = my_instance.Encrypt('aaaa', 3)
print(f"The result is: {result}")
