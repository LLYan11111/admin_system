import os
import pyodbc
import myCrypt as myCrypt
import base64
from dotenv import load_dotenv
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad

# Load environment variables
load_dotenv()

# Database connection parameters
DB_SERVER = os.getenv('DB_SERVER')
DB_NAME = os.getenv('DB_NAME')
DB_USERNAME = os.getenv('DB_USERNAME')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_TRUST_CERTIFICATE = os.getenv('DB_TRUST_CERTIFICATE', 'True') == 'True'

# Connect to MSSQL
def connect_to_mssql():
    conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={DB_SERVER};DATABASE={DB_NAME};UID={DB_USERNAME};PWD={DB_PASSWORD}"
    if DB_TRUST_CERTIFICATE:
        conn_str += ";TrustServerCertificate=yes"
    
    try:
        conn = pyodbc.connect(conn_str)
        return conn
    except Exception as e:
        print(f"Error connecting to MSSQL: {str(e)}")
        return None

# Enhanced encryption for SQL Server with IV stored in front
def sql_encrypt_with_iv(plain_text, key=None, debug=False):
    """
    Encrypt data with IV stored at the beginning of the encrypted content.
    Format: IV + Encrypted Data, then base64 encoded
    
    Args:
        plain_text: The text to encrypt
        key: The encryption key (string or bytes)
        debug: Whether to print debug information
        
    Returns:
        Base64 encoded string containing IV + encrypted data
    """
    if not plain_text:
        return None
    
    # Generate a random key if none provided
    if not key:
        key = get_random_bytes(32)  # AES-256 key
    elif isinstance(key, str):
        # If key is a string, convert to bytes and hash it to get 32 bytes
        key = myCrypt.hashlib.sha256(key.encode('utf-8')).digest()
    
    if debug:
        print(f"Encryption key (hex): {key.hex()}")
        print(f"Plain text length: {len(plain_text)} characters")
    
    # Generate a random IV
    iv = get_random_bytes(16)  # AES block size
    
    # Create cipher and encrypt
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_data = pad(plain_text.encode('utf-8'), AES.block_size)
    encrypted_data = cipher.encrypt(padded_data)
    
    # Combine IV + encrypted data and base64 encode
    combined = iv + encrypted_data
    result = base64.b64encode(combined).decode('utf-8')
    
    if debug:
        print(f"IV size: {len(iv)} bytes")
        print(f"IV (hex): {iv.hex()}")
        print(f"Encrypted data size: {len(encrypted_data)} bytes")
        print(f"Total binary size: {len(combined)} bytes")
        print(f"Base64 result length: {len(result)} characters")
    
    return result

# Decrypt data that has IV stored in front
def sql_decrypt_with_iv(cipher_text, key=None, debug=False):
    """
    Decrypt data where IV is stored at the beginning of the encrypted content.
    Expected format: base64(IV + Encrypted Data)
    
    Args:
        cipher_text: Base64 encoded string containing IV + encrypted data
        key: The encryption key (string or bytes)
        debug: Whether to print debug information
        
    Returns:
        Decrypted text
    """
    if not cipher_text:
        return None
    
    try:
        # If key is a string, convert to bytes and hash it to get 32 bytes
        if key and isinstance(key, str):
            key = myCrypt.hashlib.sha256(key.encode('utf-8')).digest()
        elif not key:
            raise ValueError("Decryption key must be provided")
        
        if debug:
            print(f"Decryption key (hex): {key.hex()}")
            print(f"Encrypted text length: {len(cipher_text)} characters")
        
        # Decode the base64 data
        encrypted_data = base64.b64decode(cipher_text)
        
        if debug:
            print(f"Decoded binary size: {len(encrypted_data)} bytes")
        
        # Extract IV (first 16 bytes) and ciphertext
        iv = encrypted_data[:16]
        ciphertext = encrypted_data[16:]
        
        if debug:
            print(f"IV size: {len(iv)} bytes")
            print(f"IV (hex): {iv.hex()}")
            print(f"Encrypted data size: {len(ciphertext)} bytes")
        
        # Create cipher and decrypt
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted_padded = cipher.decrypt(ciphertext)
        
        # Unpad and return
        result = unpad(decrypted_padded, AES.block_size).decode('utf-8')
        
        if debug:
            print(f"Decrypted text length: {len(result)} characters")
        
        return result
    except Exception as e:
        print(f"Error decrypting with IV: {str(e)}")
        return None

# Re-encrypt data from old format to new format
def reencrypt_data(old_encrypted_data):
    """
    Detect old format encryption, decrypt it, and re-encrypt with new format
    Returns: New encrypted data with IV in front
    """
    # Check if it's in the old FoxPro format (ending with ::)
    if isinstance(old_encrypted_data, str) and old_encrypted_data.endswith('::'):
        # Decrypt using the old method
        decrypted = myCrypt.MyDecrypt(old_encrypted_data)
        
        # Re-encrypt with the new method (IV in front)
        # Using a new random key for each re-encryption
        encryption_key = "new_sql_encryption_key"  # In production, retrieve from secure storage
        return sql_encrypt_with_iv(decrypted, encryption_key)
    
    # Not in old format or not encrypted
    return old_encrypted_data

# Migrate encrypted data in a table
def migrate_encrypted_fields(table_name, encrypted_fields, key_name="sql_encryption_key"):
    """
    Migrate encrypted fields in a table from old format to new format
    
    Args:
        table_name: Name of the table
        encrypted_fields: List of field names that are encrypted
        key_name: Name of the encryption key to use
    """
    if not encrypted_fields:
        return
    
    # Get a connection
    conn = connect_to_mssql()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        
        # Get all records that might have old encrypted data
        where_clause = " OR ".join([f"{field} LIKE '%::'" for field in encrypted_fields])
        sql = f"SELECT * FROM {table_name} WHERE {where_clause}"
        cursor.execute(sql)
        
        # Store encryption key if not exists
        encryption_key = f"migration_key_{table_name}"
        key_id = store_encryption_key(key_name, encryption_key)
        
        # For each record, re-encrypt data
        rows_updated = 0
        for row in cursor.fetchall():
            update_fields = []
            update_values = []
            
            record_id = row[0]  # Assuming first column is the ID
            
            for field in encrypted_fields:
                field_idx = cursor.description.index((field.lower(),)) if field.lower() in [col[0].lower() for col in cursor.description] else -1
                if field_idx >= 0:
                    value = row[field_idx]
                    if value and isinstance(value, str) and value.endswith('::'):
                        # Re-encrypt the field
                        decrypted = myCrypt.MyDecrypt(value)
                        reencrypted = sql_encrypt_with_iv(decrypted, encryption_key)
                        
                        update_fields.append(f"{field} = ?")
                        update_values.append(reencrypted)
            
            # Update the record if any fields were re-encrypted
            if update_fields:
                update_sql = f"UPDATE {table_name} SET {', '.join(update_fields)} WHERE {cursor.description[0][0]} = ?"
                update_values.append(record_id)
                cursor.execute(update_sql, update_values)
                rows_updated += 1
        
        conn.commit()
        print(f"Re-encrypted {rows_updated} records in {table_name}")
        
    except Exception as e:
        print(f"Error migrating encrypted fields: {str(e)}")
        conn.rollback()
    finally:
        conn.close()

# Example function for practical use
def sample_encryption_transition():
    """
    Sample code showing how to transition from old to new encryption
    """
    # 1. Old FoxPro encrypted data
    old_encrypted = "ylAcVkA9lcNSsUbl1Xb5uQ==::"  # "test" encrypted in FoxPro format
    
    print(f"Original encrypted data (FoxPro): {old_encrypted}")
    
    # 2. Decrypt using old method
    decrypted = myCrypt.MyDecrypt(old_encrypted)
    print(f"Decrypted data: {decrypted}")
    
    # 3. Re-encrypt with new method (IV in front)
    encryption_key = "sql_server_key"
    new_encrypted = sql_encrypt_with_iv(decrypted, encryption_key)
    print(f"Re-encrypted data (with IV): {new_encrypted}")
    
    # 4. Decrypt with new method
    decrypted_new = sql_decrypt_with_iv(new_encrypted, encryption_key)
    print(f"Decrypted from new format: {decrypted_new}")
    
    # Verify both decrypt to the same result
    print(f"Decryption match: {decrypted == decrypted_new}")
    
    return {
        "old_format": old_encrypted,
        "decrypted": decrypted,
        "new_format": new_encrypted
    }

# New encryption format for SQL Server (compatible with existing code)
def sql_encrypt(plain_text, key_id=None):
    """
    Encrypt data for storage in SQL Server
    For new SQL format: ::$key_id#~base64data
    """
    if not plain_text:
        return None
    
    # If key_id is provided, use the new format
    if key_id:
        # In production, you would get the key from your key management system
        # Here we're using a placeholder
        key = f"key{key_id}"  # Replace with actual key retrieval
        encoded_data = myCrypt.encode_data(plain_text, key)
        return f"::${key_id}{myCrypt.extbase64_encode(encoded_data)}"
    else:
        # Use the old format for backward compatibility
        # This is the foxpro format, using the hardcoded key and iv
        cipher_text = myCrypt.aes_encrypt(
            myCrypt.from_hex_string(myCrypt.ivHex),
            myCrypt.from_hex_string(myCrypt.keyHex),
            plain_text.encode('latin1')
        )
        return f"{myCrypt.extbase64_encode(cipher_text)}::"

# Decrypt data from SQL Server
def sql_decrypt(cipher_text):
    """
    Decrypt data from SQL Server
    Handles both old format (foxpro) and new format (SQL Server)
    """
    if not cipher_text:
        return None
    
    # Check for new format: ::$key_id#~base64data
    if cipher_text.startswith('::$'):
        parts = cipher_text[3:].split('#~', 1)
        if len(parts) == 2:
            key_id = parts[0]
            encoded_data = "#~" + parts[1]
            
            # In production, retrieve key using key_id from secure storage
            key = f"key{key_id}"  # Replace with actual key retrieval
            
            decoded_data = myCrypt.extbase64_decode(encoded_data)
            return myCrypt.decode_data(decoded_data, key)
    
    # Handle old format (foxpro)
    elif cipher_text.endswith('::'):
        return myCrypt.MyDecrypt(cipher_text)
    
    # Unknown format
    return cipher_text

# Execute SQL with parameter encryption
def execute_encrypted_sql(sql, params=None, encrypted_param_indices=None):
    """
    Execute SQL with encrypted parameters
    
    Args:
        sql: SQL query with parameter placeholders
        params: List of parameter values
        encrypted_param_indices: List of indices of parameters that should be encrypted
    
    Returns:
        Result of the query
    """
    if params and encrypted_param_indices:
        # Create a copy of params to avoid modifying the original
        encrypted_params = list(params)
        
        # Encrypt specified parameters
        for idx in encrypted_param_indices:
            if idx < len(encrypted_params):
                encrypted_params[idx] = sql_encrypt(encrypted_params[idx])
        
        params = encrypted_params
    
    conn = connect_to_mssql()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        if params:
            cursor.execute(sql, params)
        else:
            cursor.execute(sql)
        
        # Get results if any
        results = []
        if cursor.description:  # If there are columns in the result
            columns = [column[0] for column in cursor.description]
            for row in cursor.fetchall():
                results.append(dict(zip(columns, row)))
        
        conn.commit()
        return results
    except Exception as e:
        print(f"Error executing SQL: {str(e)}")
        conn.rollback()
        return None
    finally:
        conn.close()

# Query with automatic decryption of known encrypted fields
def query_with_decryption(sql, params=None, encrypted_fields=None):
    """
    Execute a query and automatically decrypt specified fields
    
    Args:
        sql: SQL query
        params: Parameters for the query
        encrypted_fields: List of field names that are encrypted
    
    Returns:
        List of dictionaries with decrypted values
    """
    results = execute_encrypted_sql(sql, params)
    
    if not results or not encrypted_fields:
        return results
    
    # Decrypt specified fields
    for row in results:
        for field in encrypted_fields:
            if field in row and row[field]:
                row[field] = sql_decrypt(row[field])
    
    return results

# Create encryption keys table if it doesn't exist
def ensure_key_table_exists():
    """
    Create the encryption keys table if it doesn't exist
    """
    sql = """
    IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'encryption_keys')
    BEGIN
        CREATE TABLE encryption_keys (
            id INT PRIMARY KEY IDENTITY(1,1),
            key_name VARCHAR(50) NOT NULL,
            key_value VARCHAR(255) NOT NULL,
            created_date DATETIME DEFAULT GETDATE(),
            is_active BIT DEFAULT 1
        )
    END
    """
    
    conn = connect_to_mssql()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        return True
    except Exception as e:
        print(f"Error creating encryption_keys table: {str(e)}")
        conn.rollback()
        return False
    finally:
        conn.close()

# Store a new encryption key
def store_encryption_key(key_name, key_value):
    """
    Store a new encryption key
    
    Args:
        key_name: Name or identifier for the key
        key_value: The actual encryption key value
    
    Returns:
        ID of the new key
    """
    # First ensure the table exists
    ensure_key_table_exists()
    
    # Encrypt the key value itself using a master key
    # In production, use a proper key management system
    encrypted_key = myCrypt.encode_data(key_value, "master_key")
    
    sql = """
    INSERT INTO encryption_keys (key_name, key_value)
    VALUES (?, ?)
    SELECT SCOPE_IDENTITY() AS id
    """
    
    conn = connect_to_mssql()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (key_name, encrypted_key))
        result = cursor.fetchone()
        key_id = result[0] if result else None
        conn.commit()
        return key_id
    except Exception as e:
        print(f"Error storing encryption key: {str(e)}")
        conn.rollback()
        return None
    finally:
        conn.close()

# Get an encryption key by ID
def get_encryption_key(key_id):
    """
    Get an encryption key by ID
    
    Args:
        key_id: ID of the key to retrieve
    
    Returns:
        The decrypted key value
    """
    sql = """
    SELECT key_value FROM encryption_keys 
    WHERE id = ? AND is_active = 1
    """
    
    conn = connect_to_mssql()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        cursor.execute(sql, (key_id,))
        result = cursor.fetchone()
        
        if not result:
            return None
        
        # Decrypt the key value using the master key
        encrypted_key = result[0]
        decrypted_key = myCrypt.decode_data(encrypted_key, "master_key")
        
        return decrypted_key
    except Exception as e:
        print(f"Error retrieving encryption key: {str(e)}")
        return None
    finally:
        conn.close() 