import os
import myCrypt
import sqlcrypt
import base64
import re
from dbfread import DBF
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# DBF directory path
DBF_DIR = os.path.join(os.getcwd(), 'DBF')

# Improved detection for encrypted data pattern
def is_encrypted_foxpro(value):
    """
    Check if a value matches the FoxPro encryption pattern:
    - Ends with '::'
    - Often ends with '==::' (base64 padding + marker)
    - Contains valid base64 characters
    """
    if not isinstance(value, str):
        return False
        
    # Must end with ::
    if not value.endswith('::'):
        return False
        
    # Check for base64 pattern (a-zA-Z0-9+/=)
    base64_part = value[:-2]  # Remove the :: suffix
    base64_pattern = re.compile(r'^[A-Za-z0-9+/=]+$')
    
    # Most FoxPro encrypted data will end with ==:: (base64 padding)
    # But some might have =:: (single padding) or just :: (no padding)
    return base64_pattern.match(base64_part) is not None

def decrypt_and_reencrypt_dbf_sample():
    """
    Read actual data from DBF files, find encrypted fields,
    decrypt them, and show how they would be re-encrypted
    """
    print("=== REAL DBF DATA ENCRYPTION/DECRYPTION DEMO ===\n")
    
    # List of DBF files with potential encrypted data
    sensitive_dbf_files = [
        'user.DBF',
        'passlog.DBF',
        'client.dbf',
        'client2.dbf',
        'caselog.DBF',
        'payment.DBF'
    ]
    
    # Example of testing the known pattern from test.py
    test_pattern = 'ylAcVkA9lcNSsUbl1Xb5uQ==::'
    print(f"Testing pattern detection with: {test_pattern}")
    print(f"Is encrypted: {is_encrypted_foxpro(test_pattern)}")
    print(f"Decrypts to: '{myCrypt.MyDecrypt(test_pattern)}'\n")
    
    encryption_key = "sql_server_migration_key"
    total_encrypted_fields = 0
    
    # Check each file for encrypted data
    for dbf_file in sensitive_dbf_files:
        file_path = os.path.join(DBF_DIR, dbf_file)
        
        if not os.path.exists(file_path):
            print(f"File not found: {dbf_file}")
            continue
        
        try:
            # Read DBF file
            table = DBF(file_path, encoding='latin1')
            
            # Get field names
            field_names = [field.name for field in table.fields]
            
            print(f"\n--- Processing {dbf_file} ---")
            print(f"Fields: {', '.join(field_names)}")
            
            # Check first 5 records for encrypted data
            records_to_check = min(5, len(table))
            encrypted_fields = {}
            
            # First pass - detect encrypted fields
            for i, record in enumerate(table):
                if i >= records_to_check:
                    break
                    
                for field_name in field_names:
                    value = record.get(field_name)
                    
                    # Check if it matches encrypted pattern
                    if is_encrypted_foxpro(value):
                        encrypted_fields[field_name] = True
            
            if not encrypted_fields:
                print(f"No encrypted fields found in first {records_to_check} records")
                continue
                
            print(f"Potentially encrypted fields: {', '.join(encrypted_fields.keys())}")
            
            # Second pass - show decryption examples
            for i, record in enumerate(table):
                if i >= records_to_check:
                    break
                
                for field_name in encrypted_fields:
                    value = record.get(field_name)
                    
                    if is_encrypted_foxpro(value):
                        try:
                            # Try to decrypt
                            decrypted = myCrypt.MyDecrypt(value)
                            
                            # Check if decryption looks valid (printable ASCII)
                            is_valid = all(32 <= ord(c) <= 126 for c in decrypted)
                            
                            if is_valid:
                                # Show original and decrypted values
                                print(f"\nRecord #{i+1}, Field: {field_name}")
                                print(f"Encrypted (FoxPro): {value}")
                                print(f"Base64 part: {value[:-2]}")  # Show just the base64 part
                                print(f"Decrypted: '{decrypted}'")
                                
                                # Re-encrypt with new method
                                new_encrypted = sqlcrypt.sql_encrypt_with_iv(decrypted, encryption_key)
                                
                                # Show the components of the new encrypted data
                                raw_data = base64.b64decode(new_encrypted)
                                iv_part = raw_data[:16]
                                encrypted_part = raw_data[16:]
                                
                                print(f"Re-encrypted (SQL): {new_encrypted}")
                                print(f"Components: IV ({len(iv_part)} bytes) + Encrypted data ({len(encrypted_part)} bytes)")
                                
                                # Verify decryption
                                decrypted_new = sqlcrypt.sql_decrypt_with_iv(new_encrypted, encryption_key)
                                print(f"Verification - values match: {decrypted == decrypted_new}")
                                
                                total_encrypted_fields += 1
                                
                                # Only show one good example per file
                                break
                        except Exception as e:
                            # Skip if decryption fails
                            print(f"  Decryption failed for value: {value[:20]}... - {str(e)}")
                
                # Stop if we found an example
                if total_encrypted_fields > i:
                    break
        except Exception as e:
            print(f"Error processing {dbf_file}: {str(e)}")
    
    if total_encrypted_fields == 0:
        print("\nNo valid encrypted data found in the sample records.")
        print("Try increasing the number of records to check or checking different files.")
    else:
        print(f"\nFound and processed {total_encrypted_fields} encrypted fields.")

def scan_all_dbf_for_encryption():
    """
    Scan all DBF files to detect which ones likely contain encrypted data
    """
    print("\n=== SCANNING ALL DBF FILES FOR ENCRYPTED DATA ===\n")
    
    dbf_files = []
    for file in os.listdir(DBF_DIR):
        if file.lower().endswith('.dbf'):
            dbf_files.append(file)
    
    print(f"Found {len(dbf_files)} DBF files in directory")
    
    files_with_encryption = {}
    
    for dbf_file in dbf_files:
        file_path = os.path.join(DBF_DIR, dbf_file)
        
        try:
            # Read DBF file
            table = DBF(file_path, encoding='latin1')
            
            # Get field names
            field_names = [field.name for field in table.fields]
            
            # Check a sample of records
            records_to_check = min(10, len(table))
            encrypted_fields = {}
            encrypted_count = {}
            total_records = len(table)
            
            for i, record in enumerate(table):
                if i >= records_to_check:
                    break
                    
                for field_name in field_names:
                    value = record.get(field_name)
                    
                    # Check if it matches encrypted pattern
                    if is_encrypted_foxpro(value):
                        if field_name not in encrypted_fields:
                            encrypted_fields[field_name] = True
                            encrypted_count[field_name] = 1
                        else:
                            encrypted_count[field_name] += 1
            
            if encrypted_fields:
                files_with_encryption[dbf_file] = {
                    'fields': list(encrypted_fields.keys()),
                    'counts': encrypted_count,
                    'total_records': total_records
                }
                
        except Exception as e:
            print(f"Error scanning {dbf_file}: {str(e)}")
    
    # Display results
    if files_with_encryption:
        print(f"\nFound {len(files_with_encryption)} files with potentially encrypted data:")
        for file, info in files_with_encryption.items():
            print(f"- {file} ({info['total_records']} total records)")
            for field in info['fields']:
                count = info['counts'][field]
                print(f"  Field: {field} - {count}/{min(10, info['total_records'])} records have encrypted data")
    else:
        print("No files with encrypted data found.")

def process_test_example():
    """
    Process the test example from test.py to show encryption/decryption
    """
    print("=== PROCESSING TEST EXAMPLE ===\n")
    
    # The test example from test.py
    test_example = 'ylAcVkA9lcNSsUbl1Xb5uQ==::'
    print(f"Test encrypted data: {test_example}")
    print(f"Format: Base64 encoded data + '::' suffix")
    print(f"Base64 part: {test_example[:-2]}")
    
    # Decrypt the test example
    try:
        decrypted = myCrypt.MyDecrypt(test_example)
        print(f"Decrypted: '{decrypted}'")
        
        # Re-encrypt with new format
        encryption_key = "sql_server_migration_key"
        new_encrypted = sqlcrypt.sql_encrypt_with_iv(decrypted, encryption_key)
        
        # Show the components of the new encrypted data
        raw_data = base64.b64decode(new_encrypted)
        iv_part = raw_data[:16]
        encrypted_part = raw_data[16:]
        
        print("\nRe-encrypted with IV in front:")
        print(f"New encrypted data: {new_encrypted}")
        print(f"Format: Base64 encoded (IV + Encrypted Data)")
        print(f"IV: {iv_part.hex()} ({len(iv_part)} bytes)")
        print(f"Encrypted content: {encrypted_part.hex()} ({len(encrypted_part)} bytes)")
        
        # Verify re-decryption
        decrypted_new = sqlcrypt.sql_decrypt_with_iv(new_encrypted, encryption_key)
        print(f"\nRe-decrypted: '{decrypted_new}'")
        print(f"Verification - values match: {decrypted == decrypted_new}")
        
    except Exception as e:
        print(f"Error processing test example: {str(e)}")

if __name__ == "__main__":
    print("DBF Decryption and Re-encryption Demo")
    print("=====================================")
    
    choice = input("Select action:\n1. Decrypt sample DBF data\n2. Scan all DBF files for encrypted data\n3. Run both\n4. Process test example\nChoice: ")
    
    if choice == "1":
        decrypt_and_reencrypt_dbf_sample()
    elif choice == "2":
        scan_all_dbf_for_encryption()
    elif choice == "3":
        scan_all_dbf_for_encryption()
        decrypt_and_reencrypt_dbf_sample()
    elif choice == "4":
        process_test_example()
    else:
        print("Invalid choice.") 