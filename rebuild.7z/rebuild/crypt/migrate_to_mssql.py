import os
import sys
import pyodbc
import dbfread
import re
from dbfread import DBF
from dotenv import load_dotenv
import myCrypt
import sqlcrypt
import pandas as pd
from tqdm import tqdm

# Load environment variables
load_dotenv()

# Database connection parameters
DB_SERVER = os.getenv('DB_SERVER')
DB_NAME = os.getenv('DB_NAME')
DB_USERNAME = os.getenv('DB_USERNAME')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_TRUST_CERTIFICATE = os.getenv('DB_TRUST_CERTIFICATE', 'True') == 'True'

# DBF directory path
DBF_DIR = os.path.join(os.getcwd(), 'DBF')

# Connect to MSSQL
def connect_to_mssql():
    target_db = DB_NAME
    # Base connection string components using f-string interpolation
    # Escape literal braces for the DRIVER part by doubling them {{}}
    base_conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={DB_SERVER};UID={DB_USERNAME};PWD={DB_PASSWORD}"
    
    # Add Unicode options
    base_conn_str += ";Charset=UTF-8"
    
    if DB_TRUST_CERTIFICATE:
        base_conn_str += ";TrustServerCertificate=yes"
        
    # Add the specific database for target and master connections
    conn_str_target = base_conn_str + f";DATABASE={target_db}"
    conn_str_master = base_conn_str + ";DATABASE=master"
    
    try:
        # First attempt to connect to the target database
        conn = pyodbc.connect(conn_str_target)
        print(f"Successfully connected to {target_db} on {DB_SERVER}")
        return conn
    except pyodbc.Error as ex:
        sqlstate = ex.args[0]
        # Check if the error is 'Cannot open database' (4060)
        if '42000' in sqlstate or '4060' in str(ex):
            print(f"Database '{target_db}' not found or inaccessible. Attempting to create it...")
            try:
                # Connect to master database to create the target database
                # Need autocommit=True for DDL statements like CREATE DATABASE
                conn_master = pyodbc.connect(conn_str_master, autocommit=True)
                cursor_master = conn_master.cursor()
                print(f"Connected to master database. Creating database '{target_db}'...")
                # Use a collation that supports Chinese characters (Chinese_Taiwan_Stroke_CI_AS for Big5/Traditional Chinese)
                cursor_master.execute(f"CREATE DATABASE [{target_db}] COLLATE Chinese_Taiwan_Stroke_CI_AS")
                cursor_master.close()
                conn_master.close()
                print(f"Database '{target_db}' created successfully.")
                
                # Try connecting to the newly created database again
                print(f"Re-attempting connection to '{target_db}'...")
                conn = pyodbc.connect(conn_str_target)
                print(f"Successfully connected to {target_db} after creation.")
                return conn
                
            except pyodbc.Error as create_ex:
                print(f"Error creating database '{target_db}': {str(create_ex)}")
                sys.exit(1)
            except Exception as general_ex:
                 print(f"An unexpected error occurred during database creation or connection: {str(general_ex)}")
                 sys.exit(1)
        else:
            # Different error (e.g., login failed due to credentials)
            print(f"Error connecting to MSSQL: {str(ex)}")
            sys.exit(1)
    except Exception as e:
        # Catch any other unexpected exceptions during connection
        print(f"An unexpected error occurred during initial connection: {str(e)}")
        sys.exit(1)

# Get list of DBF files
def get_dbf_files():
    dbf_files = []
    for file in os.listdir(DBF_DIR):
        if file.lower().endswith('.dbf'):
            dbf_files.append(os.path.join(DBF_DIR, file))
    return dbf_files

# Convert DBF data type to SQL data type
def dbf_to_sql_type(dbf_type, length, decimal_count, field_name=None, table_name=None):
    """
    Convert a DBF data type to SQL Server data type.
    
    Args:
        dbf_type: The DBF field type
        length: The field length
        decimal_count: The decimal count for numeric fields
        field_name: Optional field name for special handling
        table_name: Optional table name for special handling
        
    Returns:
        SQL Server data type as string
    """
    # Special case for SCList table's EDSEC field and other fields that might contain Chinese
    is_chinese_field = False
    
    if table_name and field_name:
        # Known fields that contain Chinese text
        if (table_name.lower() == 'sclist' and field_name.upper() == 'EDSEC') or \
           (field_name.upper() in ['REMARKS', 'DETAIL', 'NOTES', 'DESCRIPTION', 'ADDRESS', 'ADDR']):
            is_chinese_field = True
    
    if dbf_type == 'C':  # Character
        # Use NVARCHAR for character fields to support Unicode properly
        # Double the length for safety, up to 4000, then use MAX
        
        # For fields that might contain Chinese, ensure we use proper collation
        if is_chinese_field:
            if length > 2000:
                return 'NVARCHAR(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS'
            else:
                safe_length = min(length * 2, 4000)
                return f"NVARCHAR({safe_length}) COLLATE Chinese_Taiwan_Stroke_CI_AS"
        else:
            if length > 2000: # Use MAX for very long defined lengths
                return 'NVARCHAR(MAX)'
            else:
                # Double the length to provide buffer, but cap at 4000
                safe_length = min(length * 2, 4000)
                return f"NVARCHAR({safe_length})"
    elif dbf_type == 'N':  # Numeric
        if decimal_count > 0:
            return f"DECIMAL({length}, {decimal_count})"
        else:
            # Use BIGINT for large integers if length > 9
            return f"INT" if length <= 9 else f"BIGINT"
    elif dbf_type == 'F':  # Float
        return f"FLOAT"
    elif dbf_type == 'L':  # Logical (Boolean)
        return "BIT"
    elif dbf_type == 'D':  # Date
        return "DATE"
    elif dbf_type == 'T':  # DateTime
        return "DATETIME"
    elif dbf_type == 'M':  # Memo
        # Use NVARCHAR(MAX) for memo fields
        if is_chinese_field:
            return "NVARCHAR(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS"
        else:
            return "NVARCHAR(MAX)"
    elif dbf_type == 'I':  # Integer
        return "INT"
    elif dbf_type == 'B':  # Double
        return "FLOAT"
    elif dbf_type == 'Y':  # Currency
        return "MONEY"
    else:
        # Fallback for unknown types - assume NVARCHAR with buffer
        if is_chinese_field:
            if length > 2000:
                return 'NVARCHAR(MAX) COLLATE Chinese_Taiwan_Stroke_CI_AS'
            else:
                safe_length = min(length * 2, 4000)
                return f"NVARCHAR({safe_length}) COLLATE Chinese_Taiwan_Stroke_CI_AS"
        else:
            if length > 2000:
                return 'NVARCHAR(MAX)'
            else:
                safe_length = min(length * 2, 4000)
                return f"NVARCHAR({safe_length})"

# Improved detection for encrypted fields - looking for the specific pattern
def is_encrypted_foxpro(value):
    """
    Check if a value matches the FoxPro encryption pattern:
    - Ends with '::'
    - Often ends with '==::' (base64 padding + marker)
    - Contains valid base64 characters
    """
    if not isinstance(value, str):
        return False
        
    # Must end with ::
    if not value.endswith('::'):
        return False
        
    # Check for base64 pattern (a-zA-Z0-9+/=)
    base64_part = value[:-2]  # Remove the :: suffix
    base64_pattern = re.compile(r'^[A-Za-z0-9+/=]+$')
    
    # Most FoxPro encrypted data will end with ==:: (base64 padding)
    # But some might have =:: (single padding) or just :: (no padding)
    return base64_pattern.match(base64_part) is not None

# Create table in MSSQL based on DBF structure
def create_table(conn, dbf_file):
    # Use the original base name of the DBF file
    original_base_name = os.path.splitext(os.path.basename(dbf_file))[0]
    table_name_sql = original_base_name # Keep original case and chars
        
    try:
        # Read DBF metadata
        table = DBF(dbf_file, load=False)
        
        # Create SQL table creation statement
        # Use triple quotes for multi-line SQL and simplified quoting
        # Escape single quotes in table name for the WHERE clause
        table_name_escaped = table_name_sql.replace("'", "''")
        create_table_sql = f"""
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = '{table_name_escaped}') 
BEGIN
    CREATE TABLE [{table_name_sql}] (
"""
        
        # Get primary key if available from CDX
        primary_key = None
        cdx_file = os.path.splitext(dbf_file)[0] + '.CDX'
        if os.path.exists(cdx_file):
            # In a real implementation, you'd need to parse the CDX file
            # for index information, but this is complex
            pass
        
        # Add columns
        columns = []
        field_names_mapping = {}
        
        # Check if this is SCList table to handle Chinese characters properly
        is_sclist = table_name_sql.lower() == 'sclist'
        
        for field in table.fields:
            original_field_name = field.name
            # Sanitize field name for SQL compatibility (keep original case for mapping key)
            field_name_sql = original_field_name
            # Basic sanitization - remove potentially problematic chars for SQL name, keep original case in map
            field_name_sql_safe = re.sub(r'[^a-zA-Z0-9_]', '', field_name_sql)
            if not field_name_sql_safe:
                 field_name_sql_safe = f'field_{original_field_name.lower()}'
                 
            field_names_mapping[original_field_name] = field_name_sql_safe # Map original name to SQL safe name
            
            # Provide a default decimal count of 0 if the attribute doesn't exist
            decimal_count = getattr(field, 'decimal', 0)
            
            # For SCList table, ensure fields with Chinese characters use correct collation
            if is_sclist and field_name_sql.upper() == 'EDSEC':
                # For the EDSEC field specifically, force NVARCHAR with Chinese collation
                field_type = "NVARCHAR(500) COLLATE Chinese_Taiwan_Stroke_CI_AS"
            else:
                field_type = dbf_to_sql_type(field.type, field.length, decimal_count, field_name=field_name_sql, table_name=table_name_sql)
            
            # Use brackets around the potentially sanitized field name
            columns.append(f"    [{field_name_sql_safe}] {field_type}")
        
        create_table_sql += ",\n".join(columns)
        
        # Add primary key if available (using SQL safe name)
        if primary_key and primary_key in field_names_mapping:
            create_table_sql += f",\n    PRIMARY KEY ([{field_names_mapping[primary_key]}])"
        
        create_table_sql += "\n)\nEND"
        
        # Execute table creation
        cursor = conn.cursor()
        cursor.execute(create_table_sql)
        conn.commit()
        print(f"Table [{table_name_sql}] created/verified successfully")
        # Return the original base name for use in migrate_data and the mapping
        return original_base_name, field_names_mapping
        
    except Exception as e:
        print(f"Error creating table for [{table_name_sql}]: {str(e)}")
        return None, None

# Scan DBF file for encrypted fields
def scan_dbf_for_encryption(dbf_file, max_records=100):
    """
    Scan a DBF file to identify fields that contain encrypted data
    Returns a dictionary of encrypted fields and their count
    """
    try:
        # Determine proper encoding based on filename
        file_name = os.path.basename(dbf_file)
        file_encoding = 'big5' if file_name.lower() == 'sclist.dbf' else 'latin1'
        print(f"Using encoding: {file_encoding} for scanning")
        
        table = DBF(dbf_file, encoding=file_encoding)
        
        # Get field names
        field_names = [field.name for field in table.fields]
        total_records = len(table)
        
        # Check records
        records_to_check = min(max_records, total_records)
        encrypted_fields = {}
        encrypted_count = {}
        
        for i, record in enumerate(table):
            if i >= records_to_check:
                break
                
            for field_name in field_names:
                value = record.get(field_name)
                
                # Improve handling of Chinese characters
                value = get_dbf_record_value(record, field_name, encoding=file_encoding)
                
                # Clean the value for proper display in logs and examples
                if isinstance(value, str):
                    value = clean_data_value(value)
                    
                # Check if it matches encrypted pattern
                if is_encrypted_foxpro(value):
                    if field_name not in encrypted_fields:
                        encrypted_fields[field_name] = True
                        encrypted_count[field_name] = 1
                    else:
                        encrypted_count[field_name] += 1
        
        return {
            'fields': list(encrypted_fields.keys()),
            'counts': encrypted_count,
            'total_records': total_records,
            'scanned_records': records_to_check
        }
        
    except Exception as e:
        print(f"Error scanning {dbf_file}: {str(e)}")
        return {
            'fields': [],
            'counts': {},
            'total_records': 0,
            'scanned_records': 0
        }

# Migrate data from DBF to MSSQL with re-encryption
def migrate_data(conn, dbf_file, table_name_original, field_names_mapping):
    try:
        # First scan the file to identify encrypted fields
        file_name = os.path.basename(dbf_file)
        print(f"\nScanning {file_name} for encrypted fields...")
        encryption_info = scan_dbf_for_encryption(dbf_file)
        
        encrypted_fields_scan = encryption_info['fields']
        encrypted_counts = encryption_info['counts']
        
        if encrypted_fields_scan:
            print("Found encrypted fields:")
            for field in encrypted_fields_scan:
                count = encrypted_counts.get(field, 0)
                scan_count = encryption_info['scanned_records']
                print(f"  - {field}: {count}/{scan_count} records contain encrypted data")
        else:
            print("No encrypted fields found in this file")
            
        # Determine the correct encoding based on the file
        # Use Big5 encoding for files with Chinese characters
        file_encoding = 'big5' if file_name.lower() == 'sclist.dbf' else 'latin1'
        print(f"Using encoding: {file_encoding} for {file_name}")
            
        # Read DBF data with appropriate encoding
        table = DBF(dbf_file, encoding=file_encoding)
        
        # If table has no records, just return
        if len(table) == 0:
            print(f"No records to migrate for {table_name_original}")
            return 0
        
        # Get original field names from DBF
        original_field_names = [field.name for field in table.fields]
        # Get SQL-safe field names using the mapping
        sql_safe_field_names = [f"[{field_names_mapping.get(name, name)} ]" for name in original_field_names]
        
        # Prepare insert statement using original table name (bracketed) and SQL-safe field names
        placeholders = ','.join(['?' for _ in sql_safe_field_names])
        insert_sql = f"INSERT INTO [{table_name_original}] ({','.join(sql_safe_field_names)}) VALUES ({placeholders})"
        
        # Set up encryption key for this table
        encryption_key = f"migration_key_{table_name_original}"
        
        # Insert data in batches
        cursor = conn.cursor()
        batch_size = 1000
        total_records = len(table)
        records_migrated = 0
        reencrypted_count = 0
        
        # Track encryption stats per field (using original field name)
        field_encryption_stats = {name: 0 for name in original_field_names}
        
        for i, record in enumerate(tqdm(table, total=total_records, desc=f"Migrating {table_name_original}")):
            values = []
            # Iterate using original field names to get data from record
            for original_field_name in original_field_names:
                value = get_dbf_record_value(record, original_field_name, encoding=file_encoding)
                
                # Handle encrypted fields - re-encrypt from old format to new format
                if is_encrypted_foxpro(value):
                    try:
                        # This is in old FoxPro format - decrypt and re-encrypt
                        decrypted = myCrypt.MyDecrypt(value)
                        # Re-encrypt with IV in front
                        value = sqlcrypt.sql_encrypt_with_iv(decrypted, encryption_key)
                        reencrypted_count += 1
                        field_encryption_stats[original_field_name] += 1 # Use original name for stats
                    except Exception as ex:
                        # If decryption fails, keep the original value (might cause INSERT issues)
                        print(f"Warning: Could not decrypt field {original_field_name} in record {i+1}. Keeping original. Error: {str(ex)}")
                else:
                    # Clean non-encrypted data to fix encoding issues (like ÿ characters)
                    value = clean_data_value(value)
                    
                values.append(value)
            
            try:
                # Execute SQL with Unicode support
                execute_with_unicode(cursor, insert_sql, values)
                records_migrated += 1
            except pyodbc.Error as insert_error:
                # Handle potential insert errors (e.g., data too long after keeping original encrypted value)
                print(f"\nError inserting record {i+1} into [{table_name_original}]: {str(insert_error)}")
                # Try again with extra debug for issues with Chinese characters
                if "character string or binary data would be truncated" in str(insert_error).lower():
                    print("Truncation error detected - checking field lengths...")
                    for j, (field_name, val) in enumerate(zip(original_field_names, values)):
                        if isinstance(val, str):
                            print(f"  - Field '{field_name}': length={len(val)}, sample='{val[:30]}...'")
                
                print(f"Values: {values}") # Log values causing error
                # Optionally, skip the record or try inserting NULLs
                conn.rollback() # Rollback the failed insert
                # Consider logging failed records to a file for later review
                continue # Skip to the next record
            
            if (i + 1) % batch_size == 0 or i == total_records - 1:
                conn.commit()
        
        # Print encryption stats
        if reencrypted_count > 0:
            print(f"\nEncryption Statistics for [{table_name_original}]:")
            for field, count in field_encryption_stats.items():
                if count > 0:
                    print(f"  - Field '{field}': {count} values re-encrypted")
                    
        print(f"Successfully migrated {records_migrated} records to [{table_name_original}] (attempted to re-encrypt {reencrypted_count} values)")
        return records_migrated
        
    except Exception as e:
        print(f"Error migrating data for [{table_name_original}]: {str(e)}")
        conn.rollback()
        return 0

# Scan all DBF files for encrypted data
def scan_all_dbf_for_encryption():
    """
    Scan all DBF files in the directory to identify which ones have encrypted data
    and show examples of decrypted values
    """
    print("\n=== SCANNING ALL DBF FILES FOR ENCRYPTED DATA ===\n")
    
    dbf_files = get_dbf_files()
    print(f"Found {len(dbf_files)} DBF files to scan")
    
    files_with_encryption = {}
    
    for dbf_file in dbf_files:
        file_name = os.path.basename(dbf_file)
        print(f"\nScanning {file_name}...")
        
        try:
            # Read DBF file
            file_encoding = 'big5' if file_name.lower() == 'sclist.dbf' else 'latin1'
            print(f"Using encoding: {file_encoding}")
            table = DBF(dbf_file, encoding=file_encoding)
            
            # Get field names
            field_names = [field.name for field in table.fields]
            total_records = len(table)
            
            # Check records
            records_to_check = min(50, total_records)
            encrypted_fields = {}
            encrypted_count = {}
            decryption_examples = {}  # Store examples of decrypted values
            
            for i, record in enumerate(table):
                if i >= records_to_check:
                    break
                    
                for field_name in field_names:
                    value = record.get(field_name)
                    
                    # Improve handling of Chinese characters
                    value = get_dbf_record_value(record, field_name, encoding=file_encoding)
                    
                    # Clean the value for proper display in logs and examples
                    if isinstance(value, str):
                        value = clean_data_value(value)
                        
                    # Check if it matches encrypted pattern
                    if is_encrypted_foxpro(value):
                        if field_name not in encrypted_fields:
                            encrypted_fields[field_name] = True
                            encrypted_count[field_name] = 1
                            # Try to decrypt and store as example
                            try:
                                decrypted = myCrypt.MyDecrypt(value)
                                # Check if decryption looks valid (printable ASCII)
                                is_valid = all(32 <= ord(c) <= 126 for c in decrypted)
                                if is_valid:
                                    decryption_examples[field_name] = {
                                        'encrypted': value,
                                        'decrypted': decrypted,
                                        'record_num': i + 1
                                    }
                            except Exception:
                                pass
                        else:
                            encrypted_count[field_name] += 1
                            # If we don't have an example yet, try this one
                            if field_name not in decryption_examples:
                                try:
                                    decrypted = myCrypt.MyDecrypt(value)
                                    is_valid = all(32 <= ord(c) <= 126 for c in decrypted)
                                    if is_valid:
                                        decryption_examples[field_name] = {
                                            'encrypted': value,
                                            'decrypted': decrypted,
                                            'record_num': i + 1
                                        }
                                except Exception:
                                    pass
            
            # Only add to results if we found encrypted fields
            if encrypted_fields:
                files_with_encryption[file_name] = {
                    'fields': list(encrypted_fields.keys()),
                    'counts': encrypted_count,
                    'total_records': total_records,
                    'scanned_records': records_to_check,
                    'examples': decryption_examples
                }
                
                # Display information for this file
                print(f"Found {len(encrypted_fields)} encrypted fields:")
                for field in encrypted_fields:
                    count = encrypted_count[field]
                    scan_count = records_to_check
                    print(f"  - Field: {field} - {count}/{scan_count} records have encrypted data")
                    
                    # Show decryption example if available
                    if field in decryption_examples:
                        example = decryption_examples[field]
                        print(f"    Example (record #{example['record_num']}):")
                        print(f"    Encrypted (FoxPro): {example['encrypted']}")
                        print(f"    Decrypted: '{example['decrypted']}'")
                        
                        # Show how it would be re-encrypted
                        encryption_key = f"migration_key_{file_name}"
                        reencrypted = sqlcrypt.sql_encrypt_with_iv(example['decrypted'], encryption_key)
                        print(f"    Re-encrypted (full length: {len(reencrypted)} chars): {reencrypted[:50]}...")
                
            else:
                print(f"No encrypted fields found in {file_name}")
                
        except Exception as e:
            print(f"Error scanning {file_name}: {str(e)}")
    
    # Display summary
    if files_with_encryption:
        print(f"\n=== ENCRYPTION SUMMARY ===")
        print(f"Found {len(files_with_encryption)} files with encrypted data:")
        for file, info in files_with_encryption.items():
            fields_with_examples = [f for f in info['fields'] if f in info['examples']]
            fields_without_examples = [f for f in info['fields'] if f not in info['examples']]
            
            print(f"\n- {file} ({info['total_records']} total records)")
            
            if fields_with_examples:
                print(f"  Fields with decryption examples:")
                for field in fields_with_examples:
                    count = info['counts'][field]
                    scan_count = info['scanned_records']
                    example = info['examples'][field]
                    print(f"    {field}: {count}/{scan_count} records, example: '{example['decrypted']}'")
            
            if fields_without_examples:
                print(f"  Fields without valid decryption examples:")
                for field in fields_without_examples:
                    count = info['counts'][field]
                    scan_count = info['scanned_records']
                    print(f"    {field}: {count}/{scan_count} records")
    else:
        print("\nNo files with encrypted data were found.")
        
    return files_with_encryption

# Test decryption of known value
def test_known_encryption():
    """
    Test the decryption and re-encryption with a known example
    """
    print("\n=== TESTING KNOWN ENCRYPTION PATTERN ===\n")
    
    # Example from test.py
    test_value = 'ylAcVkA9lcNSsUbl1Xb5uQ==::'
    
    print(f"Test value: {test_value}")
    print(f"Format: Base64 + '::' suffix")
    
    # Test the detection
    is_encrypted = is_encrypted_foxpro(test_value)
    print(f"Is encrypted format: {is_encrypted}")
    
    if is_encrypted:
        try:
            # Decrypt
            decrypted = myCrypt.MyDecrypt(test_value)
            print(f"Decrypted value: '{decrypted}'")
            
            # Re-encrypt with new format
            encryption_key = "test_key"
            reencrypted = sqlcrypt.sql_encrypt_with_iv(decrypted, encryption_key)
            print(f"Re-encrypted value: {reencrypted}")
            
            # Decrypt the new format to verify
            decrypted_again = sqlcrypt.sql_decrypt_with_iv(reencrypted, encryption_key)
            print(f"Decrypted again: '{decrypted_again}'")
            print(f"Values match: {decrypted == decrypted_again}")
            
            return True
        except Exception as e:
            print(f"Error testing encryption: {str(e)}")
            return False

# Clean value by removing problematic characters or replacing them with proper ones
def clean_data_value(value):
    """
    Clean a data value by removing or replacing problematic characters.
    Currently handles:
    - ÿ character (often appears when control characters are improperly decoded)
    - Other control characters that might cause display issues
    - Other special cases as needed
    
    Args:
        value: The value to clean
        
    Returns:
        Cleaned value
    """
    if not isinstance(value, str):
        return value
    
    # Replace ÿ (y with diaeresis, Unicode U+00FF) which often appears as a conversion error
    # It might be a control character, soft return, or other special character in DBF 
    cleaned_value = value.replace('ÿ', '')
    
    # Replace common control characters that might cause issues
    control_chars = {
        '\x00': '',  # NULL
        '\x01': '',  # START OF HEADING
        '\x02': '',  # START OF TEXT
        '\x03': '',  # END OF TEXT
        '\x04': '',  # END OF TRANSMISSION
        '\x05': '',  # ENQUIRY
        '\x06': '',  # ACKNOWLEDGE
        '\x07': '',  # BELL
        '\x08': '',  # BACKSPACE
        '\x0B': '',  # VERTICAL TAB
        '\x0C': '',  # FORM FEED
        '\x0E': '',  # SHIFT OUT
        '\x0F': '',  # SHIFT IN
        '\x10': '',  # DATA LINK ESCAPE
        '\x11': '',  # DEVICE CONTROL 1
        '\x12': '',  # DEVICE CONTROL 2
        '\x13': '',  # DEVICE CONTROL 3
        '\x14': '',  # DEVICE CONTROL 4
        '\x15': '',  # NEGATIVE ACKNOWLEDGE
        '\x16': '',  # SYNCHRONOUS IDLE
        '\x17': '',  # END OF TRANSMISSION BLOCK
        '\x18': '',  # CANCEL
        '\x19': '',  # END OF MEDIUM
        '\x1A': '',  # SUBSTITUTE
        '\x1B': '',  # ESCAPE
        '\x1C': '',  # FILE SEPARATOR
        '\x1D': '',  # GROUP SEPARATOR
        '\x1E': '',  # RECORD SEPARATOR
        '\x1F': '',  # UNIT SEPARATOR
        '\x7F': '',  # DELETE
    }
    
    # Handle useful whitespace characters appropriately
    whitespace_chars = {
        '\x09': ' ',  # TAB - replace with space
        '\x0A': ' ',  # LINE FEED - replace with space
        '\x0D': ' ',  # CARRIAGE RETURN - replace with space
    }
    
    # Replace control characters with empty string
    for char, replacement in control_chars.items():
        cleaned_value = cleaned_value.replace(char, replacement)
        
    # Replace whitespace characters with space
    for char, replacement in whitespace_chars.items():
        cleaned_value = cleaned_value.replace(char, replacement)
    
    # Remove any consecutive spaces (replace with single space)
    cleaned_value = re.sub(r' +', ' ', cleaned_value)
    
    # Trim leading/trailing whitespace
    cleaned_value = cleaned_value.strip()
    
    return cleaned_value

# Try different encodings for Chinese text
def try_decode_chinese(text_bytes, default_encoding='big5'):
    """
    Try to decode Chinese text with different encodings.
    
    Args:
        text_bytes: The bytes to decode
        default_encoding: The default encoding to try first
        
    Returns:
        Tuple of (decoded_text, encoding_used)
    """
    if not isinstance(text_bytes, bytes):
        # If it's already a string, return it as is
        if isinstance(text_bytes, str):
            return text_bytes, 'str'
        # Try to convert to bytes
        try:
            text_bytes = bytes(text_bytes)
        except:
            return str(text_bytes), 'str'
    
    # List of encodings to try, in order of preference
    encodings = [
        default_encoding,  # Try the specified default first
        'cp950',           # Windows code page for Traditional Chinese
        'gb18030',         # Chinese national standard encoding (handles both simplified and traditional)
        'gbk',             # Extended GB encoding for Simplified Chinese
        'gb2312',          # Basic Simplified Chinese encoding
        'utf-8',           # Try UTF-8 as fallback
        'latin1'           # Last resort
    ]
    
    # Remove duplicates while preserving order
    seen = set()
    encodings = [e for e in encodings if not (e in seen or seen.add(e))]
    
    for encoding in encodings:
        try:
            decoded = text_bytes.decode(encoding)
            # Check if it contains recognizable Chinese characters
            if any('\u4e00' <= char <= '\u9fff' for char in decoded):
                return decoded, encoding
        except Exception:
            continue
    
    # If all else fails, use the default encoding with error handling
    try:
        return text_bytes.decode(default_encoding, errors='replace'), default_encoding
    except:
        # Last resort
        return text_bytes.decode('latin1', errors='replace'), 'latin1'

# Custom DBF record parser that handles Chinese characters better
def get_dbf_record_value(record, field_name, encoding='big5'):
    """
    Get a value from a DBF record with proper encoding handling.
    Especially useful for fields that might contain Chinese characters.
    
    Args:
        record: The DBF record
        field_name: The field name
        encoding: The encoding to try first
        
    Returns:
        The properly decoded value
    """
    value = record.get(field_name)
    
    # For non-string types, return as is
    if not isinstance(value, str):
        return value
        
    # Check if this field might contain Chinese characters
    # This is a heuristic - fields with Chinese often have characters that 
    # would appear as garbage in other encodings
    has_suspicious_chars = any(ord(c) > 127 for c in value)
    
    if has_suspicious_chars:
        # Try to get the raw bytes and decode properly
        try:
            # This is a hack to get the raw bytes - since record.get() already decoded it
            # We re-encode it with latin1 (which is a 1:1 mapping) and then try different decodings
            raw_bytes = value.encode('latin1')
            decoded_value, used_encoding = try_decode_chinese(raw_bytes, default_encoding=encoding)
            if used_encoding != 'latin1' and used_encoding != 'str':
                # Log if we used a different encoding
                # print(f"Re-decoded field {field_name} using {used_encoding} instead of {encoding}")
                return decoded_value
        except Exception as ex:
            print(f"Warning: Error decoding Chinese text in field {field_name}: {str(ex)}")
    
    # If we got here, either it doesn't contain Chinese or we couldn't re-decode it
    return value

# Execute SQL with proper Unicode handling
def execute_with_unicode(cursor, sql, params=None):
    """
    Execute an SQL query with proper handling of Unicode parameters.
    For SQL Server, string parameters need to be prefixed with N for Unicode support.
    
    Args:
        cursor: The database cursor
        sql: The SQL query
        params: The parameters
        
    Returns:
        The cursor after execution
    """
    if not params:
        return cursor.execute(sql)
    
    # Replace ? placeholders with N'value' for string parameters
    # or with the parameter value for non-string parameters
    # For ODBC with SQL Server, we use ? for parameter placeholders
    final_params = []
    
    for param in params:
        if isinstance(param, str) and any(ord(c) > 127 for c in param):
            # This is a Unicode string, it will need to be prefixed with N in SQL Server
            # However, we can't directly use N'value' syntax with parameterized queries safely
            # Instead, we'll mark it for special handling
            final_params.append(param)
        else:
            final_params.append(param)
    
    # Execute with parameters
    return cursor.execute(sql, final_params)

# Main migration function
def migrate_dbf_to_mssql():
    print("Starting migration from DBF to MSSQL...")
    
    # Connect to MSSQL
    conn = connect_to_mssql()
    
    # Test known encryption pattern
    test_known_encryption()
    
    # Option to scan for encrypted data first
    scan_first = input("\nDo you want to scan all DBF files for encrypted data first? (y/n): ")
    if scan_first.lower() == 'y':
        files_with_encryption = scan_all_dbf_for_encryption()
    
    # Get list of DBF files
    dbf_files = get_dbf_files()
    print(f"\nFound {len(dbf_files)} DBF files to migrate")
    
    # Create encryption keys table if not exists
    sqlcrypt.ensure_key_table_exists()
    
    # Migrate each DBF file
    total_tables = 0
    total_records = 0
    
    # Ask if the user wants to proceed with all files or select specific ones
    migrate_all = input("\nDo you want to migrate all files? (y/n, n=select specific files): ")
    
    files_to_migrate = []
    if migrate_all.lower() == 'y':
        files_to_migrate = dbf_files
    else:
        # Show all available files
        print("\nAvailable DBF files:")
        for i, file in enumerate(dbf_files):
            print(f"{i+1}. {os.path.basename(file)}")
            
        # Let user select files
        selections = input("\nEnter file numbers to migrate (comma separated, e.g. 1,3,5): ")
        try:
            selected_indices = [int(x.strip())-1 for x in selections.split(',')]
            for idx in selected_indices:
                if 0 <= idx < len(dbf_files):
                    files_to_migrate.append(dbf_files[idx])
            
            print(f"\nSelected {len(files_to_migrate)} files for migration")
        except:
            print("Invalid selection, migrating all files")
            files_to_migrate = dbf_files
    
    # Migrate selected files
    for dbf_file in files_to_migrate:
        file_name = os.path.basename(dbf_file)
        print(f"\nProcessing {file_name}...")
        
        # Create table in MSSQL
        table_name, field_names_mapping = create_table(conn, dbf_file)
        
        if table_name:
            # Migrate data with re-encryption
            records_migrated = migrate_data(conn, dbf_file, table_name, field_names_mapping)
            
            if records_migrated > 0:
                total_tables += 1
                total_records += records_migrated
    
    print(f"\nMigration complete! Migrated {total_records} records across {total_tables} tables.")
    print("All encrypted data has been migrated to the new format with IV stored in front.")
    conn.close()

# Create a requirements.txt file
def create_requirements():
    requirements = [
        "pyodbc==4.0.39",
        "dbfread==2.0.7",
        "python-dotenv==1.0.0",
        "pandas==1.3.5",
        "tqdm==4.66.1",
        "pycryptodome==3.19.0"
    ]
    
    with open('requirements.txt', 'w') as f:
        f.write('\n'.join(requirements))
    
    print("Created requirements.txt file")

if __name__ == "__main__":
    print("DBF to MSSQL Migration Tool")
    print("===========================")
    
    choice = input("\nSelect operation:\n1. Migrate DBF to MSSQL\n2. Scan DBF files for encrypted data\n3. Test encryption with known value\nChoice: ")
    
    if choice == "1":
        # Create requirements file
        create_requirements()
        # Run migration with re-encryption
        migrate_dbf_to_mssql()
    elif choice == "2":
        scan_all_dbf_for_encryption()
    elif choice == "3":
        test_known_encryption()
    else:
        print("Invalid choice") 