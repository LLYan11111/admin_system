import sys
from PyQt5 import QtWidgets, QtGui, QtCore
from datetime import datetime

# ===== Updated Constants for Styles =====
BASE_FONT = "'Segoe UI', Arial"
FONT_SIZE_NORMAL = "13px"
FONT_SIZE_SMALL = "11px"
FONT_SIZE_LARGE = "16px"

COLOR_BACKGROUND = "#F5F5F5" # Light gray background
COLOR_CONTENT_BACKGROUND = "#FFFFFF" # White for content areas
COLOR_BORDER = "#CCCCCC" # Light gray border
COLOR_TEXT_PRIMARY = "#222222" # Dark gray text
COLOR_TEXT_SECONDARY = "#555555" # Medium gray text
COLOR_ACCENT = "#0078D4" # Blue accent
COLOR_ACCENT_HOVER = "#005A9E"
COLOR_ACCENT_PRESSED = "#004C87"
COLOR_TABLE_HEADER_BG = "#E1E1E1" # Light gray table header
COLOR_TABLE_HEADER_FG = "#333333"
COLOR_TABLE_ALT_ROW = "#F0F8FF" # Light blue for alternating rows

# --- Style for Function Key Buttons (Similar to CaseEntryBatch) ---
FUNC_KEY_BUTTON_STYLE = f"""
    QPushButton {{
        background-color: #D4D0C8; /* Standard button gray */
        color: black;
        border: 1px solid #808080; /* Gray border */
        border-top-color: #FFFFFF; /* Lighter top border for 3D effect */
        border-left-color: #FFFFFF; /* Lighter left border for 3D effect */
        padding: 3px 8px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 20px;
        min-width: 70px; /* Ensure buttons have some width */
        outline: none; /* Remove focus outline */
    }}
    QPushButton:pressed {{
        background-color: #C0C0C0; /* Darker gray when pressed */
        border-color: #404040;
        border-top-color: #808080;
        border-left-color: #808080;
    }}
    QPushButton:focus {{
        /* Optional: Add a subtle focus indicator if needed */
        /* border: 1px solid {COLOR_ACCENT}; */
    }}
"""

INPUT_STYLE = f"""
    background-color: {COLOR_CONTENT_BACKGROUND};
    border: 1px solid {COLOR_BORDER};
    border-radius: 3px;
    padding: 4px 6px;
    color: {COLOR_TEXT_PRIMARY};
    font-family: {BASE_FONT};
    font-size: {FONT_SIZE_NORMAL};
    selection-background-color: {COLOR_ACCENT};
    selection-color: white;
"""
# --- Restore original Label Style for form area ---
LABEL_STYLE = f"color: {COLOR_TEXT_PRIMARY}; font-family: {BASE_FONT}; font-size: {FONT_SIZE_NORMAL}; font-weight: bold;" # Changed back to primary text color
# --- Standard Button Style (Keep for other buttons if needed) ---
BUTTON_STYLE = f"""
    QPushButton {{
        background-color: #E1E1E1;
        color: {COLOR_TEXT_PRIMARY};
        border: 1px solid {COLOR_BORDER};
        border-radius: 3px;
        padding: 5px 10px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 20px; /* Ensure minimum height */
    }}
    QPushButton:hover {{
        background-color: #D1D1D1;
        border-color: #BDBDBD;
    }}
    QPushButton:pressed {{
        background-color: #C1C1C1;
    }}
    QPushButton:disabled {{
        background-color: #EFEFEF;
        color: #AAAAAA;
    }}
"""
ACTIVE_TAB_STYLE = f"""
    QPushButton {{
        background-color: {COLOR_ACCENT};
        color: white;
        border: 1px solid {COLOR_ACCENT};
        border-bottom: 2px solid {COLOR_CONTENT_BACKGROUND}; /* Blend bottom border */
        border-radius: 3px 3px 0 0; /* Rounded top corners */
        padding: 5px 10px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        font-weight: bold;
        min-height: 20px;
    }}
"""
INACTIVE_TAB_STYLE = f"""
    QPushButton {{
        background-color: #E1E1E1;
        color: {COLOR_TEXT_SECONDARY};
        border: 1px solid {COLOR_BORDER};
        border-bottom: 1px solid {COLOR_BORDER}; /* Ensure bottom border matches */
        border-radius: 3px 3px 0 0;
        padding: 5px 10px;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        min-height: 20px;
    }}
    QPushButton:hover {{
        background-color: #D1D1D1;
    }}
"""

TABLE_HEADER_STYLE = f"""
    QHeaderView::section {{
        background-color: {COLOR_TABLE_HEADER_BG};
        color: {COLOR_TABLE_HEADER_FG};
        padding: 4px;
        border: 1px solid {COLOR_BORDER};
        font-weight: bold;
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
    }}
"""
TABLE_STYLE = f"""
    QTableWidget {{
        background-color: {COLOR_CONTENT_BACKGROUND};
        color: {COLOR_TEXT_PRIMARY};
        gridline-color: {COLOR_BORDER};
        border: 1px solid {COLOR_BORDER};
        font-size: {FONT_SIZE_NORMAL};
        font-family: {BASE_FONT};
        alternate-background-color: {COLOR_TABLE_ALT_ROW}; /* Zebra striping */
    }}
    QTableWidget::item {{
        padding: 4px;
        border-bottom: 1px solid {COLOR_BORDER}; /* Lighter border between rows */
        border-right: 1px dotted {COLOR_BORDER}; /* Dotted border between columns */
    }}
    QTableWidget::item:selected {{
        background-color: {COLOR_ACCENT};
        color: white;
    }}
"""
# Simplified Data Table Styles (assuming they are similar to regular tables now)
DATA_TABLE_STYLE = TABLE_STYLE
DATA_TABLE_HEADER_STYLE = TABLE_HEADER_STYLE # Reuse header style

class CaseEntryBatch(QtWidgets.QDialog): # Renamed class
    """
    案件查詢對話框 - 用於查看和管理案件詳細信息的主界面。
    提供多個詳細信息頁面，用於顯示案件的不同方面。
    """

    # ===== INITIALIZATION METHODS =====
    def __init__(self, parent=None):
        """初始化 CaseEntryBatch 對話框""" # Updated docstring
        super().__init__(parent) # No change needed here, super() handles it
        self.setWindowTitle("Case Master - Case Entry By Batch") # Title can remain if desired
        self._configure_window()
        # Initialize detail page widgets to None initially
        self._initialize_detail_widgets() # Keep this
        self.init_ui() # Call init_ui after initializing widgets

    def _configure_window(self):
        """配置窗口的基本屬性 (大小, 樣式, 標誌)"""
        # Increased width from 805 to 880
        self.setFixedSize(880, 850) # Consider if fixed size is truly needed, maybe allow resizing?
        # Use standard dialog frame instead of frameless
        self.setWindowFlags(QtCore.Qt.Dialog)

        # --- Updated Global Stylesheet ---
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {COLOR_BACKGROUND};
                /* Remove border/radius for standard frame */
                /* border: 1px solid {COLOR_BORDER}; */
                /* border-radius: 5px; */
            }}
            QWidget {{ /* Apply base font to all widgets */
                font-family: {BASE_FONT};
                font-size: {FONT_SIZE_NORMAL};
            }}
            /* Restore original Label Style for form */
            QLabel {{ {LABEL_STYLE} }}
            QLineEdit, QTextEdit, QListWidget {{ {INPUT_STYLE} }}
            QCheckBox {{
                color: {COLOR_TEXT_PRIMARY};
                font-size: {FONT_SIZE_NORMAL};
                spacing: 5px; /* Space between box and text */
            }}
            QCheckBox::indicator {{
                width: 15px;
                height: 15px;
            }}
            QTableWidget {{
                 {TABLE_STYLE} /* Apply base table style */
            }}
            QHeaderView::section {{ /* Style for default table headers */
                {TABLE_HEADER_STYLE}
            }}
            /* Apply base button style globally */
            {BUTTON_STYLE}
        """)

    def _initialize_detail_widgets(self):
        """將所有詳細頁面的屬性初始化為 None"""
        # Keep references for Detail 1 parts
        self.financial_area = None
        self.data_table_area = None
        self.bottom_area = None
        # Keep references for other pages
        self.payment_area = None
        self.payment_summary_area = None # Detail 2 part 2
        self.personal_info_area = None
        self.company_info_area = None
        self.block_info_area = None
        self.detail_code_area = None
        self.case_history_area = None
        self.transfer_info_area = None
        # Add containers for multi-part pages
        self.detail1_container = None
        self.detail2_container = None

    def init_ui(self):
        """初始化用戶界面組件"""
        self.main_layout = QtWidgets.QVBoxLayout(self) # Store reference to main layout
        # Adjust margins for standard window frame
        self.main_layout.setContentsMargins(5, 5, 5, 5)
        self.main_layout.setSpacing(0) # No spacing between main sections

        # --- UI Components (Fixed Sections) ---
        self.title_bar = self.create_title_bar()
        # self.ref_row = self.create_ref_row() # Remove ref_row
        self.action_button_bar = self.create_action_button_bar() # Add action button bar
        self.form_area = self.create_form_area() # Ensure row stretch is applied here
        self.tab_area = self.create_tab_area()

        # --- Stacked Widget for Detail Pages ---
        self.stacked_widget = QtWidgets.QStackedWidget()
        # Add border to stacked widget to contain white pages
        self.stacked_widget.setStyleSheet(f"border: 1px solid {COLOR_BORDER};")


        # --- Create and Add Detail Page 1 Container ---
        self.detail1_container = QtWidgets.QWidget()
        # Ensure container background is white
        self.detail1_container.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        detail1_layout = QtWidgets.QVBoxLayout(self.detail1_container)
        detail1_layout.setContentsMargins(0, 0, 0, 0)
        detail1_layout.setSpacing(0) # No spacing within detail page parts
        # Call the methods to create the parts of Detail 1
        self.financial_area = self.create_financial_area()
        self.data_table_area = self.create_data_table_area()
        self.bottom_area = self.create_bottom_area()
        # Add the parts to the container's layout
        detail1_layout.addWidget(self.financial_area)
        detail1_layout.addWidget(self.data_table_area)
        detail1_layout.addWidget(self.bottom_area)
        self.stacked_widget.addWidget(self.detail1_container) # Add page 1 container to stack

        # --- Add Components to Main Layout ---
        self.main_layout.addWidget(self.title_bar)
        # self.main_layout.addWidget(self.ref_row) # Remove ref_row
        self.main_layout.addWidget(self.action_button_bar) # Add action button bar
        self.main_layout.addWidget(self.form_area)
        self.main_layout.addWidget(self.tab_area)
        self.main_layout.addWidget(self.stacked_widget, 1) # Allow stacked widget to stretch
        # self.main_layout.addStretch(1) # Remove stretch from main layout

        # --- Initial Page Display ---
        self.show_detail_page(1) # Show Detail 1 by default

    # ===== MAIN UI COMPONENT CREATION METHODS =====
    def create_title_bar(self):
        """創建標題欄 (移除功能鍵提示)"""
        title_widget = QtWidgets.QWidget()
        title_widget.setFixedHeight(35) # Adjusted height
        # --- Updated Title Bar Style ---
        title_widget.setStyleSheet(f"""
            background-color: {COLOR_ACCENT}; /* Use accent color */
            /* Remove border radius for standard frame */
            /* border-top-left-radius: 5px; */
            /* border-top-right-radius: 5px; */
            border-bottom: 1px solid {COLOR_BORDER}; /* Separator line */
        """)

        title_layout = QtWidgets.QHBoxLayout(title_widget)
        title_layout.setContentsMargins(15, 0, 15, 0)

        title_label = QtWidgets.QLabel("Case Master - Case Entry By Batch") # Updated title
        # --- Updated Title Label Style (Override global label style) ---
        title_label.setStyleSheet(f"color: white; font-size: {FONT_SIZE_LARGE}; font-weight: bold; background-color: transparent;")

        # keys_label = QtWidgets.QLabel("F3-Edit | F4-Del | F5-Brow | F6-Goto") # Remove keys label
        # esc_label = QtWidgets.QLabel("ESC-Exit") # Remove esc label

        self.mode_label = QtWidgets.QLabel("VIEW")
        self.mode_label.setObjectName("mode_label")
        # --- Updated Mode Label Style (Override global label style) ---
        self.mode_label.setStyleSheet(f"color: white; font-size: {FONT_SIZE_NORMAL}; font-weight: bold; padding: 2px 8px; background-color: rgba(255, 255, 255, 0.2); border-radius: 3px;")
        self.mode_label.setAlignment(QtCore.Qt.AlignCenter)

        title_layout.addWidget(title_label)
        title_layout.addStretch()
        title_layout.addWidget(self.mode_label)
        title_layout.addStretch()
        # title_layout.addWidget(keys_label) # Remove keys label
        # title_layout.addSpacing(20)
        # title_layout.addWidget(esc_label) # Remove esc label

        return title_widget

    def create_action_button_bar(self):
        """創建包含 F2, F3, F4, ESC, F7, F10 按鈕的操作欄"""
        button_widget = QtWidgets.QWidget()
        # Use light gray background similar to old ref_row or the image
        button_widget.setStyleSheet(f"background-color: {COLOR_TABLE_HEADER_BG}; border-bottom: 1px solid {COLOR_BORDER};")
        button_layout = QtWidgets.QHBoxLayout(button_widget)
        button_layout.setContentsMargins(5, 2, 5, 2) # Reduced margins
        button_layout.setSpacing(4) # Spacing between buttons

        # Create buttons based on the image
        self.f2_button = QtWidgets.QPushButton("F2 - New")
        self.f3_button = QtWidgets.QPushButton("F3 - Edit")
        self.f4_button = QtWidgets.QPushButton("F4 - Del")
        self.esc_button = QtWidgets.QPushButton("ESC-Exit")
        self.f7_button = QtWidgets.QPushButton("F7 - Import")
        self.f10_button = QtWidgets.QPushButton("F10 - Print")

        buttons = [
            self.f2_button, self.f3_button, self.f4_button,
            self.esc_button, self.f7_button
        ]

        # Apply style and add main buttons to layout
        for btn in buttons:
            btn.setStyleSheet(FUNC_KEY_BUTTON_STYLE) # Using the gray button style
            button_layout.addWidget(btn)
            # Connect signals
            if btn == self.f2_button: btn.clicked.connect(self.new_action)
            elif btn == self.f3_button: btn.clicked.connect(self.edit_action)
            elif btn == self.f4_button: btn.clicked.connect(self.delete_action)
            elif btn == self.esc_button: btn.clicked.connect(self.close)
            elif btn == self.f7_button: btn.clicked.connect(self.import_action)

        button_layout.addStretch() # Push main buttons to the left

        # Add F10 button separately (appears further right in image)
        self.f10_button.setStyleSheet(FUNC_KEY_BUTTON_STYLE)
        self.f10_button.clicked.connect(self.print_action)
        button_layout.addWidget(self.f10_button)

        return button_widget

    def create_form_area(self):
        """創建主要表單區域，包含客戶信息"""
        form_widget = QtWidgets.QWidget()
        # --- Updated Form Area Style ---
        form_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-bottom: 1px solid {COLOR_BORDER};")

        form_layout = QtWidgets.QGridLayout(form_widget)
        form_layout.setContentsMargins(15, 15, 15, 15) # Increased margins
        form_layout.setHorizontalSpacing(15) # Increased spacing
        form_layout.setVerticalSpacing(10) # Increased spacing

        # Helper to add label and widget
        def add_form_field(label_text, widget, row, col, col_span=1, label_alignment=QtCore.Qt.AlignLeft):
            label = QtWidgets.QLabel(label_text)
            # Label style applied globally via _configure_window
            label.setAlignment(label_alignment | QtCore.Qt.AlignVCenter)
            form_layout.addWidget(label, row, col * 2)
            form_layout.addWidget(widget, row, col * 2 + 1, 1, col_span * 2 -1 if col_span > 1 else 1)
            # Input style applied globally

        # --- Fields (Keep existing field creation) ---
        ref_no = QtWidgets.QLineEdit(); ref_no.setFixedWidth(120)
        client_code = QtWidgets.QLineEdit(); client_code.setFixedWidth(120)
        ac_name = QtWidgets.QLineEdit(); ac_name.setFixedWidth(250)
        ac_no = QtWidgets.QLineEdit(); ac_no.setFixedWidth(250)
        chinese = QtWidgets.QLineEdit(); chinese.setFixedWidth(200)
        # --- Remove border from 'English' QLabel ---
        english = QtWidgets.QLabel("N"); english.setFixedWidth(40); english.setAlignment(QtCore.Qt.AlignCenter)
        english.setStyleSheet(f"background-color: #E9E9E9; font-weight: bold; border: none; padding: 4px 6px; color: {COLOR_TEXT_PRIMARY}; font-family: {BASE_FONT}; font-size: {FONT_SIZE_NORMAL};") # Read-only look without border
        sex = QtWidgets.QLineEdit(); sex.setFixedWidth(40)
        currency = QtWidgets.QLineEdit(); currency.setFixedWidth(80)
        loan_type = QtWidgets.QLineEdit(); loan_type.setFixedWidth(80)
        date_assign = QtWidgets.QLineEdit(); date_assign.setFixedWidth(120); date_assign.setPlaceholderText("MM/DD/YYYY") # Placeholder text
        collector = QtWidgets.QLineEdit(); collector.setFixedWidth(120)
        status = QtWidgets.QLineEdit(); status.setFixedWidth(120)
        card_type = QtWidgets.QLineEdit(); card_type.setFixedWidth(120)
        id_no = QtWidgets.QLineEdit(); id_no.setFixedWidth(180)
        # --- Remove border from 'Corp' QLabel ---
        corp = QtWidgets.QLabel("N"); corp.setFixedWidth(40); corp.setAlignment(QtCore.Qt.AlignCenter)
        corp.setStyleSheet(f"background-color: #E9E9E9; font-weight: bold; border: none; padding: 4px 6px; color: {COLOR_TEXT_PRIMARY}; font-family: {BASE_FONT}; font-size: {FONT_SIZE_NORMAL};") # Read-only look without border
        debtor_id = QtWidgets.QLineEdit(); debtor_id.setFixedWidth(180)

        # --- Layout (Currency moved back to row 6, col 1) ---
        add_form_field("Ref No", ref_no, 0, 0)
        add_form_field("Client Code", client_code, 1, 0)
        add_form_field("A/C name", ac_name, 2, 0, col_span=2)
        add_form_field("A/C no.", ac_no, 3, 0, col_span=2)
        add_form_field("Chinese", chinese, 4, 0, col_span=1)
        add_form_field("English", english, 5, 0)
        add_form_field("Sex", sex, 6, 0)
        add_form_field("Currency", currency, 6, 1) # Moved Currency back

        add_form_field("Loan Type", loan_type, 1, 1)

        add_form_field("Date Assign", date_assign, 0, 2)
        add_form_field("Collector", collector, 1, 2)
        add_form_field("Status", status, 2, 2)
        add_form_field("Card Type", card_type, 3, 2)
        add_form_field("I.D no.", id_no, 4, 2)
        add_form_field("Corp", corp, 5, 2)
        add_form_field("Debtor ID", debtor_id, 6, 2)

        # Set column stretch factors
        form_layout.setColumnStretch(1, 1) # Widget column 1
        form_layout.setColumnStretch(3, 1) # Widget column 2
        form_layout.setColumnStretch(5, 1) # Widget column 3

        last_content_row = 7
        form_layout.setRowStretch(last_content_row, 1)

        return form_widget

    def create_tab_area(self):
        """創建細節標籤頁按鈕區域"""
        tab_widget = QtWidgets.QWidget()
        tab_widget.setFixedHeight(40) # Slightly taller for better click target
        # --- Updated Tab Area Style ---
        tab_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-bottom: 1px solid {COLOR_BORDER};")

        tab_layout = QtWidgets.QHBoxLayout(tab_widget)
        tab_layout.setContentsMargins(8, 0, 8, 0) # Margin at bottom is handled by border
        tab_layout.setSpacing(2) # Spacing between tabs

        self.detail_buttons = []
        for i in range(1, 9):
            btn = QtWidgets.QPushButton(f"Detail {i}")
            btn.setMinimumWidth(75)
            btn.setStyleSheet(INACTIVE_TAB_STYLE) # Start all as inactive
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, idx=i: self.show_detail_page(idx))
            self.detail_buttons.append(btn)
            tab_layout.addWidget(btn)

        tab_layout.addStretch()
        return tab_widget

    # ===== DETAIL PAGE MANAGEMENT =====
    def show_detail_page(self, page_number):
        """根據頁面編號顯示對應的詳細頁面內容 (using QStackedWidget)"""
        # Update button styles
        for i, btn in enumerate(self.detail_buttons):
            is_active = (i + 1 == page_number)
            btn.setStyleSheet(ACTIVE_TAB_STYLE if is_active else INACTIVE_TAB_STYLE)

        # --- Get or Create the target widget/container ---
        target_widget = None
        if page_number == 1:
            target_widget = self.detail1_container # Already created in init_ui
        elif page_number == 2:
            if self.detail2_container is None:
                self.detail2_container = QtWidgets.QWidget()
                # Ensure container background is white
                self.detail2_container.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
                layout = QtWidgets.QVBoxLayout(self.detail2_container)
                layout.setContentsMargins(0,0,0,0)
                layout.setSpacing(0)
                self.payment_area = self._ensure_widget_exists('payment_area', self.create_payment_area, add_to_stack=False)
                self.payment_summary_area = self._ensure_widget_exists('payment_summary_area', self.create_payment_summary_area, add_to_stack=False)
                layout.addWidget(self.payment_area)
                layout.addWidget(self.payment_summary_area)
                self.stacked_widget.addWidget(self.detail2_container) # Add container to stack
            target_widget = self.detail2_container
        elif page_number == 3:
            target_widget = self._ensure_widget_exists('personal_info_area', self.create_personal_info_area)
        elif page_number == 4:
            target_widget = self._ensure_widget_exists('company_info_area', self.create_company_info_area)
        elif page_number == 5:
            target_widget = self._ensure_widget_exists('block_info_area', self.create_block_info_area)
        elif page_number == 6:
            target_widget = self._ensure_widget_exists('detail_code_area', self.create_detail_code_area)
        elif page_number == 7:
            target_widget = self._ensure_widget_exists('case_history_area', self.create_case_history_area)
        elif page_number == 8:
            target_widget = self._ensure_widget_exists('transfer_info_area', self.create_transfer_info_area)

        # --- Switch the visible page in the stack ---
        if target_widget:
            # Ensure the created widget also has a white background if it's a direct QWidget
            if isinstance(target_widget, QtWidgets.QWidget) and not isinstance(target_widget, QtWidgets.QStackedWidget):
                current_style = target_widget.styleSheet()
                if "background-color" not in current_style:
                    target_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
            self.stacked_widget.setCurrentWidget(target_widget)
        else:
            print(f"Error: Could not find or create widget/container for page {page_number}")

    def _ensure_widget_exists(self, attr_name, create_method, add_to_stack=True):
        """如果控件不存在，則創建它。可選地添加到 QStackedWidget。"""
        widget = getattr(self, attr_name, None)
        if widget is None:
            if not callable(create_method):
                 print(f"Error: {create_method.__name__} is not callable or defined correctly.")
                 return None

            widget = create_method()
            if widget is None:
                print(f"Error: {create_method.__name__} returned None.")
                return None

            # Ensure background is white if not set
            if isinstance(widget, QtWidgets.QWidget) and "background-color" not in widget.styleSheet():
                 widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")

            setattr(self, attr_name, widget)

            if add_to_stack:
                self.stacked_widget.addWidget(widget)
        return widget

    # ===== DETAIL PAGE CREATION METHODS =====
    # ... (create_financial_area, create_data_table_area, etc. remain the same) ...
    # ... (Ensure background-color is set to COLOR_CONTENT_BACKGROUND in each create_* method) ...
    def create_financial_area(self):
        """創建財務信息區域 (Detail 1 - Part 1) - Placeholder"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};") # Set background
        layout = QtWidgets.QGridLayout(widget) # Use GridLayout for structure
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        # --- Example Fields (Replace with your actual fields) ---
        layout.addWidget(QtWidgets.QLabel("Ass. Amt:"), 0, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 0, 1)
        layout.addWidget(QtWidgets.QLabel("Late Fee:"), 0, 2)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 0, 3)
        layout.addWidget(QtWidgets.QCheckBox("OA"), 0, 4)
        layout.addWidget(QtWidgets.QLabel("Interest:"), 0, 5)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 0, 6)
        layout.addWidget(QtWidgets.QCheckBox("OA"), 0, 7)

        layout.addWidget(QtWidgets.QLabel("Legal Fee:"), 1, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 1, 1)
        layout.addWidget(QtWidgets.QLabel("Others:"), 1, 2) # Corrected typo
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 1, 3)
        layout.addWidget(QtWidgets.QCheckBox("OA"), 1, 4)
        layout.addWidget(QtWidgets.QLabel("O/S Amt:"), 1, 5)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 1, 6)
        layout.addWidget(QtWidgets.QCheckBox("OA"), 1, 7)

        layout.addWidget(QtWidgets.QLabel("Commission:"), 2, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 2, 1)
        layout.addWidget(QtWidgets.QLabel("Comm Rate:"), 2, 2)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 2, 3)
        layout.addWidget(QtWidgets.QLabel("Total Balance:"), 2, 5)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 2, 6)

        layout.addWidget(QtWidgets.QPushButton("All Billed"), 3, 0)
        layout.addWidget(QtWidgets.QLabel("Discounted Amt:"), 3, 2)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 3, 3)
        layout.addWidget(QtWidgets.QLabel("Dis. End Date:"), 3, 5)
        layout.addWidget(QtWidgets.QLineEdit("MM/DD/YYYY"), 3, 6)
        layout.addWidget(QtWidgets.QCheckBox("Charging Order"), 3, 7)

        layout.setRowStretch(4, 1)
        layout.setColumnStretch(8, 1)

        return widget

    def create_data_table_area(self):
        """創建數據表格區域 (Detail 1 - Part 2)，包含 Linked/Package 摘要"""
        area_widget = QtWidgets.QWidget()
        area_widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        area_layout = QtWidgets.QVBoxLayout(area_widget)
        area_layout.setContentsMargins(15, 5, 15, 10)
        area_layout.setSpacing(10)

        summary_widget = QtWidgets.QWidget()
        summary_layout = QtWidgets.QVBoxLayout(summary_widget)
        summary_layout.setContentsMargins(0, 0, 0, 0)
        summary_layout.setSpacing(0)

        header_layout = QtWidgets.QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(0)

        headers = [(" ", 65), ("No.", 45), ("Ass. Amt", 95), ("All Others", 95),
                   ("Commission", 95), ("Total Paid", 95), ("Total O/S", 95),
                   ("Total Balance", 95), (" ", 30)]

        for idx, (text, width) in enumerate(headers):
            lbl = QtWidgets.QLabel(text)
            lbl.setFixedWidth(width)
            lbl.setAlignment(QtCore.Qt.AlignCenter)
            # --- Restore border for summary header labels ---
            lbl_style = f"""
                background-color: {COLOR_TABLE_HEADER_BG};
                color: {COLOR_TABLE_HEADER_FG};
                font-weight: bold;
                font-size: {FONT_SIZE_SMALL};
                padding: 3px;
                border-top: 1px solid {COLOR_BORDER};
                border-bottom: 1px solid {COLOR_BORDER};
                border-right: 1px solid {COLOR_BORDER};
            """
            if idx == 0:
                 lbl_style += f"border-left: 1px solid {COLOR_BORDER};"
            lbl.setStyleSheet(lbl_style)
            header_layout.addWidget(lbl)

        summary_layout.addLayout(header_layout)

        summary_grid_widget = QtWidgets.QWidget()
        summary_grid_layout = QtWidgets.QGridLayout(summary_grid_widget)
        summary_grid_layout.setContentsMargins(0,0,0,0)
        summary_grid_layout.setSpacing(0)

        row_labels = ["Linked", "Package"]
        default_values = ["0", "0.00", "0.00", "0.00", "0.00", "0.00", "0.00"]

        for r, row_label_text in enumerate(row_labels):
            row_lbl = QtWidgets.QLabel(row_label_text)
            row_lbl.setFixedWidth(headers[0][1])
            row_lbl.setAlignment(QtCore.Qt.AlignCenter)
            # --- Restore border for summary row labels ---
            row_lbl.setStyleSheet(f"""
                background-color: {COLOR_TABLE_HEADER_BG};
                color: {COLOR_TABLE_HEADER_FG};
                font-weight: bold;
                font-size: {FONT_SIZE_NORMAL};
                padding: 4px;
                border-left: 1px solid {COLOR_BORDER};
                border-bottom: 1px solid {COLOR_BORDER};
                border-right: 1px solid {COLOR_BORDER};
            """)
            summary_grid_layout.addWidget(row_lbl, r, 0)

            for c, default_val in enumerate(default_values):
                data_lbl = QtWidgets.QLabel(default_val)
                data_lbl.setFixedWidth(headers[c+1][1])
                data_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
                # --- Restore border for summary data labels ---
                data_lbl.setStyleSheet(f"""
                    background-color: {COLOR_CONTENT_BACKGROUND};
                    color: {COLOR_TEXT_PRIMARY};
                    font-size: {FONT_SIZE_NORMAL};
                    padding: 4px;
                    border-bottom: 1px solid {COLOR_BORDER};
                    border-right: 1px solid {COLOR_BORDER};
                """)
                summary_grid_layout.addWidget(data_lbl, r, c + 1)

            star_lbl = QtWidgets.QLabel("**")
            star_lbl.setFixedWidth(headers[8][1])
            star_lbl.setAlignment(QtCore.Qt.AlignCenter)
            # --- Restore border for star label ---
            star_lbl.setStyleSheet(f"""
                background-color: {COLOR_TABLE_HEADER_BG};
                color: red;
                font-weight: bold;
                font-size: {FONT_SIZE_NORMAL};
                padding: 4px;
                border-bottom: 1px solid {COLOR_BORDER};
                border-right: 1px solid {COLOR_BORDER};
            """)
            summary_grid_layout.addWidget(star_lbl, r, 8)

        summary_layout.addWidget(summary_grid_widget)
        area_layout.addWidget(summary_widget)

        # --- Main Table (QTableWidget) - Borders are handled by TABLE_STYLE ---
        main_table = QtWidgets.QTableWidget(5, 8)
        main_table.setHorizontalHeaderLabels([
            "Paid Date", "Paid Amount", "OS/Amount", "OA paid",
            "Adjustment", "MD Col", "Bills", "Remarks"
        ])
        # Styles for QTableWidget and its header/items remain unchanged
        main_table.horizontalHeader().setStyleSheet(DATA_TABLE_HEADER_STYLE)
        main_table.setStyleSheet(DATA_TABLE_STYLE) # Apply table style which includes borders
        main_table.verticalHeader().setVisible(False)
        main_table.setAlternatingRowColors(True)
        main_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        main_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)

        main_table.setColumnWidth(0, 100)
        main_table.setColumnWidth(1, 100)
        main_table.setColumnWidth(2, 100)
        main_table.setColumnWidth(7, 200)
        main_table.horizontalHeader().setStretchLastSection(True)

        for r in range(5):
            for c in range(8):
                main_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"Item {r}-{c}"))

        main_table.setMinimumHeight(150)

        area_layout.addWidget(main_table)
        area_layout.addStretch()

        return area_widget

    def create_bottom_area(self):
        """創建底部信息區域 (Detail 1 - Part 3) - Placeholder"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-top: 1px solid {COLOR_BORDER};")
        widget.setFixedHeight(50)
        layout = QtWidgets.QHBoxLayout(widget)
        layout.setContentsMargins(15, 5, 15, 5)
        layout.setSpacing(10)

        layout.addWidget(QtWidgets.QPushButton("F8 - More"))
        layout.addWidget(QtWidgets.QPushButton("Ctrl+F8 - Phone"))
        layout.addStretch()

        return widget

    def create_payment_area(self):
        """創建付款信息區域 (Detail 2 - Part 1) - Placeholder"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        layout.addWidget(QtWidgets.QLabel("Total Paid:"), 0, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 0, 1)
        layout.addWidget(QtWidgets.QLabel("No. of payments:"), 0, 2)
        layout.addWidget(QtWidgets.QLineEdit("0"), 0, 3)

        layout.addWidget(QtWidgets.QLabel("Total bound:"), 1, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 1, 1)
        layout.addWidget(QtWidgets.QLabel("No. of bound:"), 1, 2)
        layout.addWidget(QtWidgets.QLineEdit("0"), 1, 3)

        layout.addWidget(QtWidgets.QLabel("Total O/A paid:"), 2, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 2, 1)
        layout.addWidget(QtWidgets.QLabel("Outstanding amt:"), 2, 2)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 2, 3)
        layout.addWidget(QtWidgets.QLabel("O/A Remain:"), 2, 4)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 2, 5)


        layout.addWidget(QtWidgets.QLabel("Ass. amount:"), 3, 0)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 3, 1)
        layout.addWidget(QtWidgets.QLabel("Total Balance:"), 3, 2)
        layout.addWidget(QtWidgets.QLineEdit("0.00"), 3, 3)

        layout.setRowStretch(4, 1)
        layout.setColumnStretch(6, 1)

        return widget

    def create_payment_summary_area(self):
        """創建付款摘要區域 (Detail 2 - Part 2) - Placeholder"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND}; border-top: 1px solid {COLOR_BORDER};")
        layout = QtWidgets.QVBoxLayout(widget)
        layout.setContentsMargins(15, 5, 15, 15)
        layout.setSpacing(5)

        table = QtWidgets.QTableWidget(4, 7)
        table.setHorizontalHeaderLabels([
            "Paid Date", "Paid Amount", "OS/Amount", "OA paid",
            "Adjustment", "MD Col", "Bills"
        ])
        table.horizontalHeader().setStyleSheet(DATA_TABLE_HEADER_STYLE)
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        table.horizontalHeader().setStretchLastSection(True)

        layout.addWidget(table)
        return widget

    def create_personal_info_area(self):
        """創建個人信息區域 (Detail 3) - Placeholder"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10) # Horizontal spacing between label/widget columns
        layout.setVerticalSpacing(8)   # Vertical spacing between rows

        # --- Helper to create input fields with fixed width ---
        def create_input(width, text=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            return line_edit

        # --- Row 0: Birthday, Age, Marital Status ---
        layout.addWidget(QtWidgets.QLabel("Birthday:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(80, "//"), 0, 1)
        layout.addWidget(QtWidgets.QLabel("Age:"), 0, 2, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(50, "0"), 0, 3)
        layout.addWidget(QtWidgets.QLabel("Marital Status:"), 0, 4, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150), 0, 5) # Adjust width as needed

        # --- Row 1: Nationality ---
        layout.addWidget(QtWidgets.QLabel("Nationality:"), 1, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(200), 1, 1, 1, 3) # Span columns 1-3

        # --- Row 2: Education ---
        layout.addWidget(QtWidgets.QLabel("Education:"), 2, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(200), 2, 1, 1, 3) # Span columns 1-3

        # --- Row 3-6: Home Address and Buttons ---
        layout.addWidget(QtWidgets.QLabel("Home Address:"), 3, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        address_edit = QtWidgets.QTextEdit()
        address_edit.setFixedHeight(100) # Adjust height for 4-5 lines roughly
        layout.addWidget(address_edit, 3, 1, 4, 5) # Span 4 rows, 5 columns (1 to 5)

        # Buttons next to address
        address_button_layout = QtWidgets.QVBoxLayout()
        address_button_layout.setContentsMargins(0, 0, 0, 0)
        address_button_layout.setSpacing(5)
        btn_f8_add = QtWidgets.QPushButton("F8 - Add")
        btn_ctrl_f8_phone = QtWidgets.QPushButton("Ctrl+F8-Phone")
        btn_f8_add.setFixedWidth(110) # Fixed width for buttons
        btn_ctrl_f8_phone.setFixedWidth(110)
        address_button_layout.addWidget(btn_f8_add)
        address_button_layout.addWidget(btn_ctrl_f8_phone)
        address_button_layout.addStretch() # Push buttons up
        # Add this button layout to the grid, spanning relevant rows next to the address label
        layout.addLayout(address_button_layout, 3, 0, 4, 1, QtCore.Qt.AlignTop | QtCore.Qt.AlignRight) # Span 4 rows in column 0

        # --- Row 7: Home Phone ---
        layout.addWidget(QtWidgets.QLabel("Home Phone:"), 7, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(250), 7, 1, 1, 3) # Span columns 1-3

        # --- Row 8: Pager Number, A/C, Mobile phone ---
        layout.addWidget(QtWidgets.QLabel("Pager Number:"), 8, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150), 8, 1)
        layout.addWidget(QtWidgets.QLabel("A/C:"), 8, 2, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(50), 8, 3)
        layout.addWidget(QtWidgets.QLabel("Mobile phone:"), 8, 4, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150), 8, 5)

        # --- Row 9: House Status, Years Lived ---
        layout.addWidget(QtWidgets.QLabel("House Status:"), 9, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150), 9, 1)
        layout.addWidget(QtWidgets.QLabel("Years Lived:"), 9, 4, QtCore.Qt.AlignRight) # Positioned further right
        layout.addWidget(create_input(50, "0"), 9, 5)

        # --- Stretch and Column Configuration ---
        # Add row stretch below the last content row
        layout.setRowStretch(10, 1)
        # Configure column widths/stretch if needed (example)
        layout.setColumnMinimumWidth(0, 100) # Minimum width for labels column
        layout.setColumnStretch(1, 1)
        layout.setColumnStretch(3, 1)
        layout.setColumnStretch(5, 1)
        layout.setColumnStretch(6, 1) # Add stretch after the last column

        return widget

    def create_company_info_area(self):
        """創建公司信息區域 (Detail 4) - Placeholder"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(8)

        # --- Helper to create input fields with fixed width ---
        def create_input(width, text=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            return line_edit

        layout.addWidget(QtWidgets.QLabel("Company name:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(350), 0, 1, 1, 3)

        layout.addWidget(QtWidgets.QLabel("Office Address:"), 1, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        office_address_edit = QtWidgets.QTextEdit()
        office_address_edit.setFixedHeight(100) # Adjust height for ~4 lines
        layout.addWidget(office_address_edit, 1, 1, 4, 5)

        layout.addWidget(QtWidgets.QLabel("Office phone 1:"), 5, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(250), 5, 1, 1, 3)

        layout.addWidget(QtWidgets.QLabel("Office Phone 2:"), 6, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(250), 6, 1, 1, 3)

        layout.addWidget(QtWidgets.QLabel("Position:"), 7, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(250), 7, 1, 1, 3)

        layout.addWidget(QtWidgets.QLabel("Annual income:"), 8, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150, "0.00"), 8, 1) # Shorter width

        layout.addWidget(QtWidgets.QLabel("Self-employed:"), 9, 0, QtCore.Qt.AlignRight)
        self_employed_label = QtWidgets.QLabel("N") # Using QLabel as in the image
        self_employed_label.setFixedWidth(40)
        self_employed_label.setAlignment(QtCore.Qt.AlignCenter)
        self_employed_label.setStyleSheet(f"""
            {INPUT_STYLE}
            background-color: #E9E9E9;
            font-weight: bold;
        """)
        layout.addWidget(self_employed_label, 9, 1)

        layout.setRowStretch(10, 1)
        layout.setColumnMinimumWidth(0, 110) # Min width for labels
        layout.setColumnStretch(1, 1)
        layout.setColumnStretch(6, 1) # Stretch after last used column

        return widget

    def create_block_info_area(self):
        """創建封鎖信息區域 (Detail 5) - 根據圖片更新"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(8)

        # --- Helper to create input fields with fixed width ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            return line_edit

        layout.addWidget(QtWidgets.QLabel("Block Code:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100), 0, 1)
        layout.addWidget(QtWidgets.QLabel("Placement:"), 0, 2, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100), 0, 3)

        layout.addWidget(QtWidgets.QLabel("Block Code Remark:"), 1, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(210), 1, 1, 1, 3)

        layout.addWidget(QtWidgets.QLabel("Agency Code:"), 2, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100), 2, 1)

        layout.addWidget(QtWidgets.QLabel("Receive Date:"), 3, 0, QtCore.Qt.AlignRight)
        receive_date_layout = QtWidgets.QHBoxLayout()
        receive_date_layout.setSpacing(5)
        receive_date_layout.addWidget(create_input(80, placeholder="//"))
        receive_date_layout.addWidget(create_input(50, placeholder=" : ")) # For time
        receive_date_layout.addStretch()
        layout.addLayout(receive_date_layout, 3, 1, 1, 2)

        layout.addWidget(QtWidgets.QLabel("HKB Oversea:"), 4, 0, QtCore.Qt.AlignRight)
        hkb_oversea_label = QtWidgets.QLabel("N")
        hkb_oversea_label.setFixedWidth(40)
        hkb_oversea_label.setAlignment(QtCore.Qt.AlignCenter)
        hkb_oversea_label.setStyleSheet(f"""
            {INPUT_STYLE}
            background-color: #E9E9E9;
            font-weight: bold;
        """)
        layout.addWidget(hkb_oversea_label, 4, 1)

        bank_alert_checkbox = QtWidgets.QCheckBox("Bank Information Alert")
        layout.addWidget(bank_alert_checkbox, 5, 0, 1, 2) # Span columns 0-1

        bank_alert_text = QtWidgets.QTextEdit()
        bank_alert_text.setFixedHeight(80) # Adjust height
        layout.addWidget(bank_alert_text, 6, 0, 3, 4) # Span 3 rows, 4 columns (0-3)

        layout.addWidget(QtWidgets.QLabel("Date To Return:"), 9, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 9, 1)

        layout.addWidget(QtWidgets.QLabel("First Call Before:"), 10, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 10, 1)

        layout.addWidget(QtWidgets.QLabel("First Visit Before:"), 11, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 11, 1)

        # --- Column 4 & 5 (Right Side) ---
        right_col_start = 4 # Starting column index for the right section

        layout.addWidget(QtWidgets.QLabel("C/O Date:"), 0, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 0, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Date to C/O:"), 1, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 1, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Net C/O Amt:"), 2, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150, placeholder="."), 2, right_col_start + 1) # Placeholder '.'

        layout.addWidget(QtWidgets.QLabel("Case Refer By:"), 3, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(200), 3, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("HOLD By:"), 4, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(200), 4, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Auto Trans Date:"), 5, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 5, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Last pay date:"), 6, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 6, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Last pay amt:"), 7, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150, placeholder="."), 7, right_col_start + 1) # Placeholder '.'

        layout.addWidget(QtWidgets.QLabel("Visit Collector:"), 8, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100), 8, right_col_start + 1)

        layout.addWidget(QtWidgets.QLabel("Sub Client Name:"), 9, right_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(200), 9, right_col_start + 1, 1, 1) # Ensure it doesn't span too far if grid expands

        # --- Stretch and Column Configuration ---
        layout.setRowStretch(12, 1) # Stretch below last content row
        layout.setColumnMinimumWidth(0, 120) # Adjust min width for left labels
        layout.setColumnMinimumWidth(right_col_start, 110) # Adjust min width for right labels
        layout.setColumnStretch(1, 1) # Allow input columns to stretch
        layout.setColumnStretch(3, 1)
        layout.setColumnStretch(right_col_start + 1, 2) # Give more stretch to right input column
        layout.setColumnStretch(right_col_start + 2, 1) # Add stretch after last column

        return widget

    def create_detail_code_area(self):
        """創建詳細代碼區域 (Detail 6) - 根據圖片更新"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(15)

        # --- Helper (ensure accessible) ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            return line_edit

        # --- Row 0: Detail Code and Last Input Date ---
        layout.addWidget(QtWidgets.QLabel("Detail Code:"), 0, 0, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(150), 0, 1)

        layout.addWidget(QtWidgets.QLabel("Last Input Date:"), 0, 3, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 0, 4)

        # --- Row 1: Large Text Area ---
        detail_code_text = QtWidgets.QTextEdit()
        # Let it expand, or set a minimum height
        detail_code_text.setMinimumHeight(200)
        layout.addWidget(detail_code_text, 1, 0, 1, 6) # Span across columns

        # --- Stretch ---
        layout.setRowStretch(2, 1) # Stretch below the text area
        layout.setColumnStretch(2, 1) # Add some stretch between fields
        layout.setColumnStretch(5, 1) # Stretch after last input date
        layout.setColumnStretch(6, 2) # More stretch at the end

        return widget

    def create_case_history_area(self):
        """創建案件歷史區域 (Detail 7) - 使用 QTableWidget 顯示歷史"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        # Main layout using QHBoxLayout to split left and right
        main_layout = QtWidgets.QHBoxLayout(widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(20) # Spacing between left and right sections

        # --- Left Section (Collector History Table) ---
        left_widget = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        # History Table (Using QTableWidget)
        history_table = QtWidgets.QTableWidget()
        history_table.setMinimumWidth(350) # Adjust width as needed
        history_table.setColumnCount(4)
        history_table.setHorizontalHeaderLabels(["Collector", "From", "To", "By"])

        # Apply Table Styles
        history_table.setStyleSheet(DATA_TABLE_STYLE) # Apply base table style
        history_table.horizontalHeader().setStyleSheet(DATA_TABLE_HEADER_STYLE)
        history_table.verticalHeader().setVisible(False) # Hide row numbers
        history_table.setAlternatingRowColors(True)
        history_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        history_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers) # Read-only

        # Example data (replace with actual data loading)
        history_data = [
            ("CB", "10/20/2000", "10/20/2000", "ADM"),
            ("ICL", "10/20/2000", "11/20/2000", "ADM"),
            ("CA", "10/20/2000", "11/20/2000", "ADM"),
            ("CL", "11/20/2000", "03/06/2004", "ADM"),
            ("ADM", "03/06/2004", "05/13/2004", "ADM"),
            ("CB", "05/13/2004", "09/06/2004", "ADM"),
            ("CD", "09/06/2004", "08/11/2005", "ADM"),
            ("ADM", "08/11/2005", "09/15/2005", "ADM"),
            ("DB", "09/15/2005", "11/04/2005", "ADM"),
            ("DVD", "11/04/2005", "NOW", "SYS")
        ]

        history_table.setRowCount(len(history_data))
        for row, record in enumerate(history_data):
            for col, value in enumerate(record):
                item = QtWidgets.QTableWidgetItem(value)
                # Center align date/by columns, left align collector
                if col == 0:
                    item.setTextAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
                else:
                    item.setTextAlignment(QtCore.Qt.AlignCenter | QtCore.Qt.AlignVCenter)

                # Example: Basic color for ADM/SYS in 'By' column
                if col == 3 and (value == "ADM" or value == "SYS"):
                     item.setForeground(QtGui.QColor(COLOR_ACCENT)) # Blue color
                history_table.setItem(row, col, item)

        # Adjust column widths
        history_table.setColumnWidth(0, 60)  # Collector
        history_table.setColumnWidth(1, 95)  # From
        history_table.setColumnWidth(2, 95)  # To
        history_table.setColumnWidth(3, 50)  # By
        # history_table.horizontalHeader().setStretchLastSection(True) # Optional: Stretch last column

        left_layout.addWidget(history_table)

        # Input field below list
        bottom_input = QtWidgets.QLineEdit()
        left_layout.addWidget(bottom_input)

        # --- Right Section (Case Details - Code remains the same) ---
        right_widget = QtWidgets.QWidget()
        right_layout = QtWidgets.QGridLayout(right_widget) # This is the correct layout variable
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setHorizontalSpacing(10)
        right_layout.setVerticalSpacing(8)

        # Helper (ensure accessible)
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            return line_edit

        # Fields - Use right_layout instead of layout
        right_layout.addWidget(QtWidgets.QLabel("Case entered by:"), 0, 0, QtCore.Qt.AlignRight)
        right_layout.addWidget(create_input(100, "ADM"), 0, 1) # Example value

        right_layout.addWidget(QtWidgets.QLabel("Entry date:"), 1, 0, QtCore.Qt.AlignRight)
        right_layout.addWidget(create_input(100, "10/20/2000"), 1, 1) # Example value

        right_layout.addWidget(QtWidgets.QLabel("Settle Letter:"), 2, 0, QtCore.Qt.AlignRight)
        right_layout.addWidget(create_input(150, "BO10602001S"), 2, 1) # Example value

        right_layout.addWidget(QtWidgets.QLabel("Return Letter:"), 3, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        return_letter_text = QtWidgets.QTextEdit()
        return_letter_text.setFixedHeight(60) # Adjust height
        right_layout.addWidget(return_letter_text, 3, 1, 2, 1) # Span 2 rows

        right_layout.addWidget(QtWidgets.QLabel("Monthly Report:"), 5, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)
        monthly_report_text = QtWidgets.QTextEdit()
        monthly_report_text.setFixedHeight(60) # Adjust height
        right_layout.addWidget(monthly_report_text, 5, 1, 2, 1) # Span 2 rows

        # Stretch for right layout
        right_layout.setRowStretch(7, 1)
        right_layout.setColumnStretch(2, 1)

        # --- Add Left and Right to Main Layout ---
        main_layout.addWidget(left_widget)
        main_layout.addWidget(right_widget)
        main_layout.addStretch() # Add stretch to the main horizontal layout

        return widget

    def create_transfer_info_area(self):
        """創建轉移信息區域 (Detail 8) - 根據圖片更新"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_CONTENT_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setHorizontalSpacing(15) # Increased spacing between columns
        layout.setVerticalSpacing(8)

        # --- Helper (ensure accessible) ---
        def create_input(width, text=None, placeholder=None):
            line_edit = QtWidgets.QLineEdit()
            line_edit.setFixedWidth(width)
            if text:
                line_edit.setText(text)
            if placeholder:
                line_edit.setPlaceholderText(placeholder)
            return line_edit

        # --- Column 0 & 1 (Left Side: Sub A/C and IDs) ---
        sub_ac_labels = [f"Sub A/C no. {i}:" for i in range(1, 6)]
        for i, label_text in enumerate(sub_ac_labels):
            layout.addWidget(QtWidgets.QLabel(label_text), i, 0, QtCore.Qt.AlignRight)
            layout.addWidget(create_input(200), i, 1) # Wider input

        # Spacer row
        layout.setRowMinimumHeight(5, 15) # Add space before Region ID

        id_labels = ["Region ID:", "Agent ID:", "Manager ID:", "Agency ID:"]
        start_row_ids = 6
        for i, label_text in enumerate(id_labels):
            layout.addWidget(QtWidgets.QLabel(label_text), start_row_ids + i, 0, QtCore.Qt.AlignRight)
            layout.addWidget(create_input(200), start_row_ids + i, 1) # Wider input

        # --- Column 2 & 3 (Middle Section: Dates, Notes, Targets) ---
        mid_col_start = 2

        # DRP Date
        layout.addWidget(QtWidgets.QLabel("DRP Date:"), 0, mid_col_start, QtCore.Qt.AlignRight)
        layout.addWidget(create_input(100, placeholder="//"), 0, mid_col_start + 1)

        # Next 4 Transfer Date Label (Row 1)
        layout.addWidget(QtWidgets.QLabel("Next 4 Transfer Date:"), 1, mid_col_start, 1, 2, QtCore.Qt.AlignLeft) # Span 2 columns for label

        # Next 4 Transfer Date Text Edit (Starts Row 2)
        next_transfer_text = QtWidgets.QTextEdit()
        next_transfer_text.setFixedSize(180, 80) # Adjust size
        layout.addWidget(next_transfer_text, 2, mid_col_start, 3, 2) # Span rows 2-4, cols mid_col_start to mid_col_start+1

        # Extended Date (Label only - Row 5)
        layout.addWidget(QtWidgets.QLabel("Extended Date"), 5, mid_col_start, 1, 2, QtCore.Qt.AlignLeft) # Span 2 columns

        # F10 Button (Row 6)
        f10_button = QtWidgets.QPushButton("F10 - Transfer Notes")
        layout.addWidget(f10_button, 6, mid_col_start, 1, 2) # Span 2 columns

        # Target Section (using a sub-grid for alignment)
        target_grid = QtWidgets.QGridLayout()
        target_grid.setSpacing(5)
        target_labels = ["Target Date:", "Total OS:", "Target:", "Permanent:", "Current:"]
        target_inputs = []
        for i, label_text in enumerate(target_labels):
            target_grid.addWidget(QtWidgets.QLabel(label_text), i, 0, QtCore.Qt.AlignRight)
            if i == 0: # Target Date is just a label in the image? Or an input? Assuming label for now.
                 # If it's an input: target_grid.addWidget(create_input(100), i, 1)
                 target_grid.addWidget(QtWidgets.QLabel(""), i, 1) # Placeholder if label
            else:
                inp = create_input(100, "0.00")
                inp.setAlignment(QtCore.Qt.AlignRight) # Right-align currency
                target_inputs.append(inp)
                target_grid.addWidget(inp, i, 1)
        target_grid.setColumnStretch(2, 1) # Stretch after input column
        # Add the target grid to the main layout, starting at ROW 2, next to transfer text
        # Adjusted row index from 1 to 2
        layout.addLayout(target_grid, 2, mid_col_start + 2, 5, 1) # Span rows 2-6 in the next column

        # --- Column 4 (Right Side: Col List) ---
        right_col_start = mid_col_start + 3 # This should now be column 5

        layout.addWidget(QtWidgets.QLabel("Col List"), 0, right_col_start, QtCore.Qt.AlignLeft)
        col_list = QtWidgets.QListWidget()
        col_list.setFixedWidth(120) # Adjust width
        layout.addWidget(col_list, 1, right_col_start, 8, 1)

        reset_button = QtWidgets.QPushButton("Reset")
        reset_button.setFixedWidth(120)
        layout.addWidget(reset_button, 9, right_col_start, QtCore.Qt.AlignBottom)

        # --- Stretch and Column Configuration ---
        # Stretch below last row on left (row 9 is last used by IDs)
        layout.setRowStretch(start_row_ids + len(id_labels), 1)
        layout.setColumnStretch(1, 1) # Stretch Sub A/C input column
        # No stretch for middle columns
        layout.setColumnStretch(mid_col_start + 1, 0)
        layout.setColumnStretch(mid_col_start + 2, 0)
        # Stretch after Col List (column right_col_start + 1, which is 6)
        layout.setColumnStretch(right_col_start + 1, 1)

        return widget

    # ===== EVENT HANDLING AND ACTIONS =====
    def keyPressEvent(self, event):
        """處理按鍵事件"""
        key = event.key()
        modifiers = event.modifiers()

        if key == QtCore.Qt.Key_Escape:
            self.close()
        elif key == QtCore.Qt.Key_F2:
            self.new_action()
        elif key == QtCore.Qt.Key_F3:
            self.edit_action()
        elif key == QtCore.Qt.Key_F4:
            self.delete_action()
        # elif key == QtCore.Qt.Key_F5: # F5 was browse in previous version
        #     self.browse_action()
        # elif key == QtCore.Qt.Key_F6: # F6 was goto in previous version
        #     self.goto_action()
        elif key == QtCore.Qt.Key_F7:
            self.import_action()
        elif key == QtCore.Qt.Key_F10:
            self.print_action()
        else:
            super().keyPressEvent(event)

    # --- Placeholder Action Methods ---
    def new_action(self):
        print("F2 - New action triggered")
        # Add logic for creating a new entry

    def edit_action(self):
        print("F3 - Edit action triggered")
        # Add logic for editing

    def delete_action(self):
        print("F4 - Delete action triggered")
        # Add logic for deleting

    # def browse_action(self): # Keep if needed, otherwise remove
    #     print("F5 - Browse action triggered")
    #     # Add logic for browsing

    # def goto_action(self): # Keep if needed, otherwise remove
    #     print("F6 - Goto action triggered")
    #     # Add logic for goto

    def import_action(self):
        print("F7 - Import action triggered")
        # Add logic for importing data

    def print_action(self):
        print("F10 - Print action triggered")
        # Add logic for printing

# ===== MAIN EXECUTION BLOCK =====
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = CaseEntryBatch() # Instantiate the renamed class
    window.show()
    sys.exit(app.exec_())