import sys
from PyQt5 import QtWidgets, QtGui, QtCore

class SimpleForm(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        self.setWindowTitle('Simple Form')
        self.setGeometry(300, 300, 600, 130)
        self.setStyleSheet("background-color: #d4d0c8;")
        
        # Create the main layout
        main_layout = QtWidgets.QGridLayout(self)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)
        
        # First row
        main_layout.addWidget(QtWidgets.QLabel("Ref No"), 0, 0)
        ref_no_input = QtWidgets.QLineEdit()
        ref_no_input.setText("0")
        ref_no_input.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(ref_no_input, 0, 1)
        
        date_assign_label = QtWidgets.QLabel("Date Assign")
        date_assign_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(date_assign_label, 0, 2)
        
        date_input = QtWidgets.QLineEdit()
        date_input.setStyleSheet("background-color: white; border: 1px solid black;")
        date_input.setText("  /  /  ")
        main_layout.addWidget(date_input, 0, 3)
        
        main_layout.addWidget(QtWidgets.QLabel("(MM/DD/YYYY)"), 0, 4)
        
        # Second row
        main_layout.addWidget(QtWidgets.QLabel("Client Code"), 1, 0)
        client_code = QtWidgets.QLineEdit()
        client_code.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(client_code, 1, 1)
        
        main_layout.addWidget(QtWidgets.QLabel("Loan Type"), 1, 2)
        loan_type = QtWidgets.QLineEdit()
        loan_type.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(loan_type, 1, 3)
        
        collector_label = QtWidgets.QLabel("Collector")
        collector_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(collector_label, 1, 4)
        
        collector = QtWidgets.QLineEdit()
        collector.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(collector, 1, 5)
        
        # Third row
        main_layout.addWidget(QtWidgets.QLabel("A/C name"), 2, 0)
        ac_name = QtWidgets.QLineEdit()
        ac_name.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(ac_name, 2, 1, 1, 2)
        
        status_label = QtWidgets.QLabel("Status")
        status_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(status_label, 2, 3)
        
        status = QtWidgets.QLineEdit()
        status.setStyleSheet("background-color: white; border: 1px solid black;")
        status.setText("  /  ")
        main_layout.addWidget(status, 2, 4)
        
        # Fourth row
        main_layout.addWidget(QtWidgets.QLabel("A/C no."), 3, 0)
        ac_no = QtWidgets.QLineEdit()
        ac_no.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(ac_no, 3, 1, 1, 2)
        
        sex = QtWidgets.QLabel("Sex")
        sex.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(sex, 3, 3)
        
        sex_input = QtWidgets.QLineEdit()
        sex_input.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(sex_input, 3, 4)
        
        card_type_label = QtWidgets.QLabel("Card Type")
        card_type_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(card_type_label, 3, 5)
        
        card_type = QtWidgets.QLineEdit()
        card_type.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(card_type, 3, 6)
        
        # Fifth row
        main_layout.addWidget(QtWidgets.QLabel("Chinese"), 4, 0)
        chinese = QtWidgets.QLineEdit()
        chinese.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(chinese, 4, 1, 1, 2)
        
        english_label = QtWidgets.QLabel("English")
        english_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(english_label, 4, 3)
        
        english_check = QtWidgets.QLabel("N")
        english_check.setFixedSize(20, 20)
        english_check.setStyleSheet("background-color: white; border: 1px solid black; color: black;")
        english_check.setAlignment(QtCore.Qt.AlignCenter)
        main_layout.addWidget(english_check, 4, 4)
        
        id_no_label = QtWidgets.QLabel("I.D no.")
        id_no_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(id_no_label, 4, 5)
        
        id_no = QtWidgets.QLineEdit()
        id_no.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(id_no, 4, 6)
        
        # Sixth row
        main_layout.addWidget(QtWidgets.QLabel("Currency"), 5, 0)
        currency = QtWidgets.QLineEdit()
        currency.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(currency, 5, 1)
        
        corp_label = QtWidgets.QLabel("Corp")
        corp_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(corp_label, 5, 3)
        
        corp_check = QtWidgets.QLabel("N")
        corp_check.setFixedSize(20, 20)
        corp_check.setStyleSheet("background-color: white; border: 1px solid black; color: black;")
        corp_check.setAlignment(QtCore.Qt.AlignCenter)
        main_layout.addWidget(corp_check, 5, 4)
        
        debtor_id_label = QtWidgets.QLabel("Debtor ID")
        debtor_id_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        main_layout.addWidget(debtor_id_label, 5, 5)
        
        debtor_id = QtWidgets.QLineEdit()
        debtor_id.setStyleSheet("background-color: white; border: 1px solid black;")
        main_layout.addWidget(debtor_id, 5, 6)
        
        # Set column stretches to maintain layout
        main_layout.setColumnStretch(2, 1)
        main_layout.setColumnStretch(6, 1)

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    form = SimpleForm()
    form.show()
    sys.exit(app.exec_())