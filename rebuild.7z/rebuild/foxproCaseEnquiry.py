import sys
from PyQt5 import QtWidgets, QtGui, QtCore
from datetime import datetime
from decimal import Decimal, InvalidOperation
import base64
import re
import os
import pyodbc
from dotenv import load_dotenv

# --- Direct Imports for modules in the same directory ---
import_error_message = None
try:
    # Import directly since they are in the same 'rebuild' directory
    import sqlcrypt
    import myCrypt
    import CaseList
    print("Successfully imported local modules (sqlcrypt, myCrypt, CaseList).")
except ImportError as e:
    error_msg = f"ERROR: Failed direct import: {e}. Ensure sqlcrypt.py, myCrypt.py, and CaseList.py are in the 'rebuild' directory."
    print(error_msg)
    import_error_message = error_msg
    # Set placeholders if imports fail
    sqlcrypt = None
    myCrypt = None
    CaseList = None

# --- Load .env file ---
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
if not os.path.exists(dotenv_path):
    print(f"ERROR: .env file not found at {dotenv_path}")
    if not import_error_message:
        import_error_message = f".env file not found at the expected location: {dotenv_path}"
else:
    load_dotenv(dotenv_path=dotenv_path)
    print(f".env file loaded from {dotenv_path}")

# --- Configuration ---
KEY_ID_TO_USE = 1
BASE64_REGEX = re.compile(r'^[A-Za-z0-9+/]*={0,2}$')
MIN_ENCRYPTED_LEN = 24

# ===== FoxPro Style Constants =====
BASE_FONT = "'MS Sans Serif', Arial"
FONT_SIZE_NORMAL = "12px"
FONT_SIZE_SMALL = "11px"
FONT_SIZE_LARGE = "14px"

# 仿 FoxPro 配色方案
COLOR_BACKGROUND = "#D4D0C8"             # 灰色背景 (更準確的 FoxPro 灰色)
COLOR_TITLE_BAR = "#000080"              # 深藍色標題欄 (FoxPro 通常使用深藍色而非黑色)
COLOR_DATA_TABLE_BG = "#000080"          # 深藍色數據表格區域
COLOR_DATA_TABLE_TEXT = "#FFFFFF"        # 白色表格文字
COLOR_CONTENT_BACKGROUND = "#D4D0C8"     # 灰色內容區域
COLOR_BORDER = "#808080"                 # 灰色邊框
COLOR_TEXT_PRIMARY = "#000000"           # 黑色文字
COLOR_TEXT_SECONDARY = "#000000"         # 次要文字也是黑色
COLOR_TABS_ACTIVE = "#FFFFFF"            # 激活標籤
COLOR_TABS_INACTIVE = "#D4D0C8"          # 未激活標籤
COLOR_TABLE_HEADER_BG = "#D4D0C8"        # 表格標題背景為灰色
COLOR_TABLE_HEADER_FG = "#000000"        # 表格標題文字為黑色

# ===== FoxPro Style Element Styles =====
# 樸素的輸入框樣式，模擬舊版 UI
INPUT_STYLE = f"""
    background-color: white;
    border: 1px solid #808080;
    border-style: sunken;
    border-radius: 0px;
    padding: 1px 2px;
    margin: 0px;
    color: {COLOR_TEXT_PRIMARY};
    font-family: {BASE_FONT};
    font-size: {FONT_SIZE_SMALL};
"""

LABEL_STYLE = f"""
    color: {COLOR_TEXT_PRIMARY}; 
    font-family: {BASE_FONT}; 
    font-size: {FONT_SIZE_SMALL};
    padding: 0px;
    margin: 0px;
"""

TITLE_LABEL_STYLE = f"""
    color: white;
    font-family: {BASE_FONT};
    font-size: {FONT_SIZE_NORMAL};
    font-weight: bold;
"""

# 標籤頁按鈕樣式
ACTIVE_TAB_STYLE = f"""
    QPushButton {{
        background-color: white;
        color: black;
        border: 1px solid black;
        border-bottom: 1px solid white;
        border-radius: 0px;
        padding: 1px 2px;
        margin: 0px;
        font-family: {BASE_FONT};
        font-size: {FONT_SIZE_SMALL};
        text-align: center;
    }}
"""

INACTIVE_TAB_STYLE = f"""
    QPushButton {{
        background-color: {COLOR_BACKGROUND};
        color: black;
        border: 1px solid black;
        border-radius: 0px;
        padding: 1px 2px;
        margin: 0px;
        font-family: {BASE_FONT};
        font-size: {FONT_SIZE_SMALL};
        text-align: center;
    }}
"""

# 表格樣式
TABLE_STYLE = f"""
    QTableWidget {{
        background-color: {COLOR_DATA_TABLE_BG};
        color: {COLOR_DATA_TABLE_TEXT};
        gridline-color: white;
        border: 1px solid white;
        font-family: {BASE_FONT};
        font-size: {FONT_SIZE_SMALL};
    }}
    QTableWidget::item {{
        border-bottom: 1px solid white;
        border-right: 1px solid white;
        padding: 0px;
        margin: 0px;
    }}
    QTableWidget::item:selected {{
        background-color: #FFFF00;
        color: black;
    }}
"""

TABLE_HEADER_STYLE = f"""
    QHeaderView::section {{
        background-color: {COLOR_BACKGROUND};
        color: {COLOR_TEXT_PRIMARY};
        padding: 2px;
        border: 1px solid black;
        font-family: {BASE_FONT};
        font-size: {FONT_SIZE_SMALL};
    }}
"""

class CaseEnquiry(QtWidgets.QDialog):
    """
    案件查詢對話框 - 使用傳統 FoxPro 風格的界面
    """
    def __init__(self, parent=None):
        """初始化 CaseEnquiry 對話框"""
        super().__init__(parent)
        self.setWindowTitle("Case Enquiry")
        self._configure_window()
        # 初始化 detail 頁面部件為 None
        self._initialize_detail_widgets()
        self.init_ui()
        
    def _configure_window(self):
        """配置窗口的基本屬性 (大小, 樣式)"""
        self.setFixedSize(780, 580)  # 較小的尺寸，更符合舊式介面
        self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.FramelessWindowHint)

        # 全局樣式表
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {COLOR_BACKGROUND};
                border: 1px solid black;
            }}
            QLabel {{
                {LABEL_STYLE}
            }}
            QLineEdit {{
                {INPUT_STYLE}
            }}
            QTableWidget {{
                {TABLE_STYLE}
            }}
            QHeaderView::section {{
                {TABLE_HEADER_STYLE}
            }}
            QPushButton {{
                background-color: {COLOR_BACKGROUND};
                border: 1px solid black;
                border-radius: 0px;
                padding: 1px 3px;
                margin: 0px;
                color: black;
                font-family: {BASE_FONT};
                font-size: {FONT_SIZE_SMALL};
            }}
        """)

    def _initialize_detail_widgets(self):
        """將所有詳細頁面的屬性初始化為 None"""
        # Detail 1 部分
        self.financial_area = None
        self.data_table_area = None
        
        # 其他 detail 頁面
        self.detail1_container = None
        self.detail2_container = None
        self.detail3_container = None
        self.detail4_container = None
        self.detail5_container = None
        self.detail6_container = None
        self.detail7_container = None
        self.detail8_container = None

    def init_ui(self):
        """初始化用戶界面組件"""
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(1, 1, 1, 1)
        self.main_layout.setSpacing(1)

        # --- UI 組件 ---
        self.title_bar = self.create_title_bar()
        self.form_area = self.create_form_area()
        self.tab_area = self.create_tab_area()

        # --- 堆疊窗口用於 Detail 頁面 ---
        self.stacked_widget = QtWidgets.QStackedWidget()

        # --- 創建 Detail 頁面 1 容器 ---
        self.detail1_container = QtWidgets.QWidget()
        detail1_layout = QtWidgets.QVBoxLayout(self.detail1_container)
        detail1_layout.setContentsMargins(0, 0, 0, 0)
        detail1_layout.setSpacing(0)
        
        # 創建 Detail 1 的部分
        self.financial_area = self.create_financial_area()
        self.data_table_area = self.create_data_table_area()
        
        # 將部分添加到容器布局
        detail1_layout.addWidget(self.financial_area)
        detail1_layout.addWidget(self.data_table_area)
        self.stacked_widget.addWidget(self.detail1_container)
        
        # --- 添加組件到主布局 ---
        self.main_layout.addWidget(self.title_bar)
        self.main_layout.addWidget(self.form_area)
        self.main_layout.addWidget(self.tab_area)
        self.main_layout.addWidget(self.stacked_widget)
        
        # --- 初始顯示頁面 ---
        self.show_detail_page(1)
        
    def create_title_bar(self):
        """創建標題欄 (使用深藍色背景)"""
        title_widget = QtWidgets.QWidget()
        title_widget.setFixedHeight(26)
        title_widget.setStyleSheet(f"background-color: {COLOR_TITLE_BAR};")

        title_layout = QtWidgets.QHBoxLayout(title_widget)
        title_layout.setContentsMargins(5, 0, 5, 0)
        title_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("Case Enquiry")
        title_label.setStyleSheet(TITLE_LABEL_STYLE)

        # 視圖模式標籤 (在右側)
        self.mode_label = QtWidgets.QLabel("VIEW")
        self.mode_label.setStyleSheet(TITLE_LABEL_STYLE)        # 功能鍵提示
        keys_label = QtWidgets.QLabel("F3-Edit | F4-Del | F5-Brow | F6-Goto")
        keys_label.setStyleSheet("color: white; font-size: 11px;")
        
        # 退出鍵提示
        esc_label = QtWidgets.QLabel("ESC-Exit")
        esc_label.setStyleSheet("color: white; font-size: 11px;")
        
        # 布局標題欄
        title_layout.addWidget(title_label)
        title_layout.addStretch()
        title_layout.addWidget(self.mode_label)
        title_layout.addStretch()
        title_layout.addWidget(keys_label)
        title_layout.addSpacing(10)
        title_layout.addWidget(esc_label)

        return title_widget
        
    def create_form_area(self):
        """創建主要表單區域，包含客戶信息"""
        form_widget = QtWidgets.QWidget()
        form_widget.setStyleSheet(f"background-color: {COLOR_BACKGROUND};")

        form_layout = QtWidgets.QGridLayout(form_widget)
        form_layout.setContentsMargins(5, 2, 5, 2)
        form_layout.setHorizontalSpacing(3)
        form_layout.setVerticalSpacing(2)

        # 創建欄位標籤和輸入框
        # 第一行
        form_layout.addWidget(QtWidgets.QLabel("Ref No"), 0, 0)
        self.ref_no = QtWidgets.QLineEdit("frefno")
        self.ref_no.setFixedHeight(22)
        form_layout.addWidget(self.ref_no, 0, 1)
        
        form_layout.addWidget(QtWidgets.QLabel("Date Assign"), 0, 2)
        self.date_assign = QtWidgets.QLineEdit("fdatass")
        self.date_assign.setFixedHeight(22)
        date_hint_label = QtWidgets.QLabel("(MM/DD/YYYY)")
        date_hint_label.setStyleSheet("color: gray; font-size: 10px;")
        form_layout.addWidget(self.date_assign, 0, 3)
        form_layout.addWidget(date_hint_label, 0, 4)

        # 第二行
        form_layout.addWidget(QtWidgets.QLabel("Client Code"), 1, 0)
        self.client_code = QtWidgets.QLineEdit("fclc")
        self.client_code.setFixedHeight(22)
        form_layout.addWidget(self.client_code, 1, 1)
        
        form_layout.addWidget(QtWidgets.QLabel("Loan Type"), 1, 2)
        self.loan_type = QtWidgets.QLineEdit("floadt")
        self.loan_type.setFixedHeight(22)
        form_layout.addWidget(self.loan_type, 1, 3)
        
        form_layout.addWidget(QtWidgets.QLabel("Collector"), 1, 5)
        self.collector = QtWidgets.QLineEdit("fcollec")
        self.collector.setFixedHeight(22)
        form_layout.addWidget(self.collector, 1, 6)

        # 第三行
        form_layout.addWidget(QtWidgets.QLabel("A/C name"), 2, 0)
        self.ac_name = QtWidgets.QLineEdit("facname")
        self.ac_name.setFixedHeight(22)
        form_layout.addWidget(self.ac_name, 2, 1, 1, 3)
        
        form_layout.addWidget(QtWidgets.QLabel("Status"), 2, 5)
        self.status = QtWidgets.QLineEdit("fstatus")
        self.status.setFixedHeight(22)
        self.status_ext = QtWidgets.QLineEdit("Text11")
        self.status_ext.setFixedWidth(50)
        self.status_ext.setFixedHeight(22)
        status_layout = QtWidgets.QHBoxLayout()
        status_layout.setContentsMargins(0, 0, 0, 0)
        status_layout.setSpacing(2)
        status_layout.addWidget(self.status)
        status_layout.addWidget(self.status_ext)
        form_layout.addLayout(status_layout, 2, 6, 1, 2)

        # 第四行
        form_layout.addWidget(QtWidgets.QLabel("A/C no."), 3, 0)
        self.ac_no = QtWidgets.QLineEdit("facno")
        self.ac_no.setFixedHeight(22)
        form_layout.addWidget(self.ac_no, 3, 1, 1, 3)
        
        form_layout.addWidget(QtWidgets.QLabel("Card Type"), 3, 5)
        self.card_type = QtWidgets.QLineEdit("fct")
        self.card_type.setFixedHeight(22)
        self.card_action = QtWidgets.QLineEdit("F5-Change Parent")
        self.card_action.setFixedWidth(150)
        self.card_action.setFixedHeight(22)
        self.card_action.setStyleSheet("color: gray; font-size: 10px;")
        card_layout = QtWidgets.QHBoxLayout()
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(2)
        card_layout.addWidget(self.card_type)
        card_layout.addWidget(self.card_action)
        form_layout.addLayout(card_layout, 3, 6, 1, 2)

        # 第五行
        form_layout.addWidget(QtWidgets.QLabel("Chinese"), 4, 0)
        self.chinese = QtWidgets.QLineEdit("fchname")
        self.chinese.setFixedHeight(22)
        form_layout.addWidget(self.chinese, 4, 1, 1, 2)
        
        form_layout.addWidget(QtWidgets.QLabel("Speak English"), 4, 3)
        self.english = QtWidgets.QLineEdit("Y")
        self.english.setFixedWidth(30)
        self.english.setFixedHeight(22)
        form_layout.addWidget(self.english, 4, 4)
        
        form_layout.addWidget(QtWidgets.QLabel("I.D no."), 4, 5)
        self.id_no = QtWidgets.QLineEdit("fidno")
        self.id_no.setFixedHeight(22)
        form_layout.addWidget(self.id_no, 4, 6, 1, 2)
        
        # 沒有 Sex、Currency、Corp 和 Debtor ID 行 (與截圖一致)

        return form_widget
        
    def create_tab_area(self):
        """創建細節標籤頁按鈕區域"""
        tab_widget = QtWidgets.QWidget()
        tab_widget.setFixedHeight(26)
        tab_widget.setStyleSheet(f"background-color: {COLOR_BACKGROUND};")
        
        tab_layout = QtWidgets.QHBoxLayout(tab_widget)
        tab_layout.setContentsMargins(5, 0, 5, 0)
        tab_layout.setSpacing(0)
        
        self.detail_buttons = []
        for i in range(1, 8):  # 僅包含 7 個標籤 (與截圖一致)
            btn = QtWidgets.QPushButton(f"Detail {i}")
            btn.setFixedWidth(60)
            btn.setFixedHeight(20)
            btn.setStyleSheet(INACTIVE_TAB_STYLE)
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, idx=i: self.show_detail_page(idx))
            self.detail_buttons.append(btn)
            tab_layout.addWidget(btn)
        tab_layout.addStretch()
        return tab_widget
        
    def create_financial_area(self):
        """創建財務信息區域 (Detail 1 - Part 1)"""
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"background-color: {COLOR_BACKGROUND};")
        layout = QtWidgets.QGridLayout(widget)
        layout.setContentsMargins(5, 2, 5, 2)
        layout.setHorizontalSpacing(3)
        layout.setVerticalSpacing(2)

        # 第一行
        layout.addWidget(QtWidgets.QLabel("Ass. Amt"), 0, 0)
        self.ass_amt = QtWidgets.QLineEdit("Text1")
        self.ass_amt.setFixedHeight(22)
        layout.addWidget(self.ass_amt, 0, 1)
        
        layout.addWidget(QtWidgets.QLabel("Late Fee"), 0, 2)
        self.late_fee = QtWidgets.QLineEdit("Text4")
        self.late_fee.setFixedHeight(22)
        layout.addWidget(self.late_fee, 0, 3)
        
        layout.addWidget(QtWidgets.QLabel("Interest"), 0, 4)
        self.interest = QtWidgets.QLineEdit("Text7")
        self.interest.setFixedHeight(22)
        layout.addWidget(self.interest, 0, 5)

        # 第二行
        layout.addWidget(QtWidgets.QLabel("Legal Fee"), 1, 0)
        self.legal_fee = QtWidgets.QLineEdit("Text2")
        self.legal_fee.setFixedHeight(22)
        layout.addWidget(self.legal_fee, 1, 1)
        
        layout.addWidget(QtWidgets.QLabel("Others"), 1, 2)
        self.others = QtWidgets.QLineEdit("Text5")
        self.others.setFixedHeight(22)
        layout.addWidget(self.others, 1, 3)
        
        layout.addWidget(QtWidgets.QLabel("O/S Amt"), 1, 4)
        self.os_amt = QtWidgets.QLineEdit("Text8")
        self.os_amt.setFixedHeight(22)
        layout.addWidget(self.os_amt, 1, 5)

        # 第三行
        layout.addWidget(QtWidgets.QLabel("Commission"), 2, 0)
        self.commission = QtWidgets.QLineEdit("Text3")
        self.commission.setFixedHeight(22)
        layout.addWidget(self.commission, 2, 1)
        
        layout.addWidget(QtWidgets.QLabel("Comm Rate"), 2, 2)
        self.comm_rate = QtWidgets.QLineEdit("Text6")
        self.comm_rate.setFixedHeight(22)
        layout.addWidget(self.comm_rate, 2, 3)

        return widget

    def create_data_table_area(self):
        """創建數據表格區域 (Detail 1 - Part 2)"""
        area_widget = QtWidgets.QWidget()
        area_layout = QtWidgets.QVBoxLayout(area_widget)
        area_layout.setContentsMargins(5, 0, 5, 5)
        area_layout.setSpacing(5)

        # --- 主數據表格 ---
        self.main_data_table = QtWidgets.QTableWidget(0, 7)
        self.main_data_table.setHorizontalHeaderLabels([
            "Bank A/C No", "Ass Amt", "Col", "CT", "ST", "O/S Amt", "Balance"
        ])
        
        # 深藍色背景，白色文字
        self.main_data_table.setStyleSheet(TABLE_STYLE)
        self.main_data_table.verticalHeader().setVisible(False)

        # --- 摘要表格 ---
        self.summary_table = QtWidgets.QTableWidget(2, 8)
        self.summary_table.setHorizontalHeaderLabels([
            "", "No.", "Ass", "Pay", "O/S", "Bal", "", ""
        ])
        
        # 設置行標籤
        row_labels = ["Linked,", "Package, No"]
        for i, label in enumerate(row_labels):
            item = QtWidgets.QTableWidgetItem(label)
            self.summary_table.setVerticalHeaderItem(i, item)
        
        # 填充預設值
        for row in range(2):
            for col in range(8):
                if col == 0:
                    continue
                if col == 1:  # No. 列
                    self.summary_table.setItem(row, col, QtWidgets.QTableWidgetItem(f"Text{9+row}"))
                elif col in [2, 3]:  # Ass, Pay 列
                    self.summary_table.setItem(row, col, QtWidgets.QTableWidgetItem(f"Text{11+row+(col-2)*2}"))
                elif col == 4:  # O/S 列
                    self.summary_table.setItem(row, col, QtWidgets.QTableWidgetItem(f"Text{15+row}"))
                elif col == 5:  # Bal 列
                    self.summary_table.setItem(row, col, QtWidgets.QTableWidgetItem(f"Text{17+row}"))

        # 設置表格樣式
        self.summary_table.setStyleSheet("""
            QTableWidget {
                background-color: #C0C0C0;
                border: 1px solid black;
            }
            QHeaderView::section {
                background-color: #C0C0C0;
                border: 1px solid black;
                padding: 1px;
            }
        """)
        self.summary_table.setFixedHeight(70)  # 限制摘要表格高度

        # 添加到佈局
        area_layout.addWidget(self.main_data_table)
        area_layout.addWidget(self.summary_table)

        return area_widget

    def show_detail_page(self, page_number):
        """根據頁面編號顯示對應的詳細頁面內容"""
        # 更新按鈕樣式
        for i, btn in enumerate(self.detail_buttons):
            is_active = (i + 1 == page_number)
            btn.setStyleSheet(ACTIVE_TAB_STYLE if is_active else INACTIVE_TAB_STYLE)

        # 顯示相應頁面
        if page_number == 1:
            self.stacked_widget.setCurrentWidget(self.detail1_container)
        # 其他頁面顯示邏輯類似...

    def keyPressEvent(self, event):
        """處理按鍵事件"""
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()
        elif event.key() == QtCore.Qt.Key_F5:
            print("F5 key pressed - Browse cases")
            self.browse_cases()
        else:
            super().keyPressEvent(event)

    def browse_cases(self):
        """顯示 CaseList 進行案件瀏覽"""
        if CaseList is None or not hasattr(CaseList, 'CaseList'):
            print("ERROR: CaseList module or class is not available.")
            QtWidgets.QMessageBox.critical(self, "Error", "Case List functionality is unavailable.")
            return
        
        # 這裡實現案件瀏覽邏輯
        print("Browse cases functionality would be implemented here")

# ===== MAIN EXECUTION BLOCK =====
if __name__ == "__main__":
    # 檢查導入錯誤
    if import_error_message:
        print(f"Critical import error detected:\n{import_error_message}")
        sys.exit(f"Exiting due to import error: {import_error_message}")

    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(sys.argv)

    window = CaseEnquiry()
    window.show()
    sys.exit(app.exec_())
