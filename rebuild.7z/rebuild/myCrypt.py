import os
import re
import hashlib
import base64
import Crypto
from Crypto.Cipher import AES 
from Crypto.Util.Padding import pad, unpad 
from Crypto.Random import get_random_bytes
from io import BytesIO
import pyodbc

C1 = 61021
C2 = 35468
EHD = "S@S"
EED = "E#E"

#oldcg
ivHex = '2D2F6B6C747B35403C462849436F3E63'
keyHex = '463E554C2F6B6C68577E4F4243614E5628492F5A43722955297D5A69412C4E43'

#string s, short key
def encrypt(s, key):
    retval = ''
    try:
        ch = list(s)
        
        for i in range(len(s)):
            ch[i] = chr(ord(s[i]) ^ (key >> 8))
            key = ((ord(ch[i]) + key) * C1 + C2) & 0xFFFF
        retval = ''.join(ch)
    except Exception as ex:
        print(f"Error in encrypt() function !!\n{str(ex)}")
    return retval

#string s, short key
def decrypt(s, key):
    retval = None
    try:
        ch = list(s)

        for i in range(len(s)):
            ch[i] = chr(ord(s[i]) ^ (key >> 8))
            key = ((ord(s[i]) + key) * C1 + C2) & 0xFFFF
        retval = ''.join(ch)
    except Exception as ex:
        print(f"Error in decrypt() function !!\n{str(ex)}")
    return retval

#string in_filename, string out_filename, short key
def encrypt_file(in_filename, out_filename, key):
    try:
        with open(in_filename, 'rb') as f:
            encrypted_file = bytearray(f.read())

        for i in range(len(encrypted_file)):
            encrypted_file[i] = encrypted_file[i] ^ (key >> 8)
            key = ((encrypted_file[i] + key) * C1 + C2) & 0xFFFF

        with open(out_filename, 'wb') as f:
            f.write(encrypted_file)

    except Exception as ex:
        if os.path.exists(out_filename):
            os.remove(out_filename)
        print(f"Error in encrypt_file() function !!\n{str(ex)}")

#string in_filename, string out_filename, short key
def decrypt_file(in_filename, out_filename, key):
    try:
        with open(in_filename, 'rb') as f:
            decrypted_file = bytearray(f.read())

        for i in range(len(decrypted_file)):
            C = decrypted_file[i]
            decrypted_file[i] = decrypted_file[i] ^ (key >> 8)
            key = ((C + key) * C1 + C2) & 0xFFFF

        with open(out_filename, 'wb') as f:
            f.write(decrypted_file)

    except Exception as ex:
        if os.path.exists(out_filename):
            os.remove(out_filename)
        print(f"Error in decrypt_file() function !!\n{str(ex)}")

#string text, string key
def encode_data(text, key):
    retval = None
    try:
        hashdigest = hashlib.sha512(key.encode('utf-8')).digest()

        aes_key = hashdigest[:32]
        aes_iv = bytearray([20, 213, 209, 121, 60, 81, 174, 208, 2, 197, 50, 173, 220, 160, 27, 132])

        cipher = AES.new(aes_key, AES.MODE_CFB, iv=aes_iv, segment_size=8)

        encrypted_data = cipher.encrypt(pad(text.encode('utf-8'), AES.block_size))
        retval = base64.b64encode(encrypted_data).decode('utf-8')
    except Exception as ex:
        print(f"Error in encode_data() function !!\n{str(ex)}")
    return retval

#string base64_string
def is_base64_string(base64_string):
    base64_string = base64_string.strip()
    return (len(base64_string) % 4 == 0) and re.match(r'^[a-zA-Z0-9+/]*={0,3}$', base64_string) is not None

#decodestring with #~ at begin
def extbase64_decode(instr):
    try:
        if instr[:2] == '#~':
            return base64.b64decode(instr[2:].encode('latin1')).decode('latin1')
        else:
            return base64.b64decode(instr.encode('latin1')).decode('latin1')
    except Exception as ex:
        print(f"Error in decodestring() function !!\n{str(ex)}")
        
#encodestring add #~ at begin
def extbase64_encode(instr):
    try:
        if instr[:2] == '#~':
            return instr
        else:
            return '#~' + base64.b64encode(instr.encode('latin1')).decode('latin1')
    except Exception as ex:
        print(f"Error in encodestring() function !!\n{str(ex)}")
    
    
#string cipher_text, string key
def decode_data(cipher_text, key):
    retval = ""
    if not key:
        return retval
    try:
        hashdigest = hashlib.sha512(key.encode('utf-8')).digest()
        aes_key = hashdigest[:32]
        aes_iv = bytearray([20, 213, 209, 121, 60, 81, 174, 208, 2, 197, 50, 173, 220, 160, 27, 132])
        crypt_text = base64.b64decode(cipher_text)    
        cipher = AES.new(aes_key, AES.MODE_CFB, iv=aes_iv, segment_size=8)
        decrypted_data = cipher.decrypt(crypt_text)
   
        #decrypted_data = unpad(cipher.decrypt(crypt_text), AES.block_size)
        retval = decrypted_data.decode('latin1')
    except Exception as ex:
        print(f"Error in decode_data() function !!\n{str(ex)}")
    return retval

#short size
def generate_random_bytes(size):
    return os.urandom(size)

#string in_file
def is_v2_encrypt(in_file):
    success = False
    try:
        with open(in_file, 'rb') as f:
            header = f.read(2)
            if header == b'V2':
                success = True
    except Exception as ex:
        success = False
        print(f"Error in is_v2_encrypt() function !!\n{str(ex)}")
    return success

#string in_file, string outFout_fileile, string key
def aes_encrypt_file(in_file, out_file, key):
    success = False

    try:
        # Read input file
        with open(in_file, 'rb') as fs_in_file:
            data = fs_in_file.read()

        # Create output file
        with open(out_file, 'wb') as fs_crypt:
            # Header
            header = b'V2'
            fs_crypt.write(header)

            # Generate random salt
            salt = generate_random_bytes(8)
            key_bytes = key.encode('utf-8')

            # Add salt to output file stream
            fs_crypt.write(salt)

            # Create hash
            hashdigest = hashlib.sha512(salt + key_bytes).digest()

            # Set Rijndael symmetric encryption algorithm
            aes_key = hashdigest[:32]
            iv = generate_random_bytes(AES.block_size)

            # Write IV to file
            fs_crypt.write(iv)

            cipher = AES.new(aes_key, AES.MODE_CBC, iv)

            # Encrypt data and write to output file
            ciphertext = cipher.encrypt(data.ljust((len(data) // AES.block_size + 1) * AES.block_size))
            fs_crypt.write(ciphertext)
            success = True

    except Exception as ex:
        success = False
        if os.path.exists(out_file):
            os.remove(out_file)
        print(f"Error in aes_encrypt_file() function !!\n{str(ex)}")

    return success


def aes_decrypt_file(in_file, key):
    success = False
    fs_out_file = BytesIO()

    try:
        is_v2 = is_v2_encrypt(in_file)

        with open(in_file, 'rb') as fs_crypt:
            if is_v2:
                header = fs_crypt.read(2)

            salt = fs_crypt.read(8)
            key_bytes = key.encode('utf-8')

            hashdigest = hashlib.sha512(salt + key_bytes).digest()

            aes_key = hashdigest[:32]
            iv = fs_crypt.read(AES.block_size)

            cipher = AES.new(aes_key, AES.MODE_CBC, iv)

            while True:
                buffer = fs_crypt.read(1048576)  # 1MB buffer
                if not buffer:
                    break
                fs_out_file.write(cipher.decrypt(buffer))

            fs_out_file.seek(0)  # Reset stream position to the beginning
            success = True

    except Exception as ex:
        success = False
        print(f"Error in aes_decrypt_file() function !!\n{str(ex)}")

    return success, fs_out_file

#string key
def trans_key(key):
    bytes_key = key.encode('utf-8')
    hashed_input_bytes = hashlib.sha512(bytes_key).digest()
    return ''.join(['{:02x}'.format(b) for b in hashed_input_bytes]).upper()

#string file_name
def get_md5_hash_from_file(file_name):
    hash_md5 = hashlib.md5()
    try:
        with open(file_name, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
    except Exception as ex:
        print(f"Error in get_md5_hash_from_file() function !!\n{str(ex)}")
        return None
    return hash_md5.hexdigest()

#string key_file
def get_key_from_pwd(key_file):
    if os.path.exists(key_file):
        k1 = input("Input primary passphrase: ")
        k2 = input("Input secondary passphrase: ")

        if k1 and k2:
            result = get_key(key_file, trans_key(k1 + k2))

            if not result:
                print("Error in get key !!")
                return None
            else:
                return result
        else:
            print("Missing passphrase !!")
            return None
    else:
        print("Missing key file !!")
        return None

#string in_file, string key
def get_key(in_file, key):
    retval = None
    try:
        with open(in_file, 'rb') as fs_crypt:
            salt = fs_crypt.read(8)
            key_bytes = key.encode('utf-8')
            hashdigest = hashlib.sha512(salt + key_bytes).digest()

            aes_key = hashdigest[:32]
            iv = fs_crypt.read(AES.block_size)

            cipher = AES.new(aes_key, AES.MODE_CBC, iv)

            data = cipher.decrypt(fs_crypt.read())
            retval = data.strip(b'\x00').decode('utf-8').replace('S@S', '').replace('E#E', '')
    except Exception as ex:
        print(f"Error in get_key() function !!\n{str(ex)}")
    return retval

#string out_file, string key, string crypttext
def gen_key_file(out_file, key, crypttext):
    success = False
    try:
        with open(out_file, 'wb') as fs_crypt:
            salt = generate_random_bytes(8)
            fs_crypt.write(salt)

            key_bytes = trans_key(key).encode('utf-8')
            hashdigest = hashlib.sha512(salt + key_bytes).digest()

            aes_key = hashdigest[:32]
            iv = generate_random_bytes(AES.block_size)

            fs_crypt.write(iv)

            cipher = AES.new(aes_key, AES.MODE_CBC, iv)
            encrypted_data = cipher.encrypt(pad(crypttext.encode('utf-8'), AES.block_size))

            fs_crypt.write(encrypted_data)
            success = True
    except Exception as ex:
        print(f"Error in gen_key_file() function !!\n{str(ex)}")

    return success

#string s
def to_md5(s):
    md5 = hashlib.md5()
    input_bytes = s.encode('ascii')
    hash_bytes = md5.update(input_bytes)
    return md5.hexdigest().upper()

#string s
def to_hex_string(s):
    input_bytes = s.encode('ascii')
    return ''.join(['{:02X}'.format(b) for b in input_bytes])

#bytes input_bytes
def to_hex_string_bytes(input_bytes):
    return ''.join(['{:02X}'.format(b) for b in input_bytes]).encode('utf-8')

#string input_str
def from_hex_string(input_str):
    bytes_out = bytearray(len(input_str) // 2)
    for i in range(len(bytes_out)):
        bytes_out[i] = int(input_str[i*2:i*2+2], 16)
    return bytes_out


def aes_encrypt(iv, key, crypt_text):
    aes = AES.new(key, AES.MODE_CBC, iv)
    crypt_text = pad(crypt_text, AES.block_size)

    result = None
    try:
        encrypted = aes.encrypt(crypt_text)
        result = to_hex_string(encrypted)
    except Exception as ex:
        print(f"Error in aes_encrypt() function !!\n{str(ex)}")
    return result

def aes_decrypt(iv, key, crypt_text):

    aes = AES.new(key, AES.MODE_CBC, iv)

    result = None
    try:
        #decrypted = aes.decrypt(crypt_text)
        #result = unpad(decrypted, AES.block_size)
        result = aes.decrypt(crypt_text).rstrip(b" ")
    except Exception as ex:
        print(f"Error in aes_decrypt() function !!\n{str(ex)}")
    return result

#byte input_bytes
def byte_to_string(input_bytes):
    if input_bytes is None:
        return None
    else:
        return input_bytes.decode('utf-8')

#string input_str
def string_to_byte(input_str):
    return input_str.encode('utf-8')


#get key from keydb
def getkeyfromkeydb(keyid):  
    # Define the connection string
    connection_string = (
        "DSN=KeyDB;"        
    )
    # Establish the connection
    try:
        connection = pyodbc.connect(connection_string)

        # Create a cursor object using the connection
        cursor = connection.cursor()

        # Example query execution
        cursor.execute("SELECT keyname, keystr FROM KeyTb where id = ?", keyid)
        
        # Fetch and print the results
        keyinfo = cursor.fetchone()

        # Close the connection
        connection.close()
        
        if keyinfo != '':
            key1 = byte_to_string(aes_decrypt(from_hex_string(to_md5(keyinfo[0])), from_hex_string(to_hex_string(to_md5(keyinfo[0]))), from_hex_string(keyinfo[1])))
            return extbase64_decode(key1)
        else:
            return ''        
    except pyodbc.Error as e:
        print("Error in connection:", e)

#Decrypt oldcg Data
def MyDecrypt(data):
    
    if data[-2:] == '::':
        cipher_text = extbase64_decode(data[:-2])       
        result = aes_decrypt(from_hex_string(ivHex), from_hex_string(keyHex), cipher_text.encode('latin1'))
    else:
        result = ''
    return result.decode('latin1')
